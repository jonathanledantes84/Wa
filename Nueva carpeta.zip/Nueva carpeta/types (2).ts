export interface EcosystemItem {
  id: string;
  name: string;
  repoUrl?: string;
  description: string;
  category: 'core' | 'erp' | 'dev' | 'comms' | 'infra' | 'integrations' | 'community' | 'regional';
  subcategory?: string;
  stars?: number;
  language?: string;
  docsUrl?: string;
  relevanceToClientum?: string;
  keyFeatures: string[];
  owner: 'frappe' | 'community' | 'independent' | 'partner';
  status?: 'active' | 'legacy' | 'unmaintained' | 'newer' | 'stable';
  argentinaPotential?: string;
}

export interface CategorySpec {
  key: string;
  label: string;
  icon: string;
  description: string;
}
