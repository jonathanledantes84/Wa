import React, { useState } from 'react';
import { Settings, ShieldCheck, CheckCircle2, PhoneCall, Key, Save } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [saved, setSaved] = useState(false);
  const [phone, setPhone] = useState('+54 9 11 8899-0000');
  const [apiKey, setApiKey] = useState('WA_LIVE_992819283918239012');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="p-8 space-y-8 bg-[#070d1f] min-h-screen text-slate-100">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs bg-emerald-500/10 text-emerald-400 font-semibold px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1.5">
            <Settings className="w-3.5 h-3.5" /> Configuración de la Cuenta
          </span>
          <span className="text-xs text-slate-400">Clientum PRO</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-white">Configuración y API de WhatsApp</h1>
        <p className="text-sm text-slate-400">Gestiona tus credenciales de WhatsApp Business Cloud API y parámetros de empresa.</p>
      </div>

      {saved && (
        <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Cambios guardados y sincronizados correctamente con WhatsApp API.
        </div>
      )}

      <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl max-w-2xl">
        <form onSubmit={handleSave} className="space-y-6">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Nombre de la Empresa</label>
            <input 
              type="text" 
              defaultValue="Clientum Latam S.A."
              className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Número WhatsApp Business API conectado</label>
            <div className="flex gap-3">
              <input 
                type="text" 
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="flex-1 bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
              <span className="px-4 py-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> Verificado
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Token de Acceso API</label>
            <input 
              type="password" 
              value={apiKey}
              onChange={e => setApiKey(e.target.value)}
              className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <div className="pt-4 border-t border-[#1C2541] flex justify-end">
            <button 
              type="submit"
              className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-all shadow-lg shadow-emerald-600/20 flex items-center gap-2"
            >
              <Save className="w-4 h-4" /> Guardar Cambios
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
