import React, { useState } from 'react';
import { Bot, Sparkles, Plus, ToggleLeft, ToggleRight, MessageSquare, Send, CheckCircle2 } from 'lucide-react';
import { ChatbotRule } from '../types';

interface ChatbotViewProps {
  rules: ChatbotRule[];
  onToggleRule: (id: string) => void;
  onAddRule: (rule: ChatbotRule) => void;
}

export const ChatbotView: React.FC<ChatbotViewProps> = ({
  rules,
  onToggleRule,
  onAddRule
}) => {
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState('');
  const [triggerKeyword, setTriggerKeyword] = useState('');
  const [responseMessage, setResponseMessage] = useState('');
  
  // Test simulator state
  const [testInput, setTestInput] = useState('');
  const [testLogs, setTestLogs] = useState<{ sender: 'user' | 'bot'; text: string }[]>([
    { sender: 'bot', text: '¡Hola! Soy el Agente IA de Clientum. Probá escribir una palabra clave como "precio", "hola" o "catalogo".' }
  ]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !triggerKeyword || !responseMessage) return;

    const newRule: ChatbotRule = {
      id: `cb-${Date.now()}`,
      name,
      triggerKeyword,
      responseMessage,
      enabled: true,
      triggerCount: 0,
      action: 'auto_reply'
    };

    onAddRule(newRule);
    setName('');
    setTriggerKeyword('');
    setResponseMessage('');
    setShowModal(false);
  };

  const handleTestSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testInput.trim()) return;

    const userMsg = testInput.trim();
    const newLogs = [...testLogs, { sender: 'user' as const, text: userMsg }];
    setTestInput('');

    // Check matching rule
    const matched = rules.find(r => r.enabled && r.triggerKeyword.toLowerCase().split(',').some(k => userMsg.toLowerCase().includes(k.trim())));
    const botReply = matched 
      ? matched.responseMessage 
      : '🤖 Entendido. Un asesor humano de nuestro equipo se pondrá en contacto contigo en breve a través de WhatsApp.';

    setTimeout(() => {
      setTestLogs([...newLogs, { sender: 'bot', text: botReply }]);
    }, 400);
  };

  return (
    <div className="p-8 space-y-8 bg-[#070d1f] min-h-screen text-slate-100">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs bg-indigo-500/10 text-indigo-400 font-semibold px-2.5 py-1 rounded-full border border-indigo-500/30 flex items-center gap-1.5">
              <Bot className="w-3.5 h-3.5" /> Motor de IA & Automatización
            </span>
            <span className="text-xs text-slate-400">24/7 Respuestas Automáticas</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Chatbot IA WhatsApp</h1>
          <p className="text-sm text-slate-400">Configura reglas inteligentes, palabras clave y derivación automática a vendedores.</p>
        </div>

        <button 
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition-all shadow-lg shadow-emerald-600/20 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Nueva Regla IA
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Rules List */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Reglas Activas del Bot</h3>
          <div className="space-y-4">
            {rules.map((rule) => (
              <div 
                key={rule.id}
                className={`p-5 rounded-2xl bg-[#0B132B] border transition-all shadow-xl space-y-3 ${
                  rule.enabled ? 'border-emerald-500/40' : 'border-[#1C2541] opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      <Bot className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{rule.name}</h4>
                      <p className="text-xs text-emerald-400 font-medium">Palabras clave: <span className="text-slate-300">{rule.triggerKeyword}</span></p>
                    </div>
                  </div>

                  <button 
                    onClick={() => onToggleRule(rule.id)}
                    className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white"
                  >
                    {rule.enabled ? (
                      <span className="flex items-center gap-1 text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/30">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Activado ({rule.triggerCount} disparos)
                      </span>
                    ) : (
                      <span className="text-slate-500 bg-slate-800 px-3 py-1 rounded-full">Desactivado</span>
                    )}
                  </button>
                </div>

                <div className="p-3.5 rounded-xl bg-[#1C2541]/50 border border-slate-700/60 text-xs text-slate-200">
                  <p className="font-semibold text-indigo-300 mb-1">Respuesta automática:</p>
                  <p className="leading-relaxed">{rule.responseMessage}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Bot Test Playground */}
        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl flex flex-col h-[600px]">
          <div className="flex items-center gap-2.5 pb-4 border-b border-[#1C2541] mb-4">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Simulador de Chatbot IA</h3>
              <p className="text-[11px] text-slate-400">Prueba cómo responde tu bot en tiempo real</p>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto space-y-3 pr-2 mb-4">
            {testLogs.map((log, i) => (
              <div key={i} className={`flex flex-col ${log.sender === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs ${
                  log.sender === 'user' 
                    ? 'bg-emerald-600 text-white rounded-br-sm' 
                    : 'bg-[#1C2541] border border-slate-700 text-slate-200 rounded-bl-sm'
                }`}>
                  {log.text}
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleTestSend} className="flex gap-2 pt-3 border-t border-[#1C2541]">
            <input 
              type="text" 
              placeholder="Escribe una prueba (ej: precio)..."
              value={testInput}
              onChange={e => setTestInput(e.target.value)}
              className="flex-1 bg-[#1C2541] border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
            <button 
              type="submit"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-all shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 w-full max-w-lg shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-[#1C2541]">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-emerald-400" /> Nueva Regla de Chatbot IA
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Nombre de la Regla</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej: Consulta de Horarios"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Palabras Clave (separadas por coma)</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej: horario, atienden, dias, abierto"
                  value={triggerKeyword}
                  onChange={e => setTriggerKeyword(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Mensaje de Respuesta Automática</label>
                <textarea 
                  rows={3}
                  required
                  placeholder="Atendemos de lunes a viernes de 9 a 18 hs..."
                  value={responseMessage}
                  onChange={e => setResponseMessage(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                ></textarea>
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <button 
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white text-sm font-medium"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-lg shadow-emerald-600/20"
                >
                  Crear Regla
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
