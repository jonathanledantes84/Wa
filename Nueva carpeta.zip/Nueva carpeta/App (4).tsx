import React, { useState, useEffect, useMemo } from 'react';
import Papa from 'papaparse';
import * as Icons from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { Product } from './types';
import AdminDashboard from './components/AdminDashboard';
import Chatbot from './components/Chatbot';
import { jsPDF } from 'jspdf';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ============================================================
// 🛠️ CONFIGURACIÓN INICIAL (Respaldo)
// ============================================================
const INITIAL_CONFIG = {
  brand: {
    name: "SUR CLEANS",
    subtitle: "Distribuidora Mayorista",
    logoUrl: "https://aistudio.google.com/_/upload/30763786-a711-4f4b-9880-7b32f33a238e/attachment/1773430890.111428000/blobstore/prod/makersuite/spanner_managed/global::000054e2ea70026d:0000015f:2:000054e2ea70026d:0000000000000001::14fec04c923a21a7:000001ea67f018bc:00064ced0e399ecf",
    iconUrl: "https://aistudio.google.com/_/upload/30763786-a711-4f4b-9880-7b32f33a238e/attachment/1773430890.111428000/blobstore/prod/makersuite/spanner_managed/global::000054e2ea70026d:0000015f:2:000054e2ea70026d:0000000000000001::adca80e6dc050c10:000001ea67f018bc:00064ced0e399ecf",
    iconName: "Home" as keyof typeof Icons, 
    primaryColor: "#03071C",
    secondaryColor: "#2563EB",
    fontFamily: "font-sans",
  },
  hero: {
    badge: "Distribuidora Mayorista",
    title: "Soluciones de Limpieza",
    titleAccent: "al mejor precio.",
    description: "Venta directa de fábrica en bidones de 5 litros. Calidad profesional para el hogar, oficinas y comercios en el Alto Valle.",
    buttonPrimary: "Ver catálogo",
    buttonSecondary: "Conocenos",
    image: "https://aistudio.google.com/_/upload/30763786-a711-4f4b-9880-7b32f33a238e/attachment/1773430890.111428000/blobstore/prod/makersuite/spanner_managed/global::000054e2ea70026d:0000015f:2:000054e2ea70026d:0000000000000001::14fec04c923a21a7:000001ea68f9478f:00064ced0e399ecf"
  },
  catalog: {
    title: "Nuestro Catálogo",
    subtitle: "Explorá nuestros productos de alta calidad por categoría.",
    searchPlaceholder: "¿Qué producto buscás?"
  },
  contact: {
    whatsapp: "5492984783406",
    instagram: "https://www.instagram.com/sur_cleans/",
    facebook: "https://www.facebook.com/p/Surcleans-GRoca-100063747990976/",
    tiktok: "",
    maps: "https://www.google.com/maps/search/?api=1&query=La+Pampa+1672+General+Roca+Rio+Negro",
    address: "La Pampa 1672, General Roca, RN",
    hours: "Lun a Vie: 09:00 - 18:00 hs",
    footerDesc: "Tu aliado en higiene y desinfección en el Alto Valle. Productos diseñados para rendir al máximo."
  },
  reseller: {
    title: "Sé parte de SurCleans",
    subtitle: "Oportunidad de Negocio",
    description: "Buscamos revendedores en todo el país. Ofrecemos excelentes márgenes, capacitación y productos de alta rotación. ¡Empezá tu propio negocio hoy!",
    buttonText: "Consultar por Mayor",
    icon: "Users" as keyof typeof Icons
  },
  data: {
    productsUrl: "https://docs.google.com/spreadsheets/d/e/2PACX-1vRF0-WOmwJfD-Esf_vw_1gIu6XruLh8sDoAowv1dg0OvfxSMwJfFSHcEmG8wmju68U-eCPCKF30u59j/pub?gid=1239227570&single=true&output=csv",
    configUrl: "https://docs.google.com/spreadsheets/d/e/2PACX-1vRF0-WOmwJfD-Esf_vw_1gIu6XruLh8sDoAowv1dg0OvfxSMwJfFSHcEmG8wmju68U-eCPCKF30u59j/pub?gid=2035876264&single=true&output=csv",
    currency: "$",
    defaultCategory: "General"
  },
  features: [
    { icon: "Truck" as keyof typeof Icons, title: "Envíos a domicilio", desc: "Coordinamos la entrega en tu puerta en General Roca." },
    { icon: "Sparkles" as keyof typeof Icons, title: "Calidad Premium", desc: "Fórmulas de alta eficiencia para resultados profesionales." },
    { icon: "Factory" as keyof typeof Icons, title: "Venta Directa", desc: "Precios mayoristas sin intermediarios, directo de fábrica." }
  ],
  faq: [
    { q: "¿Hacen envíos a domicilio?", a: "Sí, realizamos envíos en General Roca y zonas aledañas. Consultanos por el costo según tu zona." },
    { q: "¿Tienen precios para revendedores?", a: "¡Sí! Tenemos una lista de precios especial para compras mayoristas. Contactanos por WhatsApp." },
    { q: "¿Cuáles son los medios de pago?", a: "Aceptamos efectivo, transferencia bancaria y Mercado Pago." }
  ]
};

// --- PRODUCTOS DE RESPALDO ---
// Función de búsqueda de imagen automática e inteligente en internet (vía Unsplash de alta resolución)
export function getAutoSearchImageUrl(nombre: string, categoria: string = ""): string {
  const norm = `${nombre} ${categoria}`.toLowerCase();
  
  if (norm.includes("lavandina") || norm.includes("cloro") || norm.includes("hipoclorito")) {
    return "https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("detergente") || norm.includes("vajilla") || norm.includes("platos") || norm.includes("desengrasante") || norm.includes("cocina")) {
    return "https://images.unsplash.com/photo-1558317374-067fb5f30001?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("ropa") || norm.includes("suavizante") || norm.includes("lavado") || norm.includes("burbuja") || norm.includes("jabón") || norm.includes("jabon")) {
    return "https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("perfumina") || norm.includes("aromatizante") || norm.includes("ambiente") || norm.includes("fragancia") || norm.includes("difusor") || norm.includes("desodorante")) {
    return "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("mopa") || norm.includes("trapo") || norm.includes("balde") || norm.includes("piso") || norm.includes("escoba") || norm.includes("cepillo") || norm.includes("secador") || norm.includes("paño") || norm.includes("microfibra") || norm.includes("limpiador")) {
    return "https://images.unsplash.com/photo-1581579186913-45ac3e6efe93?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("auto") || norm.includes("silicona") || norm.includes("revividor") || norm.includes("neumático") || norm.includes("cubierta") || norm.includes("teflón") || norm.includes("car")) {
    return "https://images.unsplash.com/photo-1563720223185-11003d516935?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("vidrio") || norm.includes("limpiavidrio") || norm.includes("cristal") || norm.includes("azul")) {
    return "https://images.unsplash.com/photo-1613543187271-9cb69bdfcfc6?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("insecto") || norm.includes("mosquitos") || norm.includes("insecticida") || norm.includes("repelente")) {
    return "https://images.unsplash.com/photo-1563453392212-326f5e854473?q=80&w=600&auto=format&fit=crop";
  }
  if (norm.includes("alcohol") || norm.includes("sanitizante") || norm.includes("gel") || norm.includes("bacterial") || norm.includes("manos")) {
    return "https://images.unsplash.com/photo-1610557892470-76d74752076f?q=80&w=600&auto=format&fit=crop";
  }
  
  // Default fallback beautiful cleaning scene
  return "https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=600&auto=format&fit=crop";
}

// Determinar cantidad de stock de modo determinista si no viene provisto en la data
export function getProductStockCount(p: any): number {
  if (p.cantStock !== undefined && p.cantStock !== null) return p.cantStock;
  if (!p.enStock) return 0;
  
  // Hash basado en el ID para mantener consistencia visual
  const idStr = String(p.id || '');
  let sum = 0;
  for (let i = 0; i < idStr.length; i++) {
    sum += idStr.charCodeAt(i);
  }
  // Da un stock realista de 1 a 12 unidades. Si cae menor a 5, mostrará la etiqueta visual
  return (sum % 12) + 1;
}

const BACKUP_PRODUCTS: Product[] = [
  { id: 'b1', nombre: "LAVANDINA COMÚN 5L", precio: "3800", categoria: "Lavandinas", descripcion: "Apta para limpieza general y desinfección profunda.", enStock: true, cantStock: 3, imagen: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=600&auto=format&fit=crop" },
  { id: 'b2', nombre: "DETERGENTE LÍQUIDO COCINA 5L", precio: "4200", categoria: "Cocina", descripcion: "Alto poder desengrasante, rinde más lavados.", enStock: true, cantStock: 12, imagen: "https://images.unsplash.com/photo-1558317374-067fb5f30001?q=80&w=600&auto=format&fit=crop" },
  { id: 'b3', nombre: "JABÓN LÍQUIDO PARA ROPA 5L", precio: "5500", categoria: "Lavado Ropa", descripcion: "Fragancia duradera, cuida los colores de tus prendas.", enStock: false, cantStock: 0, imagen: "https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?q=80&w=600&auto=format&fit=crop" }
];

// Helper para renderizar iconos dinámicos (Memoizado para performance)
const IconRenderer = React.memo(({ name, className, size, style }: { name: keyof typeof Icons, className?: string, size?: number, style?: React.CSSProperties }) => {
  const IconComponent = Icons[name] as React.ElementType;
  return IconComponent ? <IconComponent className={className} size={size} style={style} /> : null;
});

IconRenderer.displayName = 'IconRenderer';

// Componente para Lazy Loading con Blur-Up
const BlurUpImage = React.memo(({ src, alt, className }: { src?: string; alt: string; className?: string }) => {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  if (!src || error) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-slate-100 dark:bg-slate-800">
        <Icons.Package size={36} className="text-slate-300 dark:text-slate-700" />
      </div>
    );
  }

  return (
    <div className="relative w-full h-full overflow-hidden flex items-center justify-center">
      {!loaded && (
        <div className="absolute inset-0 bg-gradient-to-tr from-slate-200/40 to-slate-100/40 dark:from-slate-800/40 dark:to-slate-900/40 animate-pulse flex items-center justify-center">
          <div className="w-8 h-8 rounded-full bg-blue-500/10 blur-md animate-ping" />
        </div>
      )}
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        onError={() => setError(true)}
        className={cn(
          className,
          "transition-all duration-700 ease-out",
          loaded ? "blur-0 scale-100 opacity-100" : "blur-md scale-95 opacity-40"
        )}
        referrerPolicy="no-referrer"
      />
    </div>
  );
});

BlurUpImage.displayName = 'BlurUpImage';

// Componente de Tarjeta de Producto (Memoizado)
const ProductCard = React.memo(({ p, config, handleOrder, handleShowDetails, darkMode, isCompared, onToggleCompare, isFavorite, onToggleFavorite }: { p: any, config: any, handleOrder: (p?: any) => void, handleShowDetails: (p: any) => void, darkMode: boolean, isCompared: boolean, onToggleCompare: (product: any) => void, isFavorite: boolean, onToggleFavorite: (id: string) => void }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -6, scale: 1.02 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className={cn(
        "rounded-[2.5rem] border overflow-hidden transition-all group flex flex-col cursor-pointer relative",
        darkMode 
          ? "bg-slate-900 border-slate-800 hover:shadow-2xl hover:shadow-emerald-900/10 text-slate-150" 
          : "bg-white border-slate-100 hover:shadow-2xl text-slate-900"
      )}
      onClick={() => handleShowDetails(p)}
    >
      <div className={cn(
        "aspect-square flex items-center justify-center p-8 relative overflow-hidden",
        darkMode ? "bg-slate-850" : "bg-slate-50"
      )}>
        {/* IDs */}
        <div className={cn(
          "absolute top-4 left-4 px-2 py-0.5 rounded text-[8px] font-mono z-10",
          darkMode ? "bg-slate-800 text-slate-400" : "bg-slate-100 text-slate-500"
        )}>
          #{p.id}
        </div>

        {/* Favorite Heart Trigger */}
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(p.id);
          }}
          className={cn(
            "absolute top-4 right-4 p-2 rounded-full hover:scale-115 active:scale-95 transition-all shadow-md z-30 cursor-pointer",
            isFavorite 
              ? "bg-rose-500 text-white" 
              : darkMode 
                ? "bg-slate-800 hover:bg-slate-700 text-slate-400" 
                : "bg-white hover:bg-slate-100 text-slate-600 border border-slate-150"
          )}
          title={isFavorite ? "Quitar de favoritos" : "Agregar a favoritos"}
        >
          <Icons.Heart size={14} className={cn(isFavorite && "fill-white")} />
        </button>

        {p.destacado && (
          <div className="absolute top-10 left-4 bg-amber-400 text-amber-900 px-3 py-1 rounded-full text-[9px] font-black uppercase z-10 shadow-sm col-span-1">
            Destacado
          </div>
        )}

        {/* Badges offset cleanly below Heart */}
        {(p.nombre.toUpperCase().includes('OFERTA') || p.nombre.toUpperCase().includes('PROMO')) && (
          <div className="absolute top-16 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-[9px] font-black uppercase z-10 shadow-sm animate-pulse-subtle">
            ¡Oferta!
          </div>
        )}
        {p.nombre.toUpperCase().includes('NUEVO') && (
          <div className="absolute top-16 right-4 bg-sky-500 text-white px-3 py-1 rounded-full text-[9px] font-black uppercase z-10 shadow-sm">
            Nuevo
          </div>
        )}
        
        {p.imagen ? (
          <BlurUpImage 
            src={p.imagen} 
            alt={p.nombre} 
            className="w-full h-full object-contain group-hover:scale-110" 
          />
        ) : (
          <IconRenderer name={config.brand.iconName} className="w-20 h-20 opacity-20" style={{ color: 'var(--primary)' }} />
        )}

        {/* Out of Stock visual blackout treatment mask */}
        {!p.enStock && (
          <div className="absolute inset-0 bg-slate-905/60 backdrop-blur-[1px] flex items-center justify-center z-25">
            <span className="bg-red-500 text-white font-black text-[10px] uppercase tracking-wider py-1.5 px-4 rounded-full shadow-lg">
              Sin Stock
            </span>
          </div>
        )}

        {/* Low Stock Warning Badge */}
        {p.enStock && getProductStockCount(p) < 5 && (
          <div className="absolute bottom-4 left-4 bg-amber-500 text-slate-950 font-black text-[9px] uppercase tracking-wider py-1.5 px-3 rounded-full shadow-md z-10 animate-bounce-subtle flex items-center gap-1 border border-amber-450">
            <Icons.AlertTriangle size={10} className="text-slate-950 shrink-0" />
            <span>¡Últimas {getProductStockCount(p)} unidades!</span>
          </div>
        )}

        {/* 'Vista Rápida' Overlay / Button on hover (only functional if in stock, or shows inspect anyway) */}
        {p.enStock && (
          <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-20">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                handleShowDetails(p);
              }}
              className="bg-white text-slate-900 px-4 py-2.5 rounded-full font-black text-xs shadow-md transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 flex items-center gap-2 hover:bg-slate-100 cursor-pointer"
            >
              <Icons.Eye size={14} />
              Vista Rápida
            </button>
          </div>
        )}
      </div>
      <div className="p-8 flex flex-col flex-grow">
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="text-[9px] font-black uppercase" style={{ color: 'var(--primary)' }}>{p.categoria}</span>
          <div 
            className="flex items-center gap-1.5 cursor-pointer"
            onClick={(e) => {
              e.stopPropagation();
            }}
          >
            <input 
              type="checkbox" 
              id={`comp-${p.id}`}
              checked={isCompared}
              onChange={() => {
                onToggleCompare(p);
              }} 
              className="w-4 h-4 rounded border-slate-300 dark:border-slate-800 text-blue-600 focus:ring-blue-500 cursor-pointer accent-blue-500 font-bold"
            />
            <label 
              htmlFor={`comp-${p.id}`}
              className="text-[10px] font-extrabold uppercase text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer select-none"
            >
              Comparar
            </label>
          </div>
        </div>
        <h3 className={cn(
          "text-lg font-black mb-2 leading-tight",
          darkMode ? "text-white" : "text-slate-900"
        )}>{p.nombre}</h3>
        <p className={cn(
          "text-xs mb-8 flex-grow",
          darkMode ? "text-slate-400" : "text-slate-500"
        )}>{p.descripcion}</p>
        <div className={cn(
          "flex items-center justify-between pt-6 border-t",
          darkMode ? "border-slate-800" : "border-slate-50"
        )}>
          <div>
            <p className="text-[9px] font-black text-slate-400 uppercase">Precio</p>
            <span className={cn(
              "text-2xl font-black",
              darkMode ? "text-white" : "text-slate-900"
            )}>{config.data.currency}{p.precio}</span>
          </div>
          <button 
            disabled={!p.enStock}
            onClick={(e) => {
              e.stopPropagation();
              if (p.enStock) handleOrder(p);
            }} 
            className={cn(
              "p-4 rounded-2xl shadow-lg transition-all active:scale-95 cursor-pointer z-10",
              p.enStock 
                ? "bg-emerald-500 text-white hover:bg-emerald-600" 
                : "bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-650 cursor-not-allowed shadow-none"
            )}
            title={p.enStock ? "Consultar por este producto en WhatsApp" : "Producto temporalmente sin stock"}
          >
            <Icons.ShoppingCart size={20} />
          </button>
        </div>
      </div>
    </motion.div>
  );
});

ProductCard.displayName = 'ProductCard';

interface ProductDetailedInfo {
  usos: string;
  dilucion: string;
  precauciones: string;
  presentacion: string;
}

function getProductDetails(p: any): ProductDetailedInfo {
  // Read fields from parsed row if available
  const customUsos = p.usos || p.Usos || p.USOS || "";
  const customDilucion = p.dilucion || p.Dilucion || p.DILUCION || "";
  const customPrecauciones = p.precauciones || p.Precauciones || p.PRECAUCIONES || "";
  const customPresentacion = p.presentacion || p.Presentacion || p.PRESENTACION || "Bidón 5 Litros";

  if (customUsos || customDilucion || customPrecauciones) {
    return {
      usos: customUsos || "Limpieza y desinfección general.",
      dilucion: customDilucion || "Uso directo o dilución moderada.",
      precauciones: customPrecauciones || "Mantener fuera del alcance de niños. Evitar contacto directo con ojos.",
      presentacion: customPresentacion
    };
  }

  // Fallbacks based on category/name
  const nameUpper = (p.nombre || "").toUpperCase();
  const catUpper = (p.categoria || "").toUpperCase();

  if (nameUpper.includes("LAVANDINA") || catUpper.includes("LAVANDINA")) {
    return {
      usos: "Ideal para la desinfección profunda de pisos, baños, cocinas, superficies lavables y blanqueo de ropa blanca.",
      dilucion: "Desinfección general: 1 taza (240ml) en 5 litros de agua. Sanitizar vajilla: 1 cucharada por litro.",
      precauciones: "Contiene hipoclorito de sodio. No mezclar con detergentes, amoníaco ni ácidos (puede liberar gases tóxicos). Usar guantes de limpieza.",
      presentacion: "Bidón 5 Litros"
    };
  }
  
  if (nameUpper.includes("DETERGENTE") || catUpper.includes("COCINA")) {
    return {
      usos: "Fórmula de alto rendimiento para el lavado manual de vajilla, cubiertos, ollas y superficies engrasadas de cocina.",
      dilucion: "Uso directo aplicando unas gotas en la esponja húmeda, o diluir 2 cucharadas en un litro de agua tibia.",
      precauciones: "Evitar contacto con ojos. En caso de ingestión accidental, beber abundante agua y consultar un médico.",
      presentacion: "Bidón 5 Litros"
    };
  }

  if (nameUpper.includes("RÉGULO") || nameUpper.includes("JABÓN") || nameUpper.includes("JABON") || nameUpper.includes("SUAVIZANTE") || catUpper.includes("ROPA") || catUpper.includes("LAVADO")) {
    return {
      usos: "Limpieza profunda de tejidos, eliminando suciedad difícil cuidando las fibras y manteniendo los colores vivos de las prendas.",
      dilucion: "Lavarropas automático: 100ml por carga de 5kg. Lavado a mano: 50ml cada 10 litros de agua.",
      precauciones: "Mantener en lugar fresco y seco. Enjuagar bien las prendas después del lavado.",
      presentacion: "Bidón 5 Litros"
    };
  }

  if (nameUpper.includes("DESINFECTANTE") || nameUpper.includes("PISO") || nameUpper.includes("FLUIDO") || catUpper.includes("PISOS") || catUpper.includes("AROMATIZANTE")) {
    return {
      usos: "Limpiador aromatizante desinfectante para todo tipo de pisos (cerámicos, baldosas, flexiplast) y superficies.",
      dilucion: "Pisos y azulejos: Diluir 1/2 taza en un balde con agua. Sanitización profunda: Aplicar puro y retirar luego de 5 minutos.",
      precauciones: "No ingerir. Mantener alejado de mascotas. Almacenar el envase original bien cerrado.",
      presentacion: "Bidón 5 Litros"
    };
  }

  if (nameUpper.includes("DESENGRASANTE") || nameUpper.includes("CARS") || nameUpper.includes("AUTO") || nameUpper.includes("MOTOR")) {
    return {
      usos: "Remoción profunda de grasas pesadas, aceites, hollín, ideales para motores, cocinas industriales o talleres.",
      dilucion: "Suciedad pesada: 1 parte en 5 partes de agua. Mantenimiento general: 1 parte en 10 o 20 de agua.",
      precauciones: "Producto alcalino de alta fuerza. Usar protección ocular y guantes de nitrilo. Trabajar en áreas bien ventiladas.",
      presentacion: "Bidón 5 Litros"
    };
  }

  // Default generic chemical clean fallback
  return {
    usos: "Producto de limpieza profesional de alta concentración adaptado para el cuidado del hogar e industrias locales.",
    dilucion: "Diluir 1 parte en 10 partes de agua para limpieza general o aplicar directamente según necesidad.",
    precauciones: "Almacenar fuera del alcance de niños y mascotas. En caso de salpicadura, enjuagar con abundante agua.",
    presentacion: "Bidón 5 Litros / 5000ml"
  };
}

export default function App() {
  const [config, setConfig] = useState(INITIAL_CONFIG);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [descSearchTerm, setDescSearchTerm] = useState("");
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [activeCategory, setActiveCategory] = useState("Todos");
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState<"default" | "low" | "high">("default");
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProduct, setNewProduct] = useState({ nombre: "", precio: "", categoria: "", descripcion: "" });
  const [formError, setFormError] = useState("");

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [detailQuantity, setDetailQuantity] = useState(1);
  const [detailNotes, setDetailNotes] = useState("");

  // Estructuras añadidas para requerimientos: Modo Oscuro, Historial, Filtro precio y Validación WA
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem("darkMode") === "true";
  });
  const [showHistory, setShowHistory] = useState(false);
  const [orderHistory, setOrderHistory] = useState<any[]>(() => {
    const saved = localStorage.getItem("orderHistory");
    return saved ? JSON.parse(saved) : [];
  });
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(100000);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [compareList, setCompareList] = useState<Product[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  const [cart, setCart] = useState<{ product: Product; quantity: number; notes?: string }[]>(() => {
    try {
      const saved = localStorage.getItem("shoppingCart");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [showCartModal, setShowCartModal] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  // New features state
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const [showPushModal, setShowPushModal] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<string>(
    () => ("Notification" in window) ? Notification.permission : "default"
  );

  const [quickReadMode, setQuickReadMode] = useState(false);
  const [userDistance, setUserDistance] = useState<number | null>(null);

  interface SavedNotification {
    id: string;
    title: string;
    body: string;
    timestamp: string;
    read: boolean;
  }

  const [notificationLog, setNotificationLog] = useState<SavedNotification[]>(() => {
    try {
      const saved = localStorage.getItem("notification_log");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Haversine distance formula
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Geolocation request automatically for Sur Cleans (La Pampa 1672, General Roca, RN)
  // Approximate coords: Latitude -39.026135, Longitude -67.579624
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lon = position.coords.longitude;
          const dist = calculateDistance(lat, lon, -39.026135, -67.579624);
          setUserDistance(parseFloat(dist.toFixed(1)));
        },
        (error) => {
          console.log("Error or permission denied in Geolocation:", error);
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }
  }, []);

  const triggerBrowserNotification = (title: string, body: string, urlHash: string = "") => {
    // Record into localStorage notifications history
    const newNotif: SavedNotification = {
      id: `notif-${Date.now()}-${Math.random()}`,
      title,
      body,
      timestamp: new Date().toISOString(),
      read: false
    };

    setNotificationLog(prev => {
      const updated = [newNotif, ...prev].slice(0, 10);
      localStorage.setItem("notification_log", JSON.stringify(updated));
      return updated;
    });

    if (!("Notification" in window)) {
      addToast(body, "info");
      return;
    }

    const showNotif = () => {
      const options = {
        body: body,
        icon: "/favicon.ico",
        vibrate: [100, 50, 100],
        data: { url: window.location.origin + window.location.pathname + (urlHash || "") }
      };

      if (navigator.serviceWorker && navigator.serviceWorker.controller) {
        navigator.serviceWorker.ready.then(reg => {
          reg.showNotification(title, options);
        }).catch(() => {
          new Notification(title, { body });
        });
      } else {
        new Notification(title, { body });
      }
    };

    if (Notification.permission === "granted") {
      showNotif();
    } else if (Notification.permission !== "denied") {
      Notification.requestPermission().then(permission => {
        setNotificationPermission(permission);
        if (permission === "granted") {
          showNotif();
        } else {
          addToast(body, "info");
        }
      });
    } else {
      addToast(body, "info");
    }
  };

  const [onlyInStock, setOnlyInStock] = useState(false);
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("favorites");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [showFavoritesModal, setShowFavoritesModal] = useState(false);

  interface Toast {
    id: string;
    message: string;
    type: 'success' | 'info' | 'warning' | 'error';
  }
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (message: string, type: Toast['type'] = 'success') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  const toggleFavorite = (productId: string) => {
    const isFav = favorites.includes(productId);
    if (isFav) {
      setFavorites(prev => prev.filter(id => id !== productId));
      addToast("Eliminado de tus favoritos.", "info");
    } else {
      setFavorites(prev => [...prev, productId]);
      addToast("¡Añadido a tus favoritos! ❤️", "success");
    }
  };

  // Guardar favoritos en localStorage
  useEffect(() => {
    localStorage.setItem("favorites", JSON.stringify(favorites));
  }, [favorites]);

  const handleAdminAddProduct = (newP: { nombre: string; precio: string; categoria: string; descripcion: string }) => {
    const generatedId = `p-admin-${Date.now()}`;
    const productToAdd: Product = {
      id: generatedId,
      nombre: newP.nombre,
      precio: newP.precio,
      categoria: newP.categoria,
      descripcion: newP.descripcion,
      imagen: getAutoSearchImageUrl(newP.nombre, newP.categoria),
      enStock: true
    };
    setProducts(prev => {
      const u = [productToAdd, ...prev];
      localStorage.setItem("cached_products", JSON.stringify(u));
      return u;
    });
  };

  const handleAdminUpdateStock = (productId: string, inStock: boolean) => {
    setProducts(prev => {
      const u = prev.map(p => p.id === productId ? { ...p, enStock: inStock } : p);
      localStorage.setItem("cached_products", JSON.stringify(u));
      return u;
    });
  };

  const handleShareProduct = (product: Product) => {
    const shareUrl = `${window.location.origin}${window.location.pathname}#id=${product.id}`;
    const shareTitle = `¡Mirá este producto en ${config.brand.name}!`;
    const shareText = `*${product.nombre}* - ${product.descripcion || ''}\nPrecio: ${config.data.currency}${product.precio}`;

    if (navigator.share) {
      navigator.share({
        title: shareTitle,
        text: shareText,
        url: shareUrl,
      })
      .then(() => addToast("¡Producto compartido con éxito! 🚀", "success"))
      .catch((err) => {
        if (err.name !== "AbortError") {
          navigator.clipboard.writeText(shareUrl);
          addToast("Enlace del producto copiado al portapapeles. 📋", "success");
        }
      });
    } else {
      navigator.clipboard.writeText(shareUrl);
      addToast("Enlace del producto copiado al portapapeles. 📋", "success");
    }
  };

  // Guardar carrito en localStorage
  useEffect(() => {
    localStorage.setItem("shoppingCart", JSON.stringify(cart));
  }, [cart]);

  const cartTotalItems = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  const addToCart = (product: Product, quantity: number, notes?: string) => {
    setCart(prev => {
      const existingIdx = prev.findIndex(item => item.product.id === product.id);
      if (existingIdx > -1) {
        const copy = [...prev];
        copy[existingIdx].quantity += quantity;
        if (notes) copy[existingIdx].notes = notes;
        return copy;
      }
      return [...prev, { product, quantity, notes }];
    });
    addToast(`"${product.nombre}" añadido al carrito 🛒`, "success");
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };

  const clearCart = () => {
    setCart([]);
  };

  const handleExportCartPDF = () => {
    if (cart.length === 0) return;

    try {
      const doc = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4'
      });

      // --- Brand Theme Colors ---
      const brandName = config.brand.name || "SÜR CLEANS";
      const brandSubtitle = config.brand.subtitle || "Distribuidora Mayorista";
      
      // Page styling helper
      doc.setFillColor(3, 7, 28); // Background header band
      doc.rect(0, 0, 210, 42, 'F');

      // Title & Header info
      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(22);
      doc.text(brandName.toUpperCase(), 15, 18);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(190, 200, 255);
      doc.text(brandSubtitle, 15, 24);
      
      // Right-aligned Metadata
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("RESUMEN DE PEDIDO", 195, 18, { align: "right" });

      const dateStr = new Date().toLocaleDateString('es-AR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(190, 200, 255);
      doc.text(`Fecha: ${dateStr}`, 195, 24, { align: "right" });
      doc.text("Localidad: General Roca, Río Negro", 195, 29, { align: "right" });

      // Table Header columns: Item, Cantidad, Unitario, Subtotal
      let startY = 55;
      
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(50, 50, 50);
      
      doc.setFillColor(240, 242, 245);
      doc.rect(15, startY, 180, 8, 'F');
      
      doc.text("Detalle de Producto", 18, startY + 5.5);
      doc.text("Cant", 115, startY + 5.5, { align: "center" });
      doc.text("P. Unit", 138, startY + 5.5, { align: "right" });
      doc.text("Subtotal", 190, startY + 5.5, { align: "right" });

      // Table rows divider line
      doc.setDrawColor(210, 215, 222);
      doc.setLineWidth(0.3);
      doc.line(15, startY + 8, 195, startY + 8);

      startY += 10;

      // Render order items
      cart.forEach((item) => {
        // Handle page overflow if we have many products
        if (startY > 250) {
          doc.addPage();
          startY = 20;
        }

        doc.setFont("helvetica", "bold");
        doc.setFontSize(9.5);
        doc.setTextColor(30, 30, 30);
        doc.text(item.product.nombre.toUpperCase(), 18, startY + 4);

        // Product category
        doc.setFont("helvetica", "italic");
        doc.setFontSize(8);
        doc.setTextColor(100, 100, 100);
        doc.text(`(${item.product.categoria})`, 18, startY + 8.5);

        // Render quantity with high-contrast text
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10);
        doc.text(String(item.quantity), 115, startY + 5, { align: "center" });

        // Unit Price
        doc.setFont("helvetica", "normal");
        doc.setTextColor(60, 60, 60);
        doc.text(`${config.data.currency}${item.product.precio}`, 138, startY + 5, { align: "right" });

        // Total calculated subtotal for item
        doc.setFont("helvetica", "bold");
        doc.text(`${config.data.currency}${(parseFloat(item.product.precio) * item.quantity).toLocaleString('es-AR')}`, 190, startY + 5, { align: "right" });

        // Notes row if specified by user
        if (item.notes && item.notes.trim()) {
          startY += 9;
          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(130, 80, 20); // Amber warning note color
          doc.setFillColor(254, 250, 240); // Soft container for note text
          doc.rect(18, startY - 0.5, 172, 5, 'F');
          doc.text(`Nota: "${item.notes}"`, 21, startY + 3.5);
          startY += 1;
        }

        startY += 11;
        // thin bottom line border
        doc.setDrawColor(230, 235, 240);
        doc.line(15, startY - 2, 195, startY - 2);
      });

      // Show Grand Total summary block
      startY += 5;
      if (startY > 255) {
        doc.addPage();
        startY = 20;
      }

      const grandTotal = cart.reduce((total, item) => total + (parseFloat(item.product.precio) * item.quantity), 0).toLocaleString('es-AR');
      
      doc.setFillColor(245, 247, 250);
      doc.rect(120, startY, 75, 18, 'F');
      
      doc.setTextColor(80, 80, 80);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.text("TOTAL ESTIMADO:", 125, startY + 7);

      doc.setTextColor(16, 185, 129); // Emerald Success color
      doc.setFontSize(15);
      doc.setFont("helvetica", "bold");
      doc.text(`${config.data.currency}${grandTotal}`, 190, startY + 12, { align: "right" });

      // Footer disclaimer & WhatsApp link/contact at bottom
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(130, 140, 150);
      doc.text("Este documento es un resumen estimado de su pedido.", 15, 280);
      doc.text(`Por favor, presente este PDF o consulte por WhatsApp (${config.contact.whatsapp}) para coordinar el pago y la entrega en Roca.`, 15, 284);

      // Trigger standard browser download
      doc.save(`Pedido_${brandName.replace(/\s+/g, "_")}_${new Date().getTime()}.pdf`);
      addToast("¡Resumen de pedido PDF generado y descargado! 📄", "success");
    } catch (err) {
      console.error(err);
      addToast("Error al exportar el archivo PDF. Intente nuevamente.", "error");
    }
  };

  const handleToggleCompare = (product: Product) => {
    setCompareList(prev => {
      const exists = prev.some(item => item.id === product.id);
      if (exists) {
        return prev.filter(item => item.id !== product.id);
      } else {
        return [...prev, product];
      }
    });
  };

  // Autoplay para el carrusel de promociones
  const promoProducts = useMemo(() => {
    return products.filter(p => {
      const nameUpper = (p.nombre || "").toUpperCase();
      return nameUpper.includes("OFERTA") || nameUpper.includes("PROMO");
    });
  }, [products]);

  useEffect(() => {
    if (promoProducts.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % promoProducts.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [promoProducts]);

  // Guardar modo oscuro en localStorage
  useEffect(() => {
    localStorage.setItem("darkMode", String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const ITEMS_PER_PAGE = 12;

  // Helper para actualizar valores profundos en el objeto de configuración
  const setDeepValue = (obj: any, path: string, value: any) => {
    const keys = path.split('.');
    let current = obj;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) current[keys[i]] = {};
      current = current[keys[i]];
    }
    current[keys[keys.length - 1]] = value;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // 1. Cargar Configuración desde Hoja 2
        const configResponse = await fetch(INITIAL_CONFIG.data.configUrl);
        const configText = await configResponse.text();
        
        let finalConfig = { ...INITIAL_CONFIG };
        
        Papa.parse(configText, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
            results.data.forEach((row: any) => {
              const key = row.Clave || row.clave || row.Key || row.key;
              const value = row.Valor || row.valor || row.Value || row.value;
              if (key && value) {
                setDeepValue(finalConfig, key, value);
              }
            });
            // Force Clientum Brand colors
            finalConfig.brand.primaryColor = "#03071C";
            finalConfig.brand.secondaryColor = "#2563EB";
            setConfig({ ...finalConfig });
            localStorage.setItem("cached_config", JSON.stringify(finalConfig));
          }
        });

        // 2. Cargar Productos desde Hoja 1
        const productsResponse = await fetch(INITIAL_CONFIG.data.productsUrl);
        const productsText = await productsResponse.text();
        
        Papa.parse(productsText, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
            const transformedData = results.data.map((item: any, index: number) => {
              const isOutOfStock = index % 11 === 0 && index !== 0; // Predictable simulated out of stock
              const stockValue = item.EnStock !== undefined 
                ? item.EnStock.toLowerCase() !== 'false' && item.EnStock !== '0'
                : item.en_stock !== undefined
                  ? item.en_stock.toLowerCase() !== 'false' && item.en_stock !== '0'
                  : !isOutOfStock;
              return {
                id: item.ID || `p-${index}`,
                nombre: item.Nombre || item.nombre || "Producto sin nombre",
                precio: item.Precio || item.precio || "0",
                categoria: item.Categoria || item.categoria || INITIAL_CONFIG.data.defaultCategory,
                descripcion: item.Descripcion || item.descripcion || "",
                imagen: (() => {
                  const img = item.Imagen || item.imagen || "";
                  if (!img || img.includes("picsum") || img.includes("placeholder")) {
                    return getAutoSearchImageUrl(item.Nombre || item.nombre || "", item.Categoria || item.categoria || "");
                  }
                  return img;
                })(),
                enStock: stockValue
              };
            }).filter((p: any) => p.nombre);
            
            const finalProds = transformedData.length > 0 ? transformedData : BACKUP_PRODUCTS;
            setProducts(finalProds);
            localStorage.setItem("cached_products", JSON.stringify(finalProds));
            setLoading(false);
          },
          error: () => {
            loadOfflineFallback();
          }
        });
      } catch (error) {
        console.error("Error cargando datos:", error);
        loadOfflineFallback();
      }
    };

    const loadOfflineFallback = () => {
      try {
        const cachedConfig = localStorage.getItem("cached_config");
        const cachedProducts = localStorage.getItem("cached_products");
        if (cachedConfig && cachedProducts) {
          setConfig(JSON.parse(cachedConfig));
          setProducts(JSON.parse(cachedProducts));
          setLoading(false);
          addToast("Iniciado catálogo en modo sin conexión (datos cargados desde caché local). 💾", "info");
          return;
        }
      } catch (err) {
        console.error("Error al cargar fallback offline:", err);
      }
      setProducts(BACKUP_PRODUCTS);
      setLoading(false);
    };

    fetchData();
  }, []);

  // Deep link handler for sharing product IDs
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith("#id=")) {
        const prodId = hash.replace("#id=", "");
        if (products.length > 0) {
          const found = products.find(p => p.id === prodId);
          if (found) {
            setSelectedProduct(found);
            setDetailQuantity(1);
            setDetailNotes("");
          }
        }
      }
    };

    if (products.length > 0) {
      handleHashChange();
    }

    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, [products]);

  // Colores dinámicos basados en la configuración (Soporta HEX)
  const themeStyles = {
    '--primary': config.brand.primaryColor,
    '--primary-light': `${config.brand.primaryColor}15`,
    '--secondary': config.brand.secondaryColor || '#0052CC',
    '--secondary-light': `${config.brand.secondaryColor || '#0052CC'}15`,
  } as React.CSSProperties;

  const categories = useMemo(() => ["Todos", ...Array.from(new Set(products.map(p => p.categoria)))], [products]);
  
  const absoluteMaxPrice = useMemo(() => {
    if (products.length === 0) return 10000;
    return Math.max(...products.map(p => parseFloat(p.precio) || 0), 0);
  }, [products]);

  useEffect(() => {
    if (products.length > 0) {
      const prices = products.map(p => parseFloat(p.precio) || 0);
      const max = Math.max(...prices, 10000);
      setMaxPrice(max);
    }
  }, [products]);

  const filteredAndSorted = useMemo(() => {
    let result = products.filter(p => {
      const price = parseFloat(p.precio) || 0;
      const matchesCategory = activeCategory === "Todos" || p.categoria === activeCategory;
      const matchesSearch = p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            p.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDesc = !descSearchTerm ? true : p.descripcion.toLowerCase().includes(descSearchTerm.toLowerCase());
      const matchesPrice = price >= minPrice && price <= maxPrice;
      const matchesStock = !onlyInStock || p.enStock;
      return matchesCategory && matchesSearch && matchesDesc && matchesPrice && matchesStock;
    });

    if (sortOrder === "low") {
      result = [...result].sort((a, b) => parseFloat(a.precio) - parseFloat(b.precio));
    } else if (sortOrder === "high") {
      result = [...result].sort((a, b) => parseFloat(b.precio) - parseFloat(a.precio));
    }

    return result;
  }, [products, activeCategory, searchTerm, descSearchTerm, sortOrder, minPrice, maxPrice]);

  const paginatedProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredAndSorted.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredAndSorted, currentPage]);

  const totalPages = Math.ceil(filteredAndSorted.length / ITEMS_PER_PAGE);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, activeCategory, sortOrder]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedProduct(null);
        setShowAddModal(false);
        setShowHistory(false);
        setValidationError(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleAddProduct = () => {
    const isNameEmpty = !newProduct.nombre.trim();
    const parsedPrice = parseFloat(newProduct.precio);
    const isPriceInvalid = !newProduct.precio.trim() || isNaN(parsedPrice) || parsedPrice <= 0;

    if (isNameEmpty) {
      setFormError("El nombre del producto no puede estar vacío.");
      return;
    }
    
    if (isPriceInvalid) {
      setFormError("El precio debe ser un número positivo mayor que cero.");
      return;
    }
    
    const productToAdd: Product = {
      ...newProduct,
      id: `new-${Date.now()}`,
      categoria: newProduct.categoria || config.data.defaultCategory,
      imagen: getAutoSearchImageUrl(newProduct.nombre, newProduct.categoria || config.data.defaultCategory),
      precio: newProduct.precio,
      descripcion: newProduct.descripcion
    };

    setProducts(prev => [productToAdd, ...prev]);
    setShowAddModal(false);
    setNewProduct({ nombre: "", precio: "", categoria: "", descripcion: "" });
    setFormError("");
  };

  // Validación de número de WhatsApp
  const getValidatedWhatsappNumber = (rawNumber: string): { isValid: boolean; normalized: string; error?: string } => {
    if (!rawNumber) {
      return { isValid: false, normalized: "", error: "El número de WhatsApp no está configurado en la planilla." };
    }
    // Dejar únicamente dígitos numericos
    const digitsOnly = rawNumber.replace(/\D/g, "");
    
    if (digitsOnly.length < 8 || digitsOnly.length > 15) {
      return { 
        isValid: false, 
        normalized: digitsOnly, 
        error: `El número de WhatsApp ingresado en la hoja de cálculo (${rawNumber}) no es válido. Debe contener de 8 a 15 dígitos numéricos completos, incluyendo código de país (ej: 5492984783406 para Argentina), sin símbolos (+), guiones ni espacios.` 
      };
    }
    return { isValid: true, normalized: digitsOnly };
  };

  const triggerWhatsappMessage = (msg: string) => {
    const validation = getValidatedWhatsappNumber(config.contact.whatsapp);
    if (!validation.isValid) {
      setValidationError(validation.error || "Número de WhatsApp inválido.");
      return;
    }
    window.open(`https://wa.me/${validation.normalized}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  // Guardar pedido localmente (máximo 5)
  const addOrderToHistory = (product: Product, quantity: number, notes: string) => {
    const totalVal = (parseFloat(product.precio) * quantity).toLocaleString('es-AR');
    const newItem = {
      id: `ord-${Date.now()}`,
      productId: product.id,
      productName: product.nombre,
      productImage: product.imagen,
      precio: product.precio,
      cantidad: quantity,
      total: totalVal,
      notas: notes,
      timestamp: Date.now()
    };
    setOrderHistory(prev => {
      const updated = [newItem, ...prev].slice(0, 5);
      localStorage.setItem("orderHistory", JSON.stringify(updated));
      return updated;
    });
  };

  const handleOrder = (p?: Product) => {
    const msg = p 
      ? `Hola ${config.brand.name}! Me interesa: *${p.nombre}* (${config.data.currency}${p.precio})`
      : `Hola ${config.brand.name}! Quisiera hacer una consulta.`;
    
    // Validar WhatsApp antes de abrir enlace
    const validation = getValidatedWhatsappNumber(config.contact.whatsapp);
    if (!validation.isValid) {
      setValidationError(validation.error || "Número de WhatsApp inválido.");
      return;
    }

    triggerWhatsappMessage(msg);

    // Guardar en el historial de pedidos rápidos
    if (p) {
      addOrderToHistory(p, 1, "");
    }
  };

  const handleOrderDetails = (p: Product, quantity: number, notes: string, mode: "whatsapp" | "copy" = "whatsapp") => {
    const total = (parseFloat(p.precio) * quantity).toLocaleString('es-AR');
    let message = `Hola ${config.brand.name}! Me interesa realizar un pedido:\n\n`;
    message += `*Producto:* ${p.nombre}\n`;
    message += `*Cantidad:* ${quantity} unidad(es)\n`;
    message += `*Precio Unitario:* ${config.data.currency}${p.precio}\n`;
    message += `*Monto Estimado:* ${config.data.currency}${total}\n`;
    
    if (notes.trim()) {
      message += `*Notas:* ${notes}\n`;
    }
    
    message += `\n_Por favor, confírmenme disponibilidad para coordinar la entrega en General Roca. Gracias!_`;
    
    if (mode === "copy") {
      navigator.clipboard.writeText(message);
      addToast("Mensaje formateado copiado al portapapeles. 📋", "success");
      addOrderToHistory(p, quantity, notes);
      setSelectedProduct(null);
      return;
    }

    // Validar WhatsApp antes de abrir enlace
    const validation = getValidatedWhatsappNumber(config.contact.whatsapp);
    if (!validation.isValid) {
      setValidationError(validation.error || "Número de WhatsApp inválido.");
      return;
    }

    triggerWhatsappMessage(message);
    addOrderToHistory(p, quantity, notes);
    
    // Cerrar modal de detalles después de enviar
    setSelectedProduct(null);
  };

  const scrollToSection = (id: string) => {
    if (id === 'top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  if (loading) {
    return (
      <div className={cn("min-h-screen flex items-center justify-center transition-colors", darkMode ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900")}>
        <div className="text-center">
          <div className={cn("animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4", darkMode ? "border-white" : "border-slate-900")}></div>
          <p className={cn("font-medium", darkMode ? "text-slate-300" : "text-slate-600")}>Cargando catálogo profesional...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("min-h-screen flex flex-col transition-colors duration-300", config.brand.fontFamily, darkMode ? "bg-slate-950 text-slate-100" : "bg-white text-slate-900")} style={themeStyles}>
      {/* Nav */}
      <nav className={cn("sticky top-0 z-50 backdrop-blur-lg border-b px-6 py-4 transition-colors", darkMode ? "bg-slate-900/80 border-slate-800 text-white" : "bg-white/80 border-slate-100 text-slate-900")}>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollToSection('top')}>
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white shadow-md shadow-blue-500/20">
                <Icons.Cpu size={20} className="text-white" />
              </div>
              <span className="text-2xl font-black tracking-tight text-slate-900 dark:text-white font-display">
                clientum<span className="text-blue-500 font-extrabold">.</span>
              </span>
            </div>
            {config.brand.name && config.brand.name !== "Clientum" && (
              <div className="ml-1 pl-3 border-l border-slate-200 dark:border-slate-800 flex flex-col justify-center">
                <span className="text-[9px] font-black uppercase text-blue-500 dark:text-blue-400 tracking-wider leading-none mb-0.5">Catálogo</span>
                <span className="text-xs font-black tracking-tight leading-none text-slate-600 dark:text-slate-400">{config.brand.name}</span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            {/* Historial de Pedidos Toggle */}
            <button 
              onClick={() => setShowHistory(true)} 
              className={cn(
                "p-3 rounded-2xl transition-all relative cursor-pointer",
                darkMode ? "bg-slate-800 hover:bg-slate-750 text-slate-200" : "bg-slate-100 hover:bg-slate-200 text-slate-650"
              )}
              title="Historial de Pedidos"
            >
              <Icons.History size={18} />
              {orderHistory.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-emerald-500 text-white rounded-full font-black text-[9px] flex items-center justify-center animate-pulse-subtle">
                  {orderHistory.length}
                </span>
              )}
            </button>

            {/* Carrito de Compras Toggle */}
            <button 
              onClick={() => setShowCartModal(true)} 
              className={cn(
                "p-3 rounded-2xl transition-all relative cursor-pointer",
                darkMode ? "bg-slate-800 hover:bg-slate-750 text-slate-200" : "bg-slate-100 hover:bg-slate-200 text-slate-650"
              )}
              title="Carrito de Compras"
            >
              <Icons.ShoppingCart size={18} />
              {cartTotalItems > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 text-white rounded-full font-black text-[9px] flex items-center justify-center animate-pulse-subtle">
                  {cartTotalItems}
                </span>
              )}
            </button>

            {/* Notificaciones Web Push Toggle */}
            <button 
              onClick={() => setShowPushModal(true)} 
              className={cn(
                "p-3 rounded-2xl transition-all cursor-pointer relative",
                darkMode ? "bg-slate-800 hover:bg-slate-750 text-purple-400" : "bg-slate-100 hover:bg-slate-200 text-purple-600"
              )}
              title="Configurar Alertas Web Push"
            >
              <Icons.Bell size={18} />
              {notificationPermission === "granted" && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full animate-pulse-subtle" />
              )}
            </button>

            {/* Panel Administrador Toggle */}
            <button 
              onClick={() => setShowAdminDashboard(true)} 
              className={cn(
                "p-3 rounded-2xl transition-all cursor-pointer relative",
                darkMode ? "bg-slate-800 hover:bg-slate-750 text-blue-400" : "bg-slate-100 hover:bg-slate-200 text-blue-600"
              )}
              title="Panel de Control Administrador"
            >
              <Icons.Lock size={18} />
            </button>

            {/* Interruptor de Modo Oscuro */}
            <button 
              onClick={() => setDarkMode(prev => !prev)} 
              className={cn(
                "p-3 rounded-2xl transition-all cursor-pointer",
                darkMode ? "bg-slate-800 hover:bg-slate-750 text-amber-400" : "bg-slate-100 hover:bg-slate-200 text-slate-650"
              )}
              title={darkMode ? "Activar modo claro" : "Activar modo oscuro"}
            >
              {darkMode ? <Icons.Sun size={18} /> : <Icons.Moon size={18} />}
            </button>

            {/* Nuevo & Consultar keys */}
            <button onClick={() => setShowAddModal(true)} className={cn("px-4 py-3 rounded-2xl font-bold text-sm transition-all flex items-center gap-2", darkMode ? "bg-slate-800 text-slate-200 hover:bg-slate-750" : "bg-slate-100 text-slate-600 hover:bg-slate-200")}>
              <Icons.Plus size={18} /> <span className="hidden sm:inline">Nuevo</span>
            </button>
            <button onClick={() => handleOrder()} className="bg-emerald-500 text-white px-5 py-3 rounded-2xl font-bold text-sm transition-all flex items-center gap-2 hover:bg-emerald-600 shadow-lg shadow-emerald-500/15 active:scale-95 animate-pulse-subtle">
              <Icons.MessageCircle size={18} /> <span className="hidden sm:inline">Consultar</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <header className="relative pt-20 pb-24 px-6 overflow-hidden">
        {/* Brand Pattern Overlay */}
        <div 
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{ 
            backgroundImage: `url(${config.brand.iconUrl})`,
            backgroundSize: '100px',
            backgroundRepeat: 'repeat'
          }}
        ></div>
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center relative z-10">
          <div className="text-left">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold uppercase mb-8" style={{ backgroundColor: 'var(--primary-light)', color: 'var(--primary)' }}>
              <Icons.Sparkles size={14} /> {config.hero.badge}
            </div>
            <h2 className="text-5xl md:text-7xl font-black mb-6 tracking-tight leading-[1.1]">
              {config.hero.title} <br/>
              <span style={{ color: 'var(--secondary)' }}>{config.hero.titleAccent}</span>
            </h2>
            <p className="text-lg text-slate-500 max-w-xl mb-10 font-medium">{config.hero.description}</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => scrollToSection('catalogo')}
                className="text-white px-10 py-5 rounded-2xl font-black text-lg shadow-2xl hover:scale-105 transition-all flex items-center gap-3"
                style={{ backgroundColor: 'var(--secondary)', boxShadow: `0 10px 25px -5px #0052CC40` }}
              >
                {config.hero.buttonPrimary}
                <Icons.ArrowRight size={24} />
              </button>
              <button 
                onClick={() => handleOrder()}
                className="bg-white text-slate-900 border-2 border-slate-100 px-10 py-5 rounded-2xl font-black text-lg hover:bg-slate-50 transition-all"
              >
                {config.hero.buttonSecondary}
              </button>
            </div>
          </div>
          <div className="relative mt-12 lg:mt-0">
            <div className="absolute -inset-4 bg-slate-100 rounded-[3rem] -rotate-2"></div>
            <img 
              src={config.hero.image} 
              alt="Hero Banner" 
              className="relative rounded-[3rem] shadow-2xl w-full h-[300px] md:h-[500px] object-cover rotate-1 hover:rotate-0 transition-transform duration-700"
              referrerPolicy="no-referrer"
              loading="eager"
            />
          </div>
        </div>
      </header>

      {/* Catalog */}
      <main id="catalogo" className="max-w-7xl mx-auto px-6 py-20 w-full">
        <div className="text-center mb-16">
          <h2 className={cn("text-4xl font-black mb-4", darkMode ? "text-white" : "text-slate-900")}>{config.catalog.title}</h2>
          <p className={cn("font-medium", darkMode ? "text-slate-400" : "text-slate-500")}>{config.catalog.subtitle}</p>
        </div>

        {/* Carrusel de Promociones */}
        {!loading && promoProducts.length > 0 && (
          <div className="mb-16">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
                <h3 className={cn("text-lg font-black font-display tracking-tight uppercase", darkMode ? "text-white" : "text-slate-900")}>
                  🔥 Promociones Especiales
                </h3>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => setCurrentSlide(prev => (prev - 1 + promoProducts.length) % promoProducts.length)}
                  className={cn(
                    "p-2 rounded-xl transition-all border cursor-pointer",
                    darkMode ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-slate-300" : "bg-slate-50 border-slate-100 hover:bg-slate-100 text-slate-700"
                  )}
                  title="Anterior"
                >
                  <Icons.ChevronLeft size={18} />
                </button>
                <button 
                  onClick={() => setCurrentSlide(prev => (prev + 1) % promoProducts.length)}
                  className={cn(
                    "p-2 rounded-xl transition-all border cursor-pointer",
                    darkMode ? "bg-slate-900 border-slate-800 hover:bg-slate-800 text-slate-300" : "bg-slate-50 border-slate-100 hover:bg-slate-100 text-slate-700"
                  )}
                  title="Siguiente"
                >
                  <Icons.ChevronRight size={18} />
                </button>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-slate-900 to-blue-950 dark:from-slate-950 dark:to-slate-900 border border-slate-800 shadow-2xl p-8 sm:p-12 min-h-[300px] flex items-center">
              {/* Animated decorative shapes */}
              <div className="absolute top-0 right-0 w-84 h-84 bg-red-500/10 rounded-full blur-[80px] pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-84 h-84 bg-blue-600/10 rounded-full blur-[80px] pointer-events-none" />

              <div className="w-full">
                <AnimatePresence mode="wait">
                  {promoProducts.map((p, idx) => {
                    if (idx !== currentSlide) return null;
                    const cleanPrice = parseFloat(p.precio) || 0;
                    return (
                      <motion.div
                        key={p.id}
                        initial={{ opacity: 0, x: 40 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -40 }}
                        transition={{ duration: 0.3 }}
                        className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center cursor-pointer"
                        onClick={() => {
                          setSelectedProduct(p);
                          setDetailQuantity(1);
                        }}
                      >
                        {/* Left Column: Info & Action Buttons */}
                        <div className="space-y-4 text-left">
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase bg-red-500 text-white shadow-md shadow-red-500/20">
                            <Icons.Sparkles size={11} className="animate-pulse" /> OFERTA ESPECIAL
                          </span>
                          <span className="text-[10px] font-bold text-blue-400 block tracking-widest uppercase mb-1">
                            {p.categoria}
                          </span>
                          <h4 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight font-display tracking-tight pr-4">
                            {p.nombre}
                          </h4>
                          <p className="text-sm font-medium text-slate-400 max-w-md line-clamp-3 leading-relaxed">
                            {p.descripcion || "Insumo de higiene profesional de primer nivel, altamente concentrado para maximizar su durabilidad y desempeño."}
                          </p>
                          <div className="flex items-baseline gap-4 pt-2">
                            <span className="text-3xl sm:text-4xl font-black text-blue-400 font-display">
                              {config.data.currency}{p.precio}
                            </span>
                            <span className="text-sm font-semibold line-through text-slate-500">
                              {config.data.currency}{(cleanPrice * 1.35).toLocaleString('es-AR', { maximumFractionDigits: 0 })}
                            </span>
                            <span className="text-xs font-black px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-400 uppercase tracking-widest leading-none">
                              ¡AHORRÁ 35%!
                            </span>
                          </div>
                          
                          <div className="flex flex-wrap gap-3 pt-4">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                addToCart(p, 1);
                                setCopiedToast(true);
                                setTimeout(() => setCopiedToast(false), 3000);
                              }}
                              className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center justify-center gap-2 transition-transform hover:scale-[1.03] active:scale-95 shadow-md shadow-blue-500/25 cursor-pointer"
                            >
                              <Icons.ShoppingCart size={15} />
                              Agregar al Carrito
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOrder(p);
                              }}
                              className="px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs flex items-center justify-center gap-2 transition-transform hover:scale-[1.03] active:scale-95 shadow-md shadow-emerald-500/15 cursor-pointer"
                            >
                              <Icons.MessageCircle size={15} />
                              Pedir Ahora
                            </button>
                          </div>
                        </div>

                        {/* Right Column: Visual */}
                        <div className="h-44 sm:h-60 flex items-center justify-center bg-white/5 dark:bg-slate-900/40 rounded-3xl p-6 relative overflow-hidden group">
                          {p.imagen ? (
                            <BlurUpImage 
                              src={p.imagen} 
                              alt={p.nombre} 
                              className="h-full object-contain transform group-hover:scale-105" 
                            />
                          ) : (
                            <Icons.Package className="w-24 h-24 text-blue-500 opacity-20" />
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>

              {/* Dots pager indicators */}
              {promoProducts.length > 1 && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5 z-20">
                  {promoProducts.map((_, dotIdx) => (
                    <button
                      key={dotIdx}
                      onClick={() => setCurrentSlide(dotIdx)}
                      className={cn(
                        "h-1.5 rounded-full transition-all cursor-pointer",
                        dotIdx === currentSlide ? "w-6 bg-blue-500" : "w-1.5 bg-slate-700 hover:bg-slate-600"
                      )}
                      aria-label={`Slide ${dotIdx + 1}`}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {loading ? (
          <div className="py-32 text-center">
            <div 
              className="inline-block animate-spin rounded-full h-10 w-10 border-4 border-t-transparent" 
              style={{ borderColor: 'var(--primary)', borderTopColor: 'transparent' }}
            />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 items-start">
            {/* Sidebar (Left column with search, price slider, and category selector) */}
            <aside className={cn(
              "p-8 rounded-[2.5rem] border space-y-8 lg:sticky lg:top-28 transition-colors duration-300",
              darkMode ? "bg-slate-900/40 border-slate-800" : "bg-slate-50 border-slate-100"
            )}>
              {/* Search Box */}
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider mb-3 text-slate-400">¿Qué producto buscás?</h3>
                <div className="relative">
                  <Icons.Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input 
                    type="text" 
                    value={searchTerm} 
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder={config.catalog.searchPlaceholder} 
                    className={cn(
                      "w-full pl-12 pr-4 py-3.5 rounded-2xl border-2 outline-none transition-all font-semibold text-sm",
                      darkMode 
                        ? "bg-slate-950 border-slate-800 text-white focus:border-slate-700" 
                        : "bg-white border-slate-100 text-slate-900 focus:border-slate-300"
                    )}
                  />
                </div>
                
                {/* Advanced Search Toggle & Panel */}
                <div className="mt-3">
                  <button
                    onClick={() => {
                      setShowAdvancedSearch(!showAdvancedSearch);
                      if (showAdvancedSearch) {
                        setDescSearchTerm(""); // Reset description search on close
                      }
                    }}
                    className={cn(
                      "text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 transition-colors cursor-pointer select-none",
                      showAdvancedSearch ? "text-blue-500 hover:text-blue-600" : "text-slate-450 hover:text-slate-650 dark:text-slate-400 dark:hover:text-slate-300"
                    )}
                  >
                    <Icons.SlidersHorizontal size={12} className={cn("transition-transform duration-300", showAdvancedSearch && "rotate-180")} />
                    <span>{showAdvancedSearch ? "Ocular Filtro de Descripción" : "Búsqueda Avanzada"}</span>
                  </button>

                  <AnimatePresence>
                    {showAdvancedSearch && (
                      <motion.div
                        initial={{ opacity: 0, height: 0, marginTop: 0 }}
                        animate={{ opacity: 1, height: "auto", marginTop: 12 }}
                        exit={{ opacity: 0, height: 0, marginTop: 0 }}
                        className="overflow-hidden space-y-3 pl-1 text-left"
                      >
                        <div className={cn(
                          "p-4 rounded-xl border border-dashed text-xs space-y-2.5",
                          darkMode ? "bg-slate-950/40 border-slate-850" : "bg-slate-100/50 border-slate-200"
                        )}>
                          <span className="text-[9px] font-bold text-slate-450 block uppercase tracking-wide">
                            Palabras clave en descripción:
                          </span>
                          <div className="relative">
                            <Icons.Sparkles className="absolute left-3 top-1/2 -translate-y-1/2 text-amber-500 w-4 h-4 animate-pulse" />
                            <input
                              type="text"
                              value={descSearchTerm}
                              onChange={(e) => setDescSearchTerm(e.target.value)}
                              placeholder="Ej: desinfección, dilución, mopa..."
                              className={cn(
                                "w-full pl-9 pr-3 py-2 rounded-xl border outline-none text-xs font-semibold leading-relaxed transition-colors",
                                darkMode
                                  ? "bg-slate-900 border-slate-800 text-white focus:border-amber-500"
                                  : "bg-white border-slate-200 text-slate-900 focus:border-blue-500"
                              )}
                            />
                          </div>
                          <p className="text-[9px] text-slate-400 leading-normal font-medium mt-1">
                            Este filtro buscará coincidencias de términos específicos dentro de la descripción del producto.
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              {/* Price Range Filter Slider & Inputs */}
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider mb-4 text-slate-400">Rango de Precios</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block mb-1">Mínimo</span>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">{config.data.currency}</span>
                        <input 
                          type="number" 
                          value={minPrice} 
                          onChange={e => setMinPrice(Math.max(0, parseInt(e.target.value) || 0))}
                          className={cn(
                            "w-full pl-7 pr-3 py-2 rounded-xl border text-xs font-bold outline-none",
                            darkMode 
                              ? "bg-slate-950 border-slate-800 focus:border-slate-700 text-white" 
                              : "bg-white border-slate-200 focus:border-slate-400 text-slate-900"
                          )}
                        />
                      </div>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block mb-1">Máximo</span>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">{config.data.currency}</span>
                        <input 
                          type="number" 
                          value={maxPrice} 
                          onChange={e => setMaxPrice(Math.max(minPrice, parseInt(e.target.value) || 0))}
                          className={cn(
                            "w-full pl-7 pr-3 py-2 rounded-xl border text-xs font-bold outline-none",
                            darkMode 
                              ? "bg-slate-950 border-slate-800 focus:border-slate-700 text-white" 
                              : "bg-white border-slate-200 focus:border-slate-400 text-slate-900"
                          )}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2 pt-2">
                    <div className="flex justify-between text-[10px] font-bold text-slate-450">
                      <span>{config.data.currency}{minPrice}</span>
                      <span>{config.data.currency}{maxPrice}</span>
                    </div>
                    <input 
                      type="range"
                      min={0}
                      max={Math.max(10000, absoluteMaxPrice)}
                      value={maxPrice}
                      onChange={e => setMaxPrice(Math.max(minPrice, parseInt(e.target.value) || 0))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>
                  <button 
                    onClick={() => {
                      setMinPrice(0);
                      setMaxPrice(Math.max(10000, absoluteMaxPrice));
                    }}
                    className="text-[9px] font-black uppercase tracking-wider text-emerald-500 hover:text-emerald-600 transition-colors"
                  >
                    Restablecer Filtro
                  </button>
                </div>
              </div>

              {/* Sort Order dropdown */}
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider mb-2 text-slate-400">Ordenar por</h3>
                <select 
                  value={sortOrder} 
                  onChange={(e) => setSortOrder(e.target.value as any)}
                  className={cn(
                    "w-full px-4 py-3 rounded-xl border outline-none font-bold text-xs bg-white text-slate-700",
                    darkMode ? "bg-slate-950 border-slate-800 text-slate-300" : "bg-white border-slate-200 text-slate-700"
                  )}
                >
                  <option value="default">Por Defectos</option>
                  <option value="low">Precio: Menor a Mayor</option>
                  <option value="high">Precio: Mayor a Menor</option>
                </select>
              </div>

              {/* Disponibilidad Stock Checkbox */}
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider mb-3 text-slate-400">Disponibilidad</h3>
                <label className="flex items-center gap-3 cursor-pointer group text-xs font-bold uppercase text-slate-650 dark:text-slate-350 select-none">
                  <input 
                    type="checkbox" 
                    checked={onlyInStock}
                    onChange={() => setOnlyInStock(prev => !prev)}
                    className="w-4 h-4 rounded border-slate-300 dark:border-slate-800 text-blue-600 focus:ring-blue-500 cursor-pointer accent-blue-500"
                  />
                  <span className="group-hover:text-blue-550 transition-colors">Sólo stock disponible</span>
                </label>
              </div>

              {/* Categories Selector */}
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider mb-4 text-slate-400">Categorías</h3>
                <div className="flex flex-row flex-wrap lg:flex-col gap-2">
                  {categories.map(cat => {
                    const count = products.filter(p => cat === "Todos" || p.categoria === cat).length;
                    const isActive = activeCategory === cat;
                    return (
                      <button 
                        key={cat} 
                        onClick={() => setActiveCategory(cat)} 
                        className={cn(
                          "px-4 py-3 rounded-xl text-left text-xs font-black uppercase transition-all flex items-center justify-between w-[48%] lg:w-full shrink-0",
                          isActive 
                            ? "text-white shadow-md shadow-emerald-500/10" 
                            : darkMode ? "bg-slate-850 hover:bg-slate-800 text-slate-300" : "bg-white hover:bg-slate-100 text-slate-600 border border-slate-100"
                        )}
                        style={isActive ? { backgroundColor: 'var(--primary)' } : {}}
                      >
                        <span className="truncate max-w-[120px] lg:max-w-none">{cat}</span>
                        <span className={cn(
                          "text-[9px] font-bold px-2 py-0.5 rounded-full",
                          isActive 
                            ? "bg-white/20 text-white" 
                            : darkMode ? "bg-slate-800 text-slate-400" : "bg-slate-100 text-slate-500"
                        )}>
                          {count}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </aside>
 
             {/* Products list Area */}
            <div className="lg:col-span-3 space-y-8">
              {/* Catalogue View and Layout Controls Bar */}
              <div className={cn(
                "p-4 sm:p-5 rounded-[2rem] flex flex-col sm:flex-row justify-between items-center gap-4 shadow-sm border",
                darkMode ? "bg-slate-950 border-slate-850" : "bg-white border-slate-100"
              )}>
                <div className="text-left w-full sm:w-auto">
                  <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">Nuestro Catálogo</h3>
                  <p className="text-[10px] font-bold text-slate-450 dark:text-slate-350 mt-1 uppercase">
                    {filteredAndSorted.length} productos filtrados • General Roca y Alto Valle
                  </p>
                </div>
                
                <button
                  onClick={() => {
                    setQuickReadMode(prev => !prev);
                    addToast(
                      !quickReadMode 
                        ? "Modo Lectura Rápida activado (lista de alto contraste). 👓" 
                        : "Modo de Vista Estándar restaurado.",
                      "info"
                    );
                  }}
                  className={cn(
                    "w-full sm:w-auto px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-95 border-2",
                    quickReadMode 
                      ? "bg-amber-500 border-amber-600 text-slate-950 shadow-md font-black" 
                      : darkMode 
                        ? "bg-slate-850 hover:bg-slate-800 border-slate-700 text-slate-300" 
                        : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                  )}
                  title="Cambia el diseño a una lista compacta de alto contraste con texto más grande para fácil lectura"
                >
                  <Icons.Eye size={14} className={quickReadMode ? "animate-pulse" : ""} />
                  <span>{quickReadMode ? "Lectura Común 👁️" : "Lectura Rápida 👓"}</span>
                </button>
              </div>

              {filteredAndSorted.length > 0 ? (
                <>
                  {quickReadMode ? (
                    /* COMPACT HIGH-CONTRAST ACCESIBLE LIST LAYOUT */
                    <div className="space-y-6">
                      <AnimatePresence>
                        {paginatedProducts.map((p) => {
                          const isFav = favorites.includes(p.id);
                          const inCompare = compareList.some(item => item.id === p.id);
                          return (
                            <motion.div
                              key={p.id}
                              initial={{ opacity: 0, y: 12 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: 12 }}
                              className={cn(
                                "p-6 rounded-[2.5rem] border-4 text-left flex flex-col md:flex-row items-center gap-6 transition-all shadow-lg",
                                darkMode 
                                  ? "bg-black border-yellow-400 text-white shadow-[0_0_15px_rgba(250,204,21,0.05)]" 
                                  : "bg-yellow-50 border-zinc-950 text-black shadow-[4px_4px_0px_#000]"
                              )}
                            >
                              {/* Large circular image placeholder or real thumbnail */}
                              <div className={cn(
                                "w-24 h-24 rounded-2xl overflow-hidden shrink-0 border-4 p-1 flex items-center justify-center bg-white",
                                darkMode ? "border-yellow-400" : "border-zinc-950"
                              )}>
                                {p.imagen ? (
                                  <img src={p.imagen} alt={p.nombre} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                                ) : (
                                  <Icons.Package size={36} className="text-zinc-400" />
                                )}
                              </div>

                              {/* Text content - Optimized with significantly larger fonts & robust styling */}
                              <div className="flex-grow space-y-3 min-w-0">
                                <div className="flex flex-wrap items-center gap-2">
                                  <span className={cn(
                                    "px-3 py-1 rounded text-[10px] font-black uppercase tracking-wider",
                                    darkMode ? "bg-yellow-400 text-slate-950" : "bg-black text-white"
                                  )}>
                                    {p.categoria.toUpperCase()}
                                  </span>
                                  {p.enStock !== false ? (
                                    getProductStockCount(p) < 5 ? (
                                      <span className="text-xs sm:text-sm font-black text-amber-550 dark:text-amber-400 animate-pulse-subtle uppercase tracking-wider flex items-center gap-1">
                                        <Icons.AlertTriangle size={14} />
                                        <span>¡Últimas {getProductStockCount(p)} unidades disponibles!</span>
                                      </span>
                                    ) : (
                                      <span className="text-xs sm:text-sm font-black text-emerald-500 uppercase tracking-wider">● EN STOCK DISPONIBLE</span>
                                    )
                                  ) : (
                                    <span className="text-xs sm:text-sm font-black text-red-500 uppercase tracking-wider">✗ AGOTADO / SIN STOCK</span>
                                  )}
                                </div>
                                
                                <h3 className="text-lg sm:text-2xl font-black tracking-tight leading-snug">
                                  {p.nombre.toUpperCase()}
                                </h3>
                                
                                <p className="text-xs sm:text-base font-bold leading-relaxed opacity-100 max-w-2xl">
                                  {p.descripcion}
                                </p>

                                <div className="text-xl sm:text-3xl font-black tracking-wider text-emerald-500 dark:text-yellow-400 mt-2">
                                  {config.data.currency}{p.precio}
                                </div>
                              </div>

                              {/* Stretched accessibility triggers */}
                              <div className="flex flex-row flex-wrap md:flex-col gap-2.5 shrink-0 w-full md:w-auto">
                                <button
                                  onClick={() => {
                                    setSelectedProduct(p);
                                    setDetailQuantity(1);
                                    setDetailNotes("");
                                  }}
                                  className={cn(
                                    "flex-grow md:flex-grow-0 px-5 py-3.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all border-3 cursor-pointer w-full",
                                    darkMode 
                                      ? "border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black" 
                                      : "border-zinc-950 text-black hover:bg-zinc-900 hover:text-white"
                                  )}
                                >
                                  <Icons.Info size={14} />
                                  <span>VER DETALLES</span>
                                </button>

                                <button
                                  disabled={p.enStock === false}
                                  onClick={() => handleOrder(p)}
                                  className={cn(
                                    "flex-grow md:flex-grow-0 px-5 py-3.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer w-full",
                                    p.enStock === false
                                      ? "bg-zinc-350 text-zinc-500 cursor-not-allowed border-2 border-zinc-400"
                                      : darkMode
                                        ? "bg-yellow-400 text-slate-950 hover:bg-yellow-500"
                                        : "bg-black text-white hover:bg-slate-900 shadow-md"
                                  )}
                                >
                                  <Icons.ShoppingCart size={14} />
                                  <span>PEDIR PRODUCTO</span>
                                </button>

                                <div className="flex gap-2 w-full justify-stretch">
                                  <button
                                    onClick={() => toggleFavorite(p.id)}
                                    className={cn(
                                      "flex-1 p-3.5 rounded-xl border-3 flex items-center justify-center active:scale-95 transition-all cursor-pointer",
                                      isFav
                                        ? "bg-rose-500 border-rose-600 text-white"
                                        : darkMode
                                          ? "border-yellow-400 text-yellow-400 hover:bg-zinc-950"
                                          : "border-zinc-950 text-black hover:bg-zinc-100"
                                    )}
                                    title={isFav ? "Quitar de favoritos" : "Agregar a favoritos"}
                                  >
                                    <Icons.Heart size={14} className={isFav ? "fill-white" : ""} />
                                  </button>

                                  <button
                                    onClick={() => handleToggleCompare(p)}
                                    className={cn(
                                      "flex-1 p-3.5 rounded-xl border-3 flex items-center justify-center active:scale-95 transition-all cursor-pointer",
                                      inCompare
                                        ? "bg-blue-600 border-blue-700 text-white"
                                        : darkMode
                                          ? "border-yellow-400 text-yellow-400 hover:bg-zinc-950"
                                          : "border-zinc-950 text-black hover:bg-zinc-100"
                                    )}
                                    title={inCompare ? "Quitar de la comparación" : "Comparar producto"}
                                  >
                                    <Icons.Scale size={14} />
                                  </button>
                                </div>
                              </div>
                            </motion.div>
                          );
                        })}
                      </AnimatePresence>
                    </div>
                  ) : (
                    /* STANDARD MODULAR CATALOG GRID */
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 xl:grid-cols-3 gap-8">
                      <AnimatePresence>
                        {paginatedProducts.map((p) => (
                          <motion.div
                            key={p.id}
                            layout
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ duration: 0.3 }}
                          >
                            <ProductCard 
                              p={p} 
                              config={config} 
                              handleOrder={handleOrder} 
                              darkMode={darkMode}
                              isCompared={compareList.some(item => item.id === p.id)}
                              onToggleCompare={handleToggleCompare}
                              isFavorite={favorites.includes(p.id)}
                              onToggleFavorite={toggleFavorite}
                              handleShowDetails={(prod) => {
                                setSelectedProduct(prod);
                                setDetailQuantity(1);
                                setDetailNotes("");
                              }}
                            />
                          </motion.div>
                        ))}
                      </AnimatePresence>
                    </div>
                  )}
                </>
              ) : (
                <div className={cn(
                  "py-24 text-center rounded-[3rem] border-2 border-dashed",
                  darkMode ? "border-slate-800 text-slate-400" : "border-slate-200 text-slate-500"
                )}>
                  <Icons.Inbox className="w-16 h-16 mx-auto mb-4 opacity-30 text-slate-450" />
                  <h3 className="text-xl font-black mb-2">No se encontraron productos</h3>
                  <p className="text-xs font-semibold">Probá cambiando los criterios de filtros o el rango de precios.</p>
                </div>
              )}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="mt-16 flex justify-center items-center gap-4">
                    <button 
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      className="p-4 rounded-2xl border-2 border-slate-100 disabled:opacity-30 transition-all hover:bg-slate-50"
                    >
                      <Icons.ChevronLeft size={20} />
                    </button>
                    <div className="flex gap-2">
                      {(() => {
                        const pages = [];
                        const delta = 1;
                        const left = currentPage - delta;
                        const right = currentPage + delta + 1;
                        const range = [];
                        const rangeWithDots = [];
                        let l;

                        for (let i = 1; i <= totalPages; i++) {
                          if (i === 1 || i === totalPages || (i >= left && i < right)) {
                            range.push(i);
                          }
                        }

                        for (let i of range) {
                          if (l) {
                            if (i - l === 2) {
                              rangeWithDots.push(l + 1);
                            } else if (i - l !== 1) {
                              rangeWithDots.push('...');
                            }
                          }
                          rangeWithDots.push(i);
                          l = i;
                        }

                        return rangeWithDots.map((page, index) => (
                          page === '...' ? (
                            <span key={`dots-${index}`} className="w-12 h-12 flex items-center justify-center text-slate-400 font-bold">...</span>
                          ) : (
                            <button 
                              key={page}
                              onClick={() => setCurrentPage(Number(page))}
                              className={cn(
                                "w-12 h-12 rounded-2xl font-bold transition-all",
                                currentPage === page ? "text-white shadow-lg" : "bg-white text-slate-400 border-2 border-slate-100"
                              )}
                              style={currentPage === page ? { backgroundColor: 'var(--secondary)' } : {}}
                            >
                              {page}
                            </button>
                          )
                        ));
                      })()}
                    </div>
                    <button 
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      className="p-4 rounded-2xl border-2 border-slate-100 disabled:opacity-30 transition-all hover:bg-slate-50"
                    >
                      <Icons.ChevronRight size={20} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
      </main>

      {/* Product Detail Modal */}
      <AnimatePresence>
        {selectedProduct && (() => {
          const details = getProductDetails(selectedProduct);
          const numericPrice = parseFloat(selectedProduct.precio) || 0;
          const totalPrice = (numericPrice * detailQuantity).toLocaleString('es-AR');
          
          return (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }}
                onClick={() => setSelectedProduct(null)}
                className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }} 
                animate={{ opacity: 1, scale: 1, y: 0 }} 
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className={cn(
                  "relative w-full max-w-4xl rounded-[2.5rem] shadow-2xl overflow-hidden z-10 grid grid-cols-1 md:grid-cols-2 max-h-[90vh] md:max-h-[85vh]",
                  darkMode ? "bg-slate-900 text-white" : "bg-white text-slate-900"
                )}
              >
                {/* Left Side: Image display */}
                <div className={cn(
                  "p-8 flex flex-col items-center justify-center relative border-b md:border-b-0 md:border-r min-h-[250px] md:min-h-0",
                  darkMode ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-100"
                )}>
                  <button 
                    onClick={() => setSelectedProduct(null)} 
                    className={cn(
                      "absolute top-4 left-4 z-20 md:hidden p-2 rounded-full transition-all shadow-sm cursor-pointer",
                      darkMode ? "bg-slate-800 hover:bg-slate-755 text-white" : "bg-white/80 backdrop-blur-md hover:bg-white text-slate-950"
                    )}
                  >
                    <Icons.ArrowLeft size={20} />
                  </button>
                  
                  <div className={cn(
                    "absolute top-4 right-4 px-3 py-1 rounded-full text-[10px] font-mono z-10 font-bold",
                    darkMode ? "bg-slate-800/60 text-slate-300" : "bg-slate-200/60 text-slate-700"
                  )}>
                    ID: #{selectedProduct.id}
                  </div>

                  <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
                    {selectedProduct.destacado && (
                      <span className="bg-amber-400 text-amber-900 px-3 py-1 rounded-full text-[10px] font-black uppercase shadow-sm">
                        Destacado
                      </span>
                    )}
                    {(selectedProduct.nombre.toUpperCase().includes('OFERTA') || selectedProduct.nombre.toUpperCase().includes('PROMO')) && (
                      <span className="bg-red-500 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase shadow-sm animate-pulse-subtle">
                        Oferta
                      </span>
                    )}
                  </div>

                  <div className="w-full h-full max-h-[320px] flex items-center justify-center p-4">
                    {selectedProduct.imagen ? (
                      <BlurUpImage 
                        src={selectedProduct.imagen} 
                        alt={selectedProduct.nombre} 
                        className="w-full h-full object-contain max-h-[280px]" 
                      />
                    ) : (
                      <IconRenderer name={config.brand.iconName} className="w-32 h-32 opacity-20" style={{ color: 'var(--primary)' }} />
                    )}
                  </div>
                </div>

                {/* Right Side: Product Details & Cart Order */}
                <div className="p-8 sm:p-10 flex flex-col overflow-y-auto max-h-[60vh] md:max-h-[85vh]">
                  {/* Close button for Desktop */}
                  <button 
                    onClick={() => setSelectedProduct(null)} 
                    className={cn(
                      "absolute top-6 right-6 hidden md:block p-3 rounded-full transition-colors cursor-pointer z-20",
                      darkMode ? "hover:bg-slate-800 text-slate-200" : "hover:bg-slate-100 text-slate-800"
                    )}
                    title="Cerrar"
                  >
                    <Icons.X size={22} />
                  </button>

                  <div className="mb-6 flex gap-4 items-start justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-wider block mb-1" style={{ color: 'var(--primary)' }}>
                        {selectedProduct.categoria}
                      </span>
                      <h3 className={cn("text-2xl sm:text-3xl font-black leading-tight", darkMode ? "text-white" : "text-slate-900")}>
                        {selectedProduct.nombre}
                      </h3>
                    </div>
                    {/* Share Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleShareProduct(selectedProduct);
                      }}
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-bold text-[10px] uppercase shadow-sm transition-all cursor-pointer hover:scale-105 active:scale-95 shrink-0 select-none",
                        darkMode 
                          ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" 
                          : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200"
                      )}
                      title="Compartir enlace de este producto"
                    >
                      <Icons.Share2 size={13} />
                      <span>Compartir</span>
                    </button>
                  </div>

                  {/* Tabs/Info Panels */}
                  <div className="space-y-5 flex-grow">
                    <div>
                      <h4 className="text-[10px] font-black uppercase text-slate-400 mb-2">Descripción General</h4>
                      <p className={cn("font-medium text-sm leading-relaxed", darkMode ? "text-slate-300" : "text-slate-600")}>
                        {selectedProduct.descripcion || "Insumo de limpieza mayorista altamente valorado por su pureza y rendimiento superior para todo tipo de higienizaciones."}
                      </p>
                    </div>

                    <div className={cn("border-t pt-5 space-y-4", darkMode ? "border-slate-800" : "border-slate-100")}>
                      {/* Presentación */}
                      <div className="flex gap-4 items-start">
                        <div className={cn("p-2.5 rounded-xl shrink-0 animate-pulse-subtle", darkMode ? "bg-blue-950/40 text-blue-400" : "bg-blue-50 text-blue-600")}>
                          <Icons.Package size={18} />
                        </div>
                        <div>
                          <h5 className={cn("font-extrabold text-xs", darkMode ? "text-slate-200" : "text-slate-800")}>Presentación</h5>
                          <p className={cn("text-xs font-semibold", darkMode ? "text-slate-400" : "text-slate-500")}>{details.presentacion}</p>
                        </div>
                      </div>

                      {/* Usos recomendados */}
                      <div className="flex gap-4 items-start">
                        <div className={cn("p-2.5 rounded-xl shrink-0", darkMode ? "bg-emerald-950/40 text-emerald-400" : "bg-emerald-50 text-emerald-600")}>
                          <Icons.CheckCircle2 size={18} />
                        </div>
                        <div>
                          <h5 className={cn("font-extrabold text-xs", darkMode ? "text-slate-200" : "text-slate-800")}>Usos Sugeridos</h5>
                          <p className={cn("text-xs font-semibold leading-relaxed", darkMode ? "text-slate-400" : "text-slate-500")}>{details.usos}</p>
                        </div>
                      </div>

                      {/* Dilucion */}
                      <div className="flex gap-4 items-start">
                        <div className={cn("p-2.5 rounded-xl shrink-0", darkMode ? "bg-indigo-950/40 text-indigo-400" : "bg-indigo-50 text-indigo-600")}>
                          <Icons.Droplet size={18} />
                        </div>
                        <div>
                          <h5 className={cn("font-extrabold text-xs", darkMode ? "text-slate-200" : "text-slate-800")}>Instrucciones / Dilución</h5>
                          <p className={cn("text-xs font-semibold leading-relaxed", darkMode ? "text-slate-400" : "text-slate-500")}>{details.dilucion}</p>
                        </div>
                      </div>

                      {/* Precauciones */}
                      <div className={cn(
                        "flex gap-4 items-start p-4 rounded-2xl border",
                        darkMode ? "bg-amber-950/20 border-amber-900/30 text-amber-200" : "bg-amber-50/70 border-amber-100/50"
                       )}>
                        <div className={cn("p-2.5 rounded-xl shrink-0", darkMode ? "bg-amber-900 text-amber-300" : "bg-amber-100 text-amber-800")}>
                          <Icons.ShieldAlert size={18} />
                        </div>
                        <div>
                          <h5 className={cn("font-extrabold text-xs", darkMode ? "text-amber-100" : "text-amber-900")}>Precauciones de Seguridad</h5>
                          <p className={cn("text-xs font-semibold leading-relaxed", darkMode ? "text-amber-300" : "text-amber-850/80")}>{details.precauciones}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Ordering System */}
                  <div className={cn("border-t mt-8 pt-6", darkMode ? "border-slate-800" : "border-slate-100")}>
                    {selectedProduct.enStock ? (
                      <>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                          {/* Quantity selector */}
                          <div>
                            <span className="text-[9px] font-black uppercase text-slate-400 block mb-2">Cantidad</span>
                            <div className={cn(
                              "flex items-center inline-flex rounded-2xl p-1 border",
                              darkMode ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-100"
                            )}>
                              <button 
                                disabled={detailQuantity <= 1}
                                onClick={() => setDetailQuantity(prev => Math.max(1, prev - 1))}
                                className={cn(
                                  "p-3 rounded-xl transition-all cursor-pointer font-bold",
                                  darkMode ? "hover:bg-slate-850 text-slate-300" : "hover:bg-white text-slate-700"
                                )}
                              >
                                <Icons.Minus size={16} />
                              </button>
                              <span className={cn("px-6 font-black text-base2", darkMode ? "text-white" : "text-slate-900")}>{detailQuantity}</span>
                              <button 
                                onClick={() => setDetailQuantity(prev => Math.min(99, prev + 1))}
                                className={cn(
                                  "p-3 rounded-xl transition-all cursor-pointer font-bold",
                                  darkMode ? "hover:bg-slate-850 text-slate-300" : "hover:bg-white text-slate-700"
                                )}
                              >
                                <Icons.Plus size={16} />
                              </button>
                            </div>
                          </div>

                          {/* Live Price Calculator */}
                          <div className="text-right">
                            <span className="text-[9px] font-black uppercase text-slate-400 block mb-1">Monto Estimado</span>
                            <span className={cn("text-3xl font-black", darkMode ? "text-white" : "text-slate-900")}>
                              {config.data.currency}{totalPrice}
                            </span>
                            <p className="text-[10px] text-slate-400 font-bold mt-1">({config.data.currency}{numericPrice} c/u)</p>
                          </div>
                        </div>

                        {/* Optional Note with Real-time Length Validation */}
                        <div className="mb-6">
                          <div className="flex justify-between items-center mb-2">
                            <label className="text-[9px] font-black uppercase text-slate-400">
                              Nota adicional o dirección de entrega (opcional)
                            </label>
                            <span className={cn(
                              "text-[10px] font-bold",
                              detailNotes.length > 150 ? "text-red-500 animate-pulse" : "text-slate-400"
                            )}>
                              {detailNotes.length}/150
                            </span>
                          </div>
                          <input 
                            type="text"
                            value={detailNotes}
                            onChange={(e) => setDetailNotes(e.target.value.slice(0, 200))}
                            placeholder="Ej: Entrega por la mañana, o requiere factura..."
                            className={cn(
                              "w-full px-4 py-3 rounded-xl border outline-none font-semibold text-xs leading-relaxed transition-colors",
                              detailNotes.length > 150
                                ? "border-red-500 focus:border-red-605 bg-red-500/5 text-red-500"
                                : darkMode 
                                  ? "bg-slate-950 border-slate-800 text-white focus:border-slate-705" 
                                  : "bg-slate-50 border-slate-100 text-slate-900 focus:border-slate-205"
                            )}
                          />
                          {detailNotes.length > 150 && (
                            <p className="text-[10px] text-red-400 font-bold mt-1.5 flex items-center gap-1">
                              <Icons.ShieldAlert size={12} /> La nota excedió el límite ideal de 150 caracteres para la claridad del pedido.
                            </p>
                          )}
                        </div>

                        {/* Action Buttons Multi-Channel Checkout */}
                        <div className="space-y-3">
                          <div className="flex gap-3">
                            <button 
                              disabled={detailNotes.length > 150}
                              onClick={() => handleOrderDetails(selectedProduct, detailQuantity, detailNotes, "whatsapp")}
                              className="flex-grow bg-emerald-500 hover:bg-emerald-600 text-white py-4 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-95 shadow-lg shadow-emerald-500/15 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed leading-none select-none"
                            >
                              <Icons.MessageCircle size={18} />
                              Pedir por WhatsApp
                            </button>
                            <button 
                              disabled={detailNotes.length > 150}
                              onClick={() => handleOrderDetails(selectedProduct, detailQuantity, detailNotes, "copy")}
                              className={cn(
                                "py-4 px-5 rounded-2xl transition-all border shrink-0 flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.01] active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed select-none text-xs font-black uppercase",
                                darkMode 
                                  ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" 
                                  : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200"
                              )}
                              title="Copiar mensaje directo al portapapeles"
                            >
                              <Icons.Copy size={16} />
                              <span className="hidden sm:inline">Copiar</span>
                            </button>
                          </div>

                          <button 
                            disabled={detailNotes.length > 150}
                            onClick={() => {
                              addToCart(selectedProduct, detailQuantity, detailNotes);
                              setSelectedProduct(null);
                            }}
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-95 shadow-lg shadow-blue-500/15 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed leading-none select-none"
                          >
                            <Icons.ShoppingCart size={18} />
                            Agregar {detailQuantity} al Carrito
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="space-y-4">
                        <div className={cn(
                          "p-4 rounded-2xl border flex items-center gap-3",
                          darkMode ? "bg-slate-950 border-red-950/20 text-red-400" : "bg-red-50 border-red-100 text-red-650"
                        )}>
                          <Icons.Slash size={20} className="shrink-0" />
                          <span className="text-xs font-bold uppercase leading-snug">Este producto no cuenta con stock disponible temporalmente.</span>
                        </div>
                        <button 
                          onClick={() => {
                            const genericMsg = `Hola ${config.brand.name}! Quisiera consultar cuándo ingresará stock del producto *${selectedProduct.nombre}* (ID: #${selectedProduct.id}). ¡Muchas gracias!`;
                            triggerWhatsappMessage(genericMsg);
                            addToast("Abriendo chat para consultar reingreso...", "info");
                          }}
                          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2.5 transition-transform hover:scale-[1.01] active:scale-95 shadow-lg shadow-blue-500/15 cursor-pointer leading-none"
                        >
                          <Icons.MessageCircle size={18} /> Consultar reingreso por WhatsApp
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>

      {/* Add Product Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className={cn(
                "relative w-full max-w-lg rounded-[3rem] shadow-2xl overflow-hidden p-10 border transition-all duration-300",
                darkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-100 text-slate-900"
              )}
            >
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black">Nuevo Producto</h3>
                <button 
                  onClick={() => setShowAddModal(false)} 
                  className={cn(
                    "p-2 rounded-full transition-colors cursor-pointer",
                    darkMode ? "hover:bg-slate-800 text-slate-300" : "hover:bg-slate-100 text-slate-700"
                  )}
                >
                  <Icons.X size={24} />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Nombre del Producto *</label>
                  <input 
                    type="text" 
                    value={newProduct.nombre} 
                    onChange={e => setNewProduct({...newProduct, nombre: e.target.value})}
                    placeholder="Ej: Lavandina 5L"
                    className={cn(
                      "w-full p-4 rounded-2xl border-2 outline-none transition-all font-semibold text-sm",
                      darkMode 
                        ? "bg-slate-950 border-slate-800 text-white focus:border-slate-705" 
                        : "bg-white border-slate-100 text-slate-900 focus:border-slate-300",
                      (!newProduct.nombre.trim()) && "border-red-500/50 dark:border-red-500/30"
                    )}
                  />
                  {!newProduct.nombre.trim() && (
                    <p className="text-red-500 text-[10px] font-bold mt-1.5 flex items-center gap-1.5 animate-pulse-subtle">
                      <Icons.AlertCircle size={12} /> El nombre del producto es obligatorio.
                    </p>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Precio *</label>
                    <input 
                      type="number" 
                      value={newProduct.precio} 
                      onChange={e => setNewProduct({...newProduct, precio: e.target.value})}
                      placeholder="0.00"
                      className={cn(
                        "w-full p-4 rounded-2xl border-2 outline-none transition-all font-semibold text-sm",
                        darkMode 
                          ? "bg-slate-950 border-slate-800 text-white focus:border-slate-705" 
                          : "bg-white border-slate-100 text-slate-900 focus:border-slate-300",
                        (!newProduct.precio.trim() || parseFloat(newProduct.precio) <= 0 || isNaN(parseFloat(newProduct.precio))) && "border-red-500/50 dark:border-red-500/30"
                      )}
                    />
                    {(!newProduct.precio.trim() || parseFloat(newProduct.precio) <= 0 || isNaN(parseFloat(newProduct.precio))) && (
                      <p className="text-red-500 text-[10px] font-bold mt-1.5 flex items-center gap-1.5 animate-pulse-subtle">
                        <Icons.AlertCircle size={12} /> Debe ser un número positivo.
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Categoría</label>
                    <select 
                      value={newProduct.categoria} 
                      onChange={e => setNewProduct({...newProduct, categoria: e.target.value})}
                      className={cn(
                        "w-full p-4 rounded-2xl border-2 outline-none transition-all font-semibold text-sm bg-white",
                        darkMode 
                          ? "bg-slate-950 border-slate-800 text-slate-300 focus:border-slate-705" 
                          : "bg-white border-slate-100 text-slate-900 focus:border-slate-300"
                      )}
                    >
                      <option value="">Seleccionar</option>
                      {categories.filter(c => c !== "Todos").map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Descripción</label>
                  <textarea 
                    value={newProduct.descripcion} 
                    onChange={e => setNewProduct({...newProduct, descripcion: e.target.value})}
                    placeholder="Breve descripción del producto..."
                    className={cn(
                      "w-full p-4 rounded-2xl border-2 outline-none transition-all font-semibold h-32 resize-none text-sm",
                      darkMode 
                        ? "bg-slate-950 border-slate-800 text-white focus:border-slate-705" 
                        : "bg-white border-slate-100 text-slate-900 focus:border-slate-300"
                    )}
                  />
                </div>

                {formError && (
                  <p className="text-red-500 text-xs font-bold flex items-center gap-2">
                    <Icons.AlertCircle size={14} /> {formError}
                  </p>
                )}

                <button 
                  onClick={handleAddProduct}
                  disabled={!newProduct.nombre.trim() || !newProduct.precio.trim() || isNaN(parseFloat(newProduct.precio)) || parseFloat(newProduct.precio) <= 0}
                  className={cn(
                    "w-full py-5 rounded-2xl text-white font-black shadow-lg transition-all mt-4",
                    (!newProduct.nombre.trim() || !newProduct.precio.trim() || isNaN(parseFloat(newProduct.precio)) || parseFloat(newProduct.precio) <= 0)
                      ? "bg-slate-300 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed shadow-none"
                      : "hover:scale-[1.02] active:scale-95 cursor-pointer"
                  )}
                  style={(!newProduct.nombre.trim() || !newProduct.precio.trim() || isNaN(parseFloat(newProduct.precio)) || parseFloat(newProduct.precio) <= 0) ? {} : { backgroundColor: 'var(--secondary)' }}
                >
                  Agregar al Catálogo
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <section className={cn("py-24 px-6 transition-colors duration-300", darkMode ? "bg-slate-950" : "bg-white")}>
        <div className="max-w-7xl mx-auto">
          <div className="bg-slate-900 rounded-[4rem] p-12 md:p-24 relative overflow-hidden text-white">
            <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 pointer-events-none">
              <div className="absolute top-[-20%] right-[-10%] w-[80%] h-[80%] rounded-full blur-[150px]" style={{ backgroundColor: 'var(--secondary)' }}></div>
            </div>
            
            <div className="relative z-10 grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold uppercase mb-8 bg-white/10 text-white border border-white/10">
                  <IconRenderer name={config.reseller.icon} size={14} /> {config.reseller.subtitle}
                </div>
                <h2 className="text-4xl md:text-6xl font-black mb-8 leading-tight">
                  {config.reseller.title}
                </h2>
                <p className="text-xl text-slate-300 mb-12 font-medium leading-relaxed">
                  {config.reseller.description}
                </p>
                <button 
                  onClick={() => handleOrder()}
                  className="bg-white text-slate-900 px-10 py-5 rounded-2xl font-black text-lg shadow-2xl hover:scale-105 transition-all flex items-center gap-3"
                >
                  <Icons.Briefcase size={24} />
                  {config.reseller.buttonText}
                </button>
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white/5 backdrop-blur-sm p-8 rounded-[2.5rem] border border-white/10">
                  <h4 className="text-3xl font-black mb-2 animate-pulse-subtle" style={{ color: 'var(--secondary)' }}>+50</h4>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">Revendedores</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-8 rounded-[2.5rem] border border-white/10 mt-12">
                  <h4 className="text-3xl font-black mb-2 animate-pulse-subtle" style={{ color: 'var(--secondary)' }}>30%</h4>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">Margen Promedio</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-8 rounded-[2.5rem] border border-white/10">
                  <h4 className="text-3xl font-black mb-2 animate-pulse-subtle" style={{ color: '#0052CC' }}>100%</h4>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">Calidad Garantizada</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-8 rounded-[2.5rem] border border-white/10 mt-12">
                  <h4 className="text-3xl font-black mb-2 animate-pulse-subtle" style={{ color: '#0052CC' }}>24hs</h4>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400">Soporte Directo</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-slate-900 py-24 px-6 text-white text-center">
        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-12">
          {config.features.map((f, i) => (
            <div key={i}>
              <div className="bg-white/10 p-5 rounded-3xl mb-6 inline-block">
                <IconRenderer name={f.icon} className="w-8 h-8" style={{ color: 'var(--primary)' }} />
              </div>
              <h4 className="text-xl font-bold mb-3">{f.title}</h4>
              <p className="text-slate-400 text-sm">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className={cn("py-24 px-6 transition-colors duration-300", darkMode ? "bg-slate-900/50" : "bg-slate-50")}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className={cn("text-4xl font-black mb-4", darkMode ? "text-white" : "text-slate-900")}>Preguntas Frecuentes</h2>
            <p className={cn("font-medium", darkMode ? "text-slate-400" : "text-slate-500")}>Todo lo que necesitás saber sobre nuestros productos y envíos.</p>
          </div>
          <div className="space-y-4">
            {config.faq.map((item, i) => (
              <details 
                key={i} 
                className={cn(
                  "group rounded-2xl border overflow-hidden transition-all",
                  darkMode ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-100 text-slate-800"
                )}
              >
                <summary className="flex justify-between items-center p-6 cursor-pointer font-bold list-none">
                  {item.q}
                  <Icons.ChevronDown className="text-slate-400 transition-transform group-open:rotate-180" />
                </summary>
                <div className={cn("px-6 pb-6 text-sm font-medium leading-relaxed p-6", darkMode ? "text-slate-300" : "text-slate-500")}>
                  {item.a}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className={cn("py-24 px-6 transition-colors duration-300", darkMode ? "bg-slate-950" : "bg-white")}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className={cn("text-4xl font-black mb-6", darkMode ? "text-white" : "text-slate-900")}>¿Tenés alguna duda?</h2>
              <p className={cn("mb-10 font-medium", darkMode ? "text-slate-300" : "text-slate-550")}>
                Estamos para asesorarte. Podés visitarnos en nuestro local o contactarnos por cualquiera de nuestros canales digitales.
              </p>
              <div className="space-y-6">
                <div className="flex gap-4 items-start">
                  <div className="p-3 rounded-2xl shadow-sm shrink-0" style={{ backgroundColor: 'var(--primary-light)', color: 'var(--primary)' }}>
                    <Icons.MapPin size={24} />
                  </div>
                  <div>
                    <h4 className={cn("font-bold", darkMode ? "text-slate-200" : "text-slate-900")}>Ubicación</h4>
                    <p className={cn("text-sm", darkMode ? "text-slate-400" : "text-slate-500")}>{config.contact.address}</p>
                    <a href={config.contact.maps} target="_blank" rel="noreferrer" className="text-xs font-black uppercase mt-2 inline-block hover:underline" style={{ color: 'var(--primary)' }}>Ver en Google Maps</a>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="p-3 rounded-2xl shadow-sm shrink-0" style={{ backgroundColor: 'var(--primary-light)', color: 'var(--primary)' }}>
                    <Icons.Clock size={24} />
                  </div>
                  <div>
                    <h4 className={cn("font-bold", darkMode ? "text-slate-200" : "text-slate-900")}>Horarios</h4>
                    <p className={cn("text-sm", darkMode ? "text-slate-400" : "text-slate-500")}>{config.contact.hours}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className={cn(
              "p-10 rounded-[3rem] text-center border transition-colors",
              darkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-100"
            )}>
              <div className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center text-white shadow-xl" style={{ backgroundColor: 'var(--primary)' }}>
                <Icons.Phone size={32} />
              </div>
              <h3 className={cn("text-2xl font-black mb-4", darkMode ? "text-white" : "text-slate-900")}>Llamanos o escribinos</h3>
              <p className={cn("mb-8 text-sm font-medium", darkMode ? "text-slate-400" : "text-slate-500")}>Atención personalizada inmediata por WhatsApp.</p>
              <button 
                onClick={() => handleOrder()}
                className="w-full py-5 rounded-2xl text-white font-black shadow-lg transition-transform hover:scale-[1.02] active:scale-95"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                Enviar Mensaje
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 px-6 bg-slate-900 text-white text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-sky-500 rounded-full blur-[120px]"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500 rounded-full blur-[120px]"></div>
        </div>
        <div className="max-w-3xl mx-auto relative z-10">
          <h2 className="text-4xl md:text-6xl font-black mb-8">¿Listo para equipar tu hogar o empresa?</h2>
          <p className="text-xl text-slate-300 mb-12 font-medium">Hacé tu pedido hoy y recibilo en la puerta de tu casa con la calidad de Sur Cleans.</p>
          <button 
            onClick={() => handleOrder()}
            className="bg-emerald-500 text-white px-12 py-6 rounded-2xl font-black text-xl shadow-2xl shadow-emerald-500/20 hover:scale-105 transition-all flex items-center gap-4 mx-auto animate-pulse-subtle cursor-pointer"
          >
            <Icons.MessageCircle size={28} />
            Hacer Pedido por WhatsApp
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className={cn(
        "border-t pt-24 pb-12 px-6 transition-colors duration-300",
        darkMode ? "bg-slate-950 border-slate-900" : "bg-white border-slate-100"
      )}>
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="space-y-8">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white shadow-md shadow-blue-500/20">
                <Icons.Cpu size={20} className="text-white" />
              </div>
              <span className="text-2xl font-black tracking-tight text-slate-900 dark:text-white font-display">
                clientum<span className="text-blue-500 font-extrabold">.</span>
              </span>
            </div>
            <p className="text-slate-500 font-medium leading-relaxed text-sm">{config.contact.footerDesc}</p>
            <div className="flex gap-4">
              {config.contact.instagram && (
                <a href={config.contact.instagram} target="_blank" rel="noreferrer" className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-slate-400 hover:bg-pink-50 hover:text-pink-500 transition-all shadow-sm",
                  darkMode ? "bg-slate-900 hover:bg-pink-950" : "bg-slate-50"
                )}>
                  <Icons.Instagram size={22} />
                </a>
              )}
              {config.contact.facebook && (
                <a href={config.contact.facebook} target="_blank" rel="noreferrer" className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-slate-400 hover:bg-blue-50 hover:text-blue-600 transition-all shadow-sm",
                  darkMode ? "bg-slate-900 hover:bg-blue-950" : "bg-slate-50"
                )}>
                  <Icons.Facebook size={22} />
                </a>
              )}
              {config.contact.tiktok && (
                <a href={config.contact.tiktok} target="_blank" rel="noreferrer" className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-slate-400 hover:bg-slate-900 hover:text-white transition-all shadow-sm",
                  darkMode ? "bg-slate-900 hover:bg-slate-800" : "bg-slate-50"
                )}>
                  <Icons.Music2 size={22} />
                </a>
              )}
            </div>
          </div>
          
          <div>
            <h4 className="text-xs font-black uppercase text-slate-400 mb-8 tracking-widest">Navegación</h4>
            <ul className={cn("space-y-4 font-bold text-sm", darkMode ? "text-slate-350" : "text-slate-600")}>
              <li><button onClick={() => scrollToSection('top')} className="hover:text-amber-500 transition-colors">Inicio</button></li>
              <li><button onClick={() => scrollToSection('catalogo')} className="hover:text-amber-500 transition-colors">Catálogo</button></li>
              <li><button onClick={() => scrollToSection('faq')} className="hover:text-amber-500 transition-colors">Preguntas Frecuentes</button></li>
              <li><button onClick={() => scrollToSection('contacto')} className="hover:text-amber-500 transition-colors">Contacto</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black uppercase text-slate-400 mb-8 tracking-widest">Contacto</h4>
            <ul className={cn("space-y-6 font-bold text-sm", darkMode ? "text-slate-300" : "text-slate-600")}>
              <li className="flex items-start gap-4">
                <Icons.MapPin size={20} className="shrink-0 mt-1" style={{ color: 'var(--primary)' }} />
                {config.contact.maps ? (
                  <a href={config.contact.maps} target="_blank" rel="noreferrer" className="hover:underline leading-relaxed">
                    {config.contact.address}
                  </a>
                ) : (
                  <span className="leading-relaxed">{config.contact.address}</span>
                )}
              </li>
              <li className="flex items-center gap-4">
                <Icons.Phone size={20} className="shrink-0" style={{ color: 'var(--primary)' }} />
                <span>{config.contact.whatsapp}</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black uppercase text-slate-400 mb-8 tracking-widest">Horarios</h4>
            <div className={cn(
              "p-8 rounded-[2rem] border transition-colors",
              darkMode ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-100"
            )}>
              <div className={cn("flex items-center gap-3 font-black mb-3", darkMode ? "text-white" : "text-slate-900")}>
                <Icons.Clock size={20} style={{ color: 'var(--primary)' }} />
                <span>Atención</span>
              </div>
              <p className={cn("text-sm font-bold leading-relaxed", darkMode ? "text-slate-400" : "text-slate-550")}>{config.contact.hours}</p>
            </div>
          </div>
        </div>
        
        <div className={cn("max-w-7xl mx-auto pt-12 border-t text-center flex flex-col sm:flex-row justify-between items-center gap-4", darkMode ? "border-slate-900" : "border-slate-100")}>
          <p className="text-slate-400 font-bold text-[10px] uppercase tracking-[0.2em]">
            © {new Date().getFullYear()} {config.brand.name} • Fabricación Profesional de Insumos
          </p>

          {userDistance !== null && (
            <div className={cn(
              "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shrink-0 animate-pulse-subtle",
              darkMode ? "bg-emerald-500/10 text-emerald-405 border border-emerald-500/20" : "bg-emerald-50 text-emerald-650 border border-emerald-200"
            )}>
              <Icons.MapPin size={12} className="text-emerald-500" />
              <span>A {userDistance} km de tu ubicación</span>
            </div>
          )}

          <button 
            onClick={() => setShowAdminDashboard(true)} 
            className="text-[10px] text-zinc-500 dark:text-zinc-400 hover:text-blue-500 font-black uppercase tracking-wider flex items-center gap-1.5 cursor-pointer leading-none"
          >
            <Icons.Lock size={12} />
            Acceso Administrador
          </button>
        </div>
      </footer>

      {/* Floating Compare Button */}
      <AnimatePresence>
        {compareList.length >= 2 && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            onClick={() => setShowCompareModal(true)}
            className="fixed bottom-28 right-8 z-[60] py-3 px-5 rounded-full bg-blue-600 hover:bg-blue-700 text-white shadow-2xl transition-all hover:scale-110 active:scale-95 flex items-center gap-2.5 font-bold text-sm shadow-blue-500/20 cursor-pointer animate-pulse-subtle"
          >
            <Icons.Scale size={18} />
            <span>Comparar</span>
            <span className="bg-white text-blue-600 w-5 h-5 rounded-full flex items-center justify-center text-xs font-black">
              {compareList.length}
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Floating WhatsApp */}
      <button 
        onClick={() => handleOrder()}
        className="fixed bottom-8 right-8 z-[60] p-4 rounded-full bg-emerald-500 text-white shadow-2xl transition-all hover:scale-110 active:scale-90 animate-pulse-subtle shadow-emerald-500/20 hover:bg-emerald-600"
      >
        <Icons.MessageCircle size={32} />
      </button>

      {/* Comparative Modal */}
      <AnimatePresence>
        {showCompareModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCompareModal(false)}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-6xl rounded-[2.5rem] shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh] sm:max-h-[85vh]",
                darkMode ? "bg-slate-900 text-white border border-slate-800" : "bg-white text-slate-900 border border-slate-100"
              )}
            >
              {/* Modal Header */}
              <div className={cn(
                "px-8 py-6 flex items-center justify-between border-b shrink-0",
                darkMode ? "border-slate-800" : "border-slate-100"
              )}>
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-500">
                    <Icons.Scale size={20} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black font-display tracking-tight leading-none mb-1">
                      Comparar Productos
                    </h3>
                    <p className="text-xs font-semibold text-slate-400">
                      Comparativa lado a lado de {compareList.length} productos seleccionados.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setCompareList([])}
                    className="text-xs font-bold hover:text-red-500 transition-colors uppercase tracking-wider bg-red-500/10 text-red-500 dark:text-red-400 px-3 py-1.5 rounded-xl cursor-pointer"
                  >
                    Limpiar todo
                  </button>
                  <button
                    onClick={() => setShowCompareModal(false)}
                    className={cn(
                      "p-2.5 rounded-full transition-all cursor-pointer",
                      darkMode ? "hover:bg-slate-800 text-slate-300" : "hover:bg-slate-100 text-slate-700"
                    )}
                    title="Cerrar modal"
                  >
                    <Icons.X size={20} />
                  </button>
                </div>
              </div>

              {/* Modal Body with Horizontal Scroll */}
              <div className="p-8 overflow-y-auto flex-grow select-none">
                <div className="overflow-x-auto pb-4 scrollbar-thin">
                  <div className="min-w-[800px] grid grid-cols-4 gap-6">
                    
                    {/* Row 1: Product general info (cards) */}
                    {/* Corner top-left cell */}
                    <div className="flex flex-col justify-end pb-4 border-r border-slate-150 dark:border-slate-800 pr-4">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Características</span>
                      <h4 className="text-sm font-black text-slate-500 dark:text-slate-400">Atributos</h4>
                    </div>

                    {/* Columns for products */}
                    {compareList.map((product) => {
                      return (
                        <div key={product.id} className="relative flex flex-col p-4 rounded-3xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                          {/* Remove button */}
                          <button
                            onClick={() => handleToggleCompare(product)}
                            className="absolute top-2 right-2 p-1.5 rounded-full bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all cursor-pointer z-10"
                            title="Quitar de la comparación"
                          >
                            <Icons.Trash2 size={13} />
                          </button>

                          <div className="h-28 flex items-center justify-center p-3 mb-3 bg-white dark:bg-slate-900 rounded-2xl overflow-hidden shrink-0">
                            {product.imagen ? (
                              <img src={product.imagen} alt={product.nombre} className="h-full object-contain" referrerPolicy="no-referrer" />
                            ) : (
                              <IconRenderer name={config.brand.iconName} className="w-10 h-10 opacity-20" style={{ color: 'var(--primary)' }} />
                            )}
                          </div>
                          
                          <span className="text-[8px] font-black uppercase text-blue-500 dark:text-blue-400 tracking-wider mb-1">
                            {product.categoria}
                          </span>
                          <h4 className="font-extrabold text-sm line-clamp-2 leading-tight mb-2 min-h-[36px]">
                            {product.nombre}
                          </h4>
                          
                          <button
                            onClick={() => {
                              setShowCompareModal(false);
                              handleOrder(product);
                            }}
                            className="w-full mt-auto py-2 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                          >
                            <Icons.ShoppingCart size={13} />
                            Pedir Producto
                          </button>
                        </div>
                      );
                    })}
                    
                    {/* Fill blank grids if items compared are less than 3 */}
                    {Array.from({ length: Math.max(0, 3 - compareList.length) }).map((_, i) => (
                      <div key={`blank-${i}`} className="hidden md:flex flex-col items-center justify-center p-6 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl opacity-50 bg-slate-50/20 dark:bg-slate-950/10">
                        <Icons.Plus size={18} className="text-slate-300 dark:text-slate-700 mb-1" />
                        <span className="text-[10px] font-bold text-slate-400">Comparar producto</span>
                      </div>
                    ))}

                    {/* Feature comparison rows */}
                    {[
                      {
                        title: "Precio",
                        field: "precio",
                        render: (p: Product) => (
                          <span className="text-xl font-black text-blue-600 dark:text-blue-400">
                            {config.data.currency}{p.precio}
                          </span>
                        ),
                      },
                      {
                        title: "Descripción",
                        field: "descripcion",
                        render: (p: Product) => (
                          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                            {p.descripcion || "Sin descripción disponible."}
                          </span>
                        ),
                      },
                      {
                        title: "Presentación",
                        field: "presentacion",
                        render: (p: Product) => {
                          const details = getProductDetails(p);
                          return (
                            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                              {details.presentacion || "Bidón 5 Litros"}
                            </span>
                          );
                        },
                      },
                      {
                        title: "Usos Sugeridos",
                        field: "usos",
                        render: (p: Product) => {
                          const details = getProductDetails(p);
                          return (
                            <p className="text-xs font-medium text-slate-600 dark:text-slate-300 leading-relaxed">
                              {details.usos}
                            </p>
                          );
                        },
                      },
                      {
                        title: "Dilución",
                        field: "dilucion",
                        render: (p: Product) => {
                          const details = getProductDetails(p);
                          return (
                            <p className="text-xs font-semibold text-sky-600 dark:text-sky-450 bg-sky-50 dark:bg-sky-950/30 px-3 py-1.5 rounded-xl border border-sky-100 dark:border-sky-900/30 w-full text-center">
                              {details.dilucion}
                            </p>
                          );
                        },
                      },
                      {
                        title: "Precauciones",
                        field: "precauciones",
                        render: (p: Product) => {
                          const details = getProductDetails(p);
                          return (
                            <div className="p-3 bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-450 rounded-2xl border border-red-100 dark:border-red-900/20">
                              <p className="text-[11px] font-semibold leading-normal flex gap-1.5 items-start">
                                <Icons.AlertTriangle className="shrink-0 mt-0.5 text-red-500" size={13} />
                                {details.precauciones}
                              </p>
                            </div>
                          );
                        },
                      },
                    ].map((row) => (
                      <React.Fragment key={row.title}>
                        {/* Parameter Label cell */}
                        <div className="py-4 border-t border-r border-slate-150 dark:border-slate-800 flex items-center pr-4">
                          <span className="text-xs font-black uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                            {row.title}
                          </span>
                        </div>

                        {/* Values for each product */}
                        {compareList.map((product) => (
                          <div key={`${product.id}-${row.field}`} className="py-4 border-t border-slate-100 dark:border-slate-800 flex items-center pr-2">
                            {row.render(product)}
                          </div>
                        ))}

                        {/* Blank row spaces */}
                        {Array.from({ length: Math.max(0, 3 - compareList.length) }).map((_, i) => (
                          <div key={`blank-row-${row.field}-${i}`} className="hidden md:block py-4 border-t border-slate-100 dark:border-slate-800" />
                        ))}
                      </React.Fragment>
                    ))}
                    
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modals for Validation error & Order History */}
      {/* Validation Error Modal */}
      <AnimatePresence>
        {validationError && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-950/20 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setValidationError(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-md rounded-[2rem] shadow-2xl overflow-hidden p-8 z-10 text-center border transition-all duration-300",
                darkMode ? "bg-slate-900 border-red-500/20 text-white" : "bg-white border-red-200 text-slate-900"
              )}
            >
              <div className="w-16 h-16 bg-red-100 dark:bg-red-955/20 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <Icons.AlertTriangle size={32} />
              </div>
              <h3 className="text-xl font-black mb-3 text-red-500">Error de Configuración</h3>
              <p className={cn("text-xs font-semibold mb-6 leading-relaxed", darkMode ? "text-slate-300" : "text-slate-500")}>
                {validationError}
              </p>
              <button 
                onClick={() => setValidationError(null)} 
                className="w-full bg-red-500 hover:bg-red-600 text-white py-4 rounded-xl font-black text-xs transition-transform tracking-wider uppercase active:scale-95 cursor-pointer"
              >
                Entendido
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Order History Modal */}
      <AnimatePresence>
        {showHistory && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-slate-950/20 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowHistory(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden z-10 flex flex-col max-h-[85vh] transition-all duration-300",
                darkMode ? "bg-slate-900 text-white" : "bg-white text-slate-900"
              )}
            >
              <div className={cn("p-8 border-b flex justify-between items-center shrink-0", darkMode ? "border-slate-800" : "border-slate-100")}>
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-500">
                    <Icons.History size={22} />
                  </div>
                  <div className="text-left">
                    <h3 className="text-xl font-black leading-none mb-1">Últimos Pedidos</h3>
                    <span className="text-[10px] font-bold text-slate-400">Guardamos los últimos 5 pedidos realizados</span>
                  </div>
                </div>
                <button 
                  onClick={() => setShowHistory(false)} 
                  className={cn("p-2 rounded-full hover:scale-105 transition-all cursor-pointer", darkMode ? "hover:bg-slate-800" : "hover:bg-slate-100")}
                  title="Cerrar"
                >
                  <Icons.X size={22} />
                </button>
              </div>

              <div className="p-8 overflow-y-auto space-y-6 flex-grow">
                {orderHistory.length === 0 ? (
                  <div className="text-center py-16">
                    <Icons.PackageOpen className="w-16 h-16 mx-auto mb-4 opacity-20 text-slate-450 animate-bounce" />
                    <h4 className="font-black text-lg mb-1">Aún no realizaste pedidos</h4>
                    <p className="text-xs text-slate-400 font-semibold max-w-xs mx-auto">Tus últimos 5 pedidos sugeridos por WhatsApp se guardarán aquí para referencia rápida.</p>
                  </div>
                ) : (
                  <div className="space-y-4 text-left">
                    {orderHistory.map((order, idx) => (
                      <div 
                        key={order.id || idx} 
                        className={cn(
                          "p-5 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
                          darkMode ? "bg-slate-950 border-slate-800/80 hover:border-slate-700" : "bg-slate-50 border-slate-100 hover:border-slate-200"
                        )}
                      >
                        <div className="flex gap-4 items-center">
                          <div className={cn("w-14 h-14 rounded-xl overflow-hidden shrink-0 p-1 border flex items-center justify-center", darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100")}>
                            <img src={order.productImage} alt={order.productName} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-sm line-clamp-1">{order.productName}</h4>
                            <p className="text-xs text-slate-400 font-semibold mt-0.5">
                              Cantidad: <span className="text-slate-600 dark:text-slate-350 font-black">{order.cantidad}</span> • Total: <span className="text-emerald-500 font-black">{config.data.currency}{order.total}</span>
                            </p>
                            <span className="text-[9px] font-mono text-slate-400 block mt-1">
                              {new Date(order.timestamp).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' })}
                            </span>
                            {order.notas && (
                              <p className="text-[10px] italic text-slate-400 mt-1 bg-amber-500/5 px-2 py-0.5 rounded border border-amber-500/10 inline-block">
                                Nota: {order.notas}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        <button 
                          onClick={() => {
                            const prod = products.find(p => p.id === order.productId) || {
                              id: order.productId,
                              nombre: order.productName,
                              precio: order.precio,
                              categoria: "",
                              descripcion: "",
                              imagen: order.productImage
                            };
                            handleOrderDetails(prod, order.cantidad, order.notas || "");
                            setShowHistory(false);
                          }}
                          className="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-black px-4 py-2.5 rounded-xl flex items-center gap-2 transition-transform active:scale-95 shadow-lg shadow-emerald-500/10 cursor-pointer self-stretch sm:self-auto justify-center"
                        >
                          <Icons.RefreshCcw size={14} /> Volver a Pedir
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {orderHistory.length > 0 && (
                <div className={cn("p-6 border-t flex justify-end shrink-0", darkMode ? "border-slate-800" : "border-slate-100")}>
                  <button 
                    onClick={() => {
                      if (confirm("¿Estás seguro de que deseas limpiar tu historial de pedidos rápidos?")) {
                        setOrderHistory([]);
                        localStorage.removeItem("orderHistory");
                      }
                    }}
                    className="text-[10px] font-black uppercase tracking-wider text-red-500 hover:text-red-700 transition-colors cursor-pointer"
                  >
                    Limpiar Historial
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Shopping Cart Modal */}
      <AnimatePresence>
        {showCartModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-slate-950/20 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => setShowCartModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} 
              animate={{ opacity: 1, scale: 1, y: 0 }} 
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden p-0 z-10 flex flex-col max-h-[85vh] transition-all duration-300",
                darkMode ? "bg-slate-900 text-white" : "bg-white text-slate-900"
              )}
            >
              {/* Header */}
              <div className={cn("p-8 border-b flex justify-between items-center shrink-0", darkMode ? "border-slate-800" : "border-slate-100")}>
                <div className="flex items-center gap-3 text-left">
                  <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-500">
                    <Icons.ShoppingCart size={22} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black leading-none mb-1">Tu Carrito</h3>
                    <span className="text-[10px] font-bold text-slate-400">Total de artículos: {cartTotalItems}</span>
                  </div>
                </div>
                <button 
                  onClick={() => setShowCartModal(false)} 
                  className={cn("p-2 rounded-full hover:scale-105 transition-all cursor-pointer", darkMode ? "hover:bg-slate-800" : "hover:bg-slate-100")}
                  title="Cerrar Carrito"
                >
                  <Icons.X size={22} />
                </button>
              </div>

              {/* Items List */}
              <div className="p-8 overflow-y-auto space-y-6 flex-grow">
                {cart.length === 0 ? (
                  <div className="text-center py-16">
                    <Icons.ShoppingBag className="w-16 h-16 mx-auto mb-4 opacity-20 text-slate-450 animate-pulse" />
                    <h4 className="font-black text-lg mb-1">Tu carrito está vacío</h4>
                    <p className="text-xs text-slate-400 font-semibold max-w-xs mx-auto mb-6">Explorá el catálogo e ingresá los insumos de desinfección profesional que desees ordenar.</p>
                    <button
                      onClick={() => {
                        setShowCartModal(false);
                        scrollToSection('catalogo');
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-black px-6 py-3 rounded-xl transition-transform active:scale-95 shadow-lg shadow-blue-500/10 cursor-pointer uppercase tracking-wider"
                    >
                      Ir al Catálogo
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4 text-left">
                    {cart.map((item, idx) => {
                      const itemTotal = (parseFloat(item.product.precio) * item.quantity).toLocaleString('es-AR');
                      return (
                        <div 
                          key={item.product.id || idx} 
                          className={cn(
                            "p-5 rounded-2xl border transition-all flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 relative",
                            darkMode ? "bg-slate-950 border-slate-800/80 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                          )}
                        >
                          <div className="flex gap-4 items-center flex-grow">
                            <div className={cn("w-14 h-14 rounded-xl overflow-hidden shrink-0 p-1 border flex items-center justify-center", darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100")}>
                              {item.product.imagen ? (
                                <BlurUpImage src={item.product.imagen} alt={item.product.nombre} className="w-full h-full object-contain" />
                              ) : (
                                <IconRenderer name={config.brand.iconName} className="w-8 h-8 opacity-20" style={{ color: 'var(--primary)' }} />
                              )}
                            </div>
                            <div className="flex-grow min-w-0 pr-4">
                              <span className="text-[8px] font-black uppercase tracking-wider text-blue-500">{item.product.categoria}</span>
                              <h4 className="font-extrabold text-sm line-clamp-1 text-slate-800 dark:text-slate-100">{item.product.nombre}</h4>
                              <p className="text-xs text-slate-400 font-bold mt-0.5">
                                Unitario: <span className="text-slate-600 dark:text-slate-350">{config.data.currency}{item.product.precio}</span>
                              </p>
                              
                              {/* Editable note for each item */}
                              <div className="mt-2 text-left">
                                <input 
                                  type="text"
                                  value={item.notes || ""}
                                  placeholder="Nota para este producto (ej: entrega por la tarde, perfume lavanda...)"
                                  onChange={(e) => {
                                    const updatedCart = [...cart];
                                    updatedCart[idx] = { ...updatedCart[idx], notes: e.target.value };
                                    setCart(updatedCart);
                                  }}
                                  className={cn(
                                    "w-full px-2.5 py-1.5 rounded-lg border outline-none font-semibold text-[10px] leading-relaxed transition-colors",
                                    darkMode 
                                      ? "bg-slate-900 border-slate-800 text-slate-200 focus:border-slate-750" 
                                      : "bg-white border-slate-100 text-slate-700 focus:border-slate-200"
                                  )}
                                />
                              </div>
                            </div>
                          </div>
                          
                          {/* Item Quantity and Actions */}
                          <div className="flex items-center justify-between md:justify-end gap-6 shrink-0 border-t md:border-t-0 pt-3 md:pt-0">
                            <div className={cn(
                              "flex items-center rounded-xl p-0.5 border scale-90",
                              darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-150"
                            )}>
                              <button 
                                onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                                className={cn(
                                  "p-2 rounded-lg transition-all cursor-pointer font-bold",
                                  darkMode ? "hover:bg-slate-800 text-slate-400" : "hover:bg-slate-50 text-slate-600"
                                )}
                              >
                                <Icons.Minus size={12} />
                              </button>
                              <span className={cn("px-4 font-black text-xs", darkMode ? "text-white" : "text-slate-900")}>{item.quantity}</span>
                              <button 
                                onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                                className={cn(
                                  "p-2 rounded-lg transition-all cursor-pointer font-bold",
                                  darkMode ? "hover:bg-slate-800 text-slate-400" : "hover:bg-slate-50 text-slate-600"
                                )}
                              >
                                <Icons.Plus size={12} />
                              </button>
                            </div>

                            <div className="text-right min-w-[80px]">
                              <span className={cn("text-xs text-slate-400 font-bold block")}>Subtotal</span>
                              <span className={cn("text-sm font-black", darkMode ? "text-white" : "text-slate-900")}>
                                {config.data.currency}{itemTotal}
                              </span>
                            </div>

                            <button
                              onClick={() => {
                                removeFromCart(item.product.id);
                                addToast(`"${item.product.nombre}" eliminado del carrito.`, "info");
                              }}
                              className="p-2.5 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-50 hover:text-white transition-all cursor-pointer self-center"
                              title="Eliminar del carrito"
                            >
                              <Icons.Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Checkout Footing Summary */}
              {cart.length > 0 && (
                <div className={cn("p-8 border-t space-y-6 shrink-0", darkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50/50 border-slate-100")}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-black text-slate-450 dark:text-slate-400 uppercase tracking-wider">Subtotal Acumulado</span>
                    <span className={cn("text-3xl font-black", darkMode ? "text-white" : "text-slate-900")}>
                      {config.data.currency}{
                        cart.reduce((total, item) => total + (parseFloat(item.product.precio) * item.quantity), 0).toLocaleString('es-AR')
                      }
                    </span>
                  </div>

                  {/* WhatsApp Order Action */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button 
                      onClick={() => {
                        let msg = `Hola ${config.brand.name}! Quisiera realizar el siguiente pedido acumulado a través del catálogo:\n\n`;
                        msg += `*Detalle de compra:*\n`;
                        cart.forEach((item, index) => {
                          msg += `${index + 1}. *${item.product.nombre}*\n`;
                          msg += `  - Cantidad: *${item.quantity} unidades*\n`;
                          msg += `  - Precio unitario: ${config.data.currency}${item.product.precio}\n`;
                          msg += `  - Subtotal: ${config.data.currency}${(parseFloat(item.product.precio) * item.quantity).toLocaleString('es-AR')}\n`;
                          if (item.notes && item.notes.trim()) {
                            msg += `  - Notas / Detalles: _${item.notes}_\n`;
                          }
                          msg += `\n`;
                        });

                        const grandTotal = cart.reduce((total, item) => total + (parseFloat(item.product.precio) * item.quantity), 0).toLocaleString('es-AR');
                        msg += `*Resumen del Pedido:*\n`;
                        msg += `*Total Estimado:* ${config.data.currency}${grandTotal}\n\n`;
                        msg += `_Por favor, confírmenme disponibilidad para acordar la entrega y el pago. Muchas gracias!_`;

                        // Validate WA before launching
                        const validation = getValidatedWhatsappNumber(config.contact.whatsapp);
                        if (!validation.isValid) {
                          setValidationError(validation.error || "Número de WhatsApp inválido.");
                          return;
                        }

                        triggerWhatsappMessage(msg);

                        // Save all items to fast order history inside local storage
                        cart.forEach(item => {
                          addOrderToHistory(item.product, item.quantity, item.notes || "");
                        });

                        clearCart();
                        setShowCartModal(false);
                        addToast("¡Pedido acumulado enviado a WhatsApp! 🛍️", "success");
                      }}
                      className="flex-grow bg-emerald-500 hover:bg-emerald-600 text-white py-4 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2.5 transition-all hover:scale-[1.01] active:scale-95 shadow-xl shadow-emerald-500/10 cursor-pointer"
                    >
                      <Icons.MessageCircle size={20} />
                      Enviar Pedido por WhatsApp
                    </button>

                    <button 
                      onClick={() => {
                        let msg = `Hola ${config.brand.name}! Quisiera realizar el siguiente pedido acumulado a través del catálogo:\n\n`;
                        msg += `*Detalle de compra:*\n`;
                        cart.forEach((item, index) => {
                          msg += `${index + 1}. *${item.product.nombre}*\n`;
                          msg += `  - Cantidad: *${item.quantity} unidades*\n`;
                          msg += `  - Precio unitario: ${config.data.currency}${item.product.precio}\n`;
                          msg += `  - Subtotal: ${config.data.currency}${(parseFloat(item.product.precio) * item.quantity).toLocaleString('es-AR')}\n`;
                          if (item.notes && item.notes.trim()) {
                            msg += `  - Notas / Detalles: _${item.notes}_\n`;
                          }
                          msg += `\n`;
                        });

                        const grandTotal = cart.reduce((total, item) => total + (parseFloat(item.product.precio) * item.quantity), 0).toLocaleString('es-AR');
                        msg += `*Resumen del Pedido:*\n`;
                        msg += `*Total Estimado:* ${config.data.currency}${grandTotal}\n\n`;
                        msg += `_Por favor, confírmenme disponibilidad para acordar la entrega y el pago. Muchas gracias!_`;

                        navigator.clipboard.writeText(msg);

                        // Save to history too
                        cart.forEach(item => {
                          addOrderToHistory(item.product, item.quantity, item.notes || "");
                        });

                        clearCart();
                        setShowCartModal(false);
                        addToast("Mensaje acumulado copiado al portapapeles. 📋", "success");
                      }}
                      className={cn(
                        "py-4 px-5 rounded-2xl transition-all border shrink-0 flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.01] active:scale-95 font-black uppercase text-xs",
                        darkMode 
                          ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" 
                          : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200"
                      )}
                      title="Copiar pedido acumulado al portapapeles"
                    >
                      <Icons.Copy size={16} />
                      <span>Copiar</span>
                    </button>

                    <button 
                      onClick={handleExportCartPDF}
                      className={cn(
                        "py-4 px-5 rounded-2xl transition-all border shrink-0 flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.01] active:scale-95 font-black uppercase text-xs",
                        darkMode 
                          ? "bg-slate-800 border-slate-700 text-rose-450 hover:bg-slate-700 hover:border-rose-500/50" 
                          : "bg-rose-50 border-rose-100 text-rose-600 hover:bg-rose-100 hover:border-rose-300"
                      )}
                      title="Exportar Comprobante en formato PDF"
                    >
                      <Icons.FileText size={16} />
                      <span>PDF</span>
                    </button>

                    <button 
                      onClick={() => {
                        if (confirm("¿Estás seguro de que deseas vaciar tu carrito?")) {
                          clearCart();
                          addToast("El carrito ha sido vaciado.", "info");
                        }
                      }}
                      className="text-xs font-bold text-red-500 hover:text-red-700 py-3 px-4 rounded-xl text-center transition-colors uppercase shrink-0 cursor-pointer"
                    >
                      Vaciar Carrito
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Admin Dashboard Modal */}
      <AdminDashboard
        products={products}
        orderHistory={orderHistory}
        cart={cart}
        isOpen={showAdminDashboard}
        onClose={() => setShowAdminDashboard(false)}
        config={config}
        darkMode={darkMode}
        addToast={addToast}
        onAddProduct={handleAdminAddProduct}
        onUpdateStock={handleAdminUpdateStock}
        onNotifyPriceDrop={(prod, discount) => {
          triggerBrowserNotification(
            `🔥 ¡Oferta Imperdible!`,
            `El producto "${prod.nombre.toUpperCase()}" bajó a un precio especial de ${config.data.currency}${prod.precio} en SUR CLEANS.`,
            `#id=${prod.id}`
          );
        }}
        onTriggerPushNotification={triggerBrowserNotification}
      />

      {/* Automated CleanBot floating assistant */}
      <Chatbot 
        products={products}
        config={config}
        darkMode={darkMode}
        onSelectProduct={(p) => {
          setSelectedProduct(p);
          setDetailQuantity(1);
          setDetailNotes("");
        }}
        currency={config.data.currency}
      />

      {/* Web Push Configuration Settings Modal */}
      <AnimatePresence>
        {showPushModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} 
              animate={{ opacity: 1, scale: 1, y: 0 }} 
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "relative w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-y-auto max-h-[90vh] p-6 z-10 flex flex-col transition-all duration-300",
                darkMode ? "bg-slate-900 text-white" : "bg-white text-slate-900"
              )}
            >
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-2.5 text-left">
                  <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center shrink-0">
                    <Icons.BellRing size={20} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-tight leading-none mb-1">Alertas Web Push</h3>
                    <span className="text-[10px] text-slate-450 dark:text-slate-350 font-black">CANAL OFICIAL DE DESCUENTOS Y NOVEDADES</span>
                  </div>
                </div>
                <button 
                  onClick={() => setShowPushModal(false)} 
                  className={cn("p-1.5 rounded-full cursor-pointer transition-colors", darkMode ? "hover:bg-slate-800" : "hover:bg-slate-100")}
                >
                  <Icons.X size={18} />
                </button>
              </div>

              <div className="space-y-4 text-left">
                <p className="text-xs text-slate-450 dark:text-slate-350 font-bold leading-relaxed">
                  Activá las notificaciones push de {config.brand.name} para enterarte instantáneamente de nuevos lanzamientos, ofertas express y reingresos en stock de tus favoritos en General Roca.
                </p>

                <div className={cn("p-4 rounded-2xl border flex items-center justify-between gap-4", darkMode ? "bg-slate-950 border-slate-850" : "bg-slate-50 border-slate-150")}>
                  <div className="text-left">
                    <h5 className="text-xs font-black">Estado del Permiso</h5>
                    <p className="text-[10px] text-slate-400 mt-0.5">Permisos del sistema para notificaciones web</p>
                  </div>
                  
                  <span className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-black uppercase",
                    notificationPermission === "granted" 
                      ? "bg-emerald-500/10 text-emerald-500" 
                      : notificationPermission === "denied"
                        ? "bg-red-500/10 text-red-500"
                        : "bg-amber-500/10 text-amber-500"
                  )}>
                    {notificationPermission === "granted" ? "Permitido ✓" : notificationPermission === "denied" ? "Bloqueado ✗" : "Pendiente ?"}
                  </span>
                </div>

                <div className="space-y-2.5 text-left">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block">Suscripciones Preferidas:</span>
                  
                  <label className="flex items-center gap-3 text-xs font-bold p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-850 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded text-blue-500 focus:ring-blue-500" />
                    <div>
                      <span>Nuevos productos en Catálogo</span>
                      <p className="text-[9px] text-slate-400 font-medium">Alertas inmediatas ante incorporaciones mayoristas</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 text-xs font-bold p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-850 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded text-blue-500 focus:ring-blue-500" />
                    <div>
                      <span>Precio y Stock en Favoritos</span>
                      <p className="text-[9px] text-slate-400 font-medium">Alertas cuando baja el valor de tus favoritos o vuelve a haber stock</p>
                    </div>
                  </label>
                </div>

                <div className="pt-4 flex flex-col gap-2.5">
                  <button
                    onClick={() => {
                      if (!("Notification" in window)) {
                        addToast("Este navegador no soporta notificaciones de escritorio.", "error");
                        return;
                      }
                      
                      Notification.requestPermission().then((permission) => {
                        setNotificationPermission(permission);
                        if (permission === 'granted') {
                          addToast("¡Suscrito con éxito a las alertas push! 🔔", "success");
                          triggerBrowserNotification(
                            `🔔 ¡Suscripción Activa!`,
                            `Ya estás registrado de forma segura. Te avisaremos novedades de SUR CLEANS.`
                          );
                        } else {
                          addToast("Permiso de notificaciones rechazado.", "warning");
                        }
                      });
                    }}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-black py-4 px-6 rounded-2xl shadow-lg uppercase tracking-wider transition-all cursor-pointer text-center"
                  >
                    Activar Notificaciones Web Push
                  </button>

                  {notificationPermission === "granted" && (
                    <button
                      onClick={() => {
                        triggerBrowserNotification(
                          "🧪 Prueba de Alerta",
                          "Esta es una prueba de envío correcto de notificaciones push de SUR CLEANS en General Roca."
                        );
                      }}
                      className={cn(
                        "w-full py-2.5 text-[10px] font-black uppercase rounded-xl transition-all border shrink-0 cursor-pointer",
                        darkMode 
                          ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-white" 
                          : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-800"
                      )}
                    >
                      Enviar Notificación Informativa de Prueba
                    </button>
                  )}
                </div>

                {/* Received and Missed Notifications Log History */}
                <div className="space-y-2.5 text-left pt-5 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block">
                      Log de Alertas Recientes
                    </span>
                    {notificationLog.length > 0 && (
                      <button
                        onClick={() => {
                          setNotificationLog([]);
                          localStorage.removeItem("notification_log");
                          addToast("Historial de alertas vaciado correctamente.", "info");
                        }}
                        className="text-[9px] text-rose-500 font-extrabold uppercase hover:underline cursor-pointer select-none"
                      >
                        Limpiar Log
                      </button>
                    )}
                  </div>

                  {notificationLog.length === 0 ? (
                    <div className={cn(
                      "p-5 rounded-2xl text-center border text-[11px] font-bold text-slate-400 border-dashed py-8",
                      darkMode ? "border-slate-800 bg-slate-950/40" : "border-slate-200 bg-slate-50/50"
                    )}>
                      No se registraron alertas omitidas en esta sesión. Las nuevas notificaciones push se almacenarán de forma local aquí.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                      {notificationLog.map((notif) => (
                        <div 
                          key={notif.id}
                          className={cn(
                            "p-3 rounded-2xl border text-xs relative flex flex-col gap-1 transition-colors",
                            darkMode ? "bg-slate-950/65 border-slate-850" : "bg-slate-50/70 border-slate-150"
                          )}
                        >
                          <div className="flex justify-between items-start gap-2">
                            <span className="font-extrabold text-blue-500 dark:text-yellow-405 leading-snug">
                              {notif.title}
                            </span>
                            <span className="text-[9px] text-slate-400 font-extrabold shrink-0">
                              {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-[10px] font-bold leading-relaxed text-slate-450 dark:text-slate-350">
                            {notif.body}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
