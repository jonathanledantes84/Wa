import React from 'react';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Kanban, 
  Users, 
  Bot, 
  Send, 
  BarChart3, 
  Settings, 
  ShieldCheck, 
  Zap, 
  PhoneCall,
  LogOut
} from 'lucide-react';
import { ViewMode, Agent } from '../types';

interface SidebarProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  currentUser: Agent;
  unreadTotal: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  currentView, 
  onViewChange, 
  currentUser,
  unreadTotal
}) => {
  const navItems = [
    { id: 'dashboard' as ViewMode, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'inbox' as ViewMode, label: 'WhatsApp Inbox', icon: MessageSquare, badge: unreadTotal },
    { id: 'pipeline' as ViewMode, label: 'Pipeline de Ventas', icon: Kanban },
    { id: 'segments' as ViewMode, label: 'Clientes y Segmentos', icon: Users },
    { id: 'chatbot' as ViewMode, label: 'Chatbot IA & Reglas', icon: Bot },
    { id: 'campaigns' as ViewMode, label: 'Campañas Masivas', icon: Send },
    { id: 'analytics' as ViewMode, label: 'Analíticas y Reportes', icon: BarChart3 },
    { id: 'settings' as ViewMode, label: 'Configuración', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-[#0B132B] border-r border-[#1C2541] flex flex-col h-screen select-none shrink-0 text-slate-200">
      {/* Brand Header */}
      <div className="p-5 border-b border-[#1C2541] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#091026] border border-slate-700 flex items-center justify-center shadow-lg shadow-emerald-500/10 text-white">
            <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <rect width="24" height="24" rx="6" fill="#0b132b" stroke="none" />
              <path d="M12 4L20 12L12 20L4 12Z" fill="none" stroke="white" strokeWidth="2" />
              <circle cx="12" cy="4" r="2" fill="white" />
              <circle cx="20" cy="12" r="2" fill="white" />
              <circle cx="12" cy="20" r="2" fill="white" />
              <circle cx="4" cy="12" r="2" fill="white" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-lg tracking-tight text-white">Clientum</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-semibold border border-emerald-500/30">PRO</span>
            </div>
            <p className="text-xs text-slate-400">WhatsApp CRM & Ventas</p>
          </div>
        </div>
      </div>

      {/* Connection Status indicator */}
      <div className="mx-4 mt-4 p-3 rounded-xl bg-[#1C2541]/60 border border-[#3A506B]/40 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <div>
            <p className="text-xs font-medium text-white">WhatsApp API Activa</p>
            <p className="text-[10px] text-emerald-400">+54 9 11 8899-0000</p>
          </div>
        </div>
        <PhoneCall className="w-4 h-4 text-emerald-400" />
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                isActive 
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm' 
                  : 'text-slate-300 hover:bg-[#1C2541]/70 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="bg-emerald-500 text-slate-950 font-bold text-xs px-2 py-0.5 rounded-full">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* AI Assistant Quick Pill */}
      <div className="mx-3 mb-3 p-3 rounded-xl bg-gradient-to-r from-indigo-950/80 to-slate-900 border border-indigo-500/30">
        <div className="flex items-center gap-2 mb-1">
          <Bot className="w-4 h-4 text-indigo-400" />
          <span className="text-xs font-semibold text-indigo-300">Clientum IA Activa</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          Analizando sentimientos y derivando leads 24/7 en WhatsApp.
        </p>
      </div>

      {/* User Footer Profile */}
      <div className="p-3.5 border-t border-[#1C2541] bg-[#070d1f] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img 
            src={currentUser.avatar} 
            alt={currentUser.name} 
            className="w-9 h-9 rounded-full object-cover border border-slate-700" 
          />
          <div className="overflow-hidden">
            <h4 className="text-xs font-bold text-white truncate">{currentUser.name}</h4>
            <p className="text-[10px] text-emerald-400 font-medium">{currentUser.role}</p>
          </div>
        </div>
        <button 
          title="Sesión Activa"
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-[#1C2541] transition-colors"
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
        </button>
      </div>
    </aside>
  );
};
