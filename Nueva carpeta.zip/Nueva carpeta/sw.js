const CACHE_NAME = 'surcleans-offline-cache-v1';
const IMAGE_CACHE_NAME = 'surcleans-images-cache-v1';
const DATA_CACHE_NAME = 'surcleans-data-cache-v1';

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/src/main.tsx',
  '/src/index.css',
  '/src/App.tsx',
];

// Instalar Service Worker y almacenar recursos estáticos iniciales
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

// Activar y limpiar cachés antiguas
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (
            cache !== CACHE_NAME &&
            cache !== IMAGE_CACHE_NAME &&
            cache !== DATA_CACHE_NAME
          ) {
            return caches.delete(cache);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Interceptación de solicitudes para funcionamiento sin conexión
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Interceptar datos de la hoja de cálculo (Google Sheets CSV en dataUrls)
  if (url.hostname.includes('docs.google.com') && url.pathname.includes('/spreadsheets/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.status === 200) {
            const responseClone = response.clone();
            caches.open(DATA_CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          // Si falla, servir de la caché
          return caches.match(request);
        })
    );
    return;
  }

  // Interceptar imágenes (Picsum, Google uploads o cualquier formato de imagen)
  const isImage = 
    request.destination === 'image' || 
    url.pathname.match(/\.(png|jpg|jpeg|gif|webp|svg)/i) ||
    url.hostname.includes('picsum.photos') ||
    url.hostname.includes('aistudio.google.com');

  if (isImage) {
    event.respondWith(
      caches.match(request).then((cachedResponse) => {
        if (cachedResponse) {
          // Servir imagen desde caché, pero refrescar de fondo de manera silenciosa
          fetch(request).then((networkResponse) => {
            if (networkResponse.status === 200) {
              caches.open(IMAGE_CACHE_NAME).then((cache) => {
                cache.put(request, networkResponse);
              });
            }
          }).catch(() => {/* Ignorar errores offline silenciosos */});
          
          return cachedResponse;
        }

        return fetch(request).then((networkResponse) => {
          if (networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(IMAGE_CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return networkResponse;
        }).catch(() => {
          // Imagen de respaldo de paquete roto si está offline y no en caché
          return new Response(
            `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>`,
            { headers: { 'Content-Type': 'image/svg+xml' } }
          );
        });
      })
    );
    return;
  }

  // Comportamiento estático por defecto: Stale-While-Revalidate
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request)
        .then((networkResponse) => {
          if (networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // Silenciar errores de fetch offline
        });

      return cachedResponse || fetchPromise;
    })
  );
});

// Listener de eventos para Notificaciones Push simuladas y reales
self.addEventListener('push', (event) => {
  let data = { title: 'SUR CLEANS', body: '¡Hay novedades en el catálogo!' };
  
  if (event.data) {
    try {
      data = event.data.json();
    } catch {
      data = { title: 'SUR CLEANS', body: event.data.text() };
    }
  }

  const options = {
    body: data.body,
    icon: '/favicon.ico', // o icono de fallback de la distribuidora
    badge: '/favicon.ico',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    }
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Evento click de la notificación
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const urlToOpen = event.notification.data ? event.notification.data.url : '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (let i = 0; i < windowClients.length; i++) {
        const client = windowClients[i];
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
