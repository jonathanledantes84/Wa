export interface Product {
  id: string;
  nombre: string;
  precio: string;
  precioAnterior?: string;
  categoria: string;
  descripcion: string;
  imagen?: string;
  stock?: string | number | boolean;
  enStock?: boolean;
  destacado?: boolean;
  cantStock?: number;
}

export interface SheetConfig {
  url: string;
  whatsapp: string;
}
