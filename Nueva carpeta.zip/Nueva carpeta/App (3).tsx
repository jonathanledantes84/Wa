import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { InboxView } from './components/InboxView';
import { PipelineView } from './components/PipelineView';
import { BroadcastsView } from './components/BroadcastsView';
import { TemplateView } from './components/TemplateView';
import { AutomationView } from './components/AutomationView';
import { AnalyticsView } from './components/AnalyticsView';
import { SettingsView } from './components/SettingsView';
import { ErpView } from './components/ErpView';
import { RestaurantView } from './components/RestaurantView';
import { EcommerceView } from './components/EcommerceView';
import { SaaSClusterView } from './components/SaaSClusterView';
import { SaaSThemeView } from './components/SaaSThemeView';
import { AuthModal } from './components/AuthModal';

import {
  initialTenant,
  initialAgents,
  initialLeads,
  initialConversations,
  initialMessages,
  initialTemplates,
  initialCampaigns,
  initialAutomationRules,
  initialAnalytics,
  initialErpItems,
  initialErpSalesOrders,
  initialErpInvoices,
  initialRestaurantTables,
  initialMenuItems,
  initialRestaurantOrders,
  initialEcommerceProducts,
  initialStoreOrders,
  initialSaaSClusterSites,
  initialGeoStatesAndCities,
  initialSaaSThemeConfig,
  initialCurrentSaaSUser
} from './mockData';

import {
  Tenant,
  Agent,
  Lead,
  Conversation,
  WhatsAppMessage,
  WhatsAppTemplate,
  Campaign,
  AutomationRule,
  LeadStage,
  ErpItem,
  ErpSalesOrder,
  ErpInvoice,
  RestaurantTable,
  MenuItem,
  RestaurantOrder,
  RestaurantOrderStatus,
  EcommerceProduct,
  StoreOrder,
  SaaSClusterSite,
  GeoStateCity,
  ClusterSiteStatus,
  SaaSThemeConfig,
  SaaSUserSession
} from './types';

import { Sparkles, X, Send } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('inbox');
  const [tenant, setTenant] = useState<Tenant>(initialTenant);
  const [agents, setAgents] = useState<Agent[]>(initialAgents);
  const [currentAgent, setCurrentAgent] = useState<Agent>(initialAgents[0]);
  const [leads, setLeads] = useState<Lead[]>(initialLeads);
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [messages, setMessages] = useState<Record<string, WhatsAppMessage[]>>(initialMessages);
  const [templates, setTemplates] = useState<WhatsAppTemplate[]>(initialTemplates);
  const [campaigns, setCampaigns] = useState<Campaign[]>(initialCampaigns);
  const [automationRules, setAutomationRules] = useState<AutomationRule[]>(initialAutomationRules);
  const [analytics, setAnalytics] = useState(initialAnalytics);
  const [erpItems, setErpItems] = useState<ErpItem[]>(initialErpItems);
  const [erpSalesOrders, setErpSalesOrders] = useState<ErpSalesOrder[]>(initialErpSalesOrders);
  const [erpInvoices, setErpInvoices] = useState<ErpInvoice[]>(initialErpInvoices);

  const [restaurantTables, setRestaurantTables] = useState<RestaurantTable[]>(initialRestaurantTables);
  const [menuItems, setMenuItems] = useState<MenuItem[]>(initialMenuItems);
  const [restaurantOrders, setRestaurantOrders] = useState<RestaurantOrder[]>(initialRestaurantOrders);

  const [ecommerceProducts, setEcommerceProducts] = useState<EcommerceProduct[]>(initialEcommerceProducts);
  const [storeOrders, setStoreOrders] = useState<StoreOrder[]>(initialStoreOrders);

  const [saasClusterSites, setSaasClusterSites] = useState<SaaSClusterSite[]>(initialSaaSClusterSites);
  const [geoStatesAndCities, setGeoStatesAndCities] = useState<GeoStateCity[]>(initialGeoStatesAndCities);
  const [saasThemeConfig, setSaasThemeConfig] = useState<SaaSThemeConfig>(initialSaaSThemeConfig);

  const [currentUser, setCurrentUser] = useState<SaaSUserSession | null>(initialCurrentSaaSUser);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleLoginSuccess = (user: SaaSUserSession) => {
    setCurrentUser(user);
    // Sync tenant name and agent if applicable
    setTenant(prev => ({ ...prev, name: user.companyName }));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setShowAuthModal(true);
  };

  const [selectedConvId, setSelectedConvId] = useState<string>(initialConversations[0].id);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAiCopilotModal, setShowAiCopilotModal] = useState(false);
  const [aiCustomPrompt, setAiCustomPrompt] = useState('');
  const [aiCustomResult, setAiCustomResult] = useState<string | null>(null);
  const [loadingAiCustom, setLoadingAiCustom] = useState(false);

  // Unread messages sum
  const unreadCountTotal = conversations.reduce((sum, c) => sum + c.unreadCount, 0);

  // Send WhatsApp message handler
  const handleSendMessage = (
    convId: string,
    text: string,
    isNote = false,
    templateName?: string
  ) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newMsg: WhatsAppMessage = {
      id: `msg_${Date.now()}`,
      conversationId: convId,
      sender: isNote ? 'agent' : 'agent',
      senderName: currentAgent.name,
      text,
      type: templateName ? 'template' : 'text',
      timestamp: timeStr,
      status: 'delivered',
      templateName,
      isNote
    };

    setMessages((prev) => ({
      ...prev,
      [convId]: [...(prev[convId] || []), newMsg]
    }));

    // Update conversation preview
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === convId) {
          return {
            ...c,
            lastMessage: isNote ? `[Note]: ${text}` : text,
            lastMessageTimestamp: timeStr,
            unreadCount: 0
          };
        }
        return c;
      })
    );

    // Update tenant credit usage if customer message
    if (!isNote) {
      setTenant((prev) => ({
        ...prev,
        creditsUsed: prev.creditsUsed + 1
      }));
    }

    // Simulate automated customer/lead reply after 2.5 seconds if customer message
    if (!isNote) {
      setTimeout(() => {
        const replyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const autoReplyMsg: WhatsAppMessage = {
          id: `msg_reply_${Date.now()}`,
          conversationId: convId,
          sender: 'lead',
          text: `Thank you ${currentAgent.name}! I received your message regarding our Clientum CRM setup. Let's proceed. 👍`,
          type: 'text',
          timestamp: replyTime,
          status: 'read'
        };

        setMessages((prevMsgs) => ({
          ...prevMsgs,
          [convId]: [...(prevMsgs[convId] || []), autoReplyMsg]
        }));

        setConversations((prevConvs) =>
          prevConvs.map((c) => {
            if (c.id === convId) {
              return {
                ...c,
                lastMessage: autoReplyMsg.text,
                lastMessageTimestamp: replyTime
              };
            }
            return c;
          })
        );
      }, 2500);
    }
  };

  // Lead stage update handler
  const handleUpdateLeadStage = (leadId: string, newStage: LeadStage) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === leadId ? { ...l, stage: newStage } : l))
    );

    setConversations((prev) =>
      prev.map((c) => (c.leadId === leadId ? { ...c, stage: newStage } : c))
    );
  };

  // Assign agent handler
  const handleAssignAgent = (leadId: string, agentId: string) => {
    const ag = agents.find((a) => a.id === agentId);

    setLeads((prev) =>
      prev.map((l) =>
        l.id === leadId
          ? { ...l, assignedAgentId: agentId, assignedAgentName: ag?.name }
          : l
      )
    );

    setConversations((prev) =>
      prev.map((c) =>
        c.leadId === leadId
          ? { ...c, assignedAgentId: agentId, assignedAgentName: ag?.name }
          : c
      )
    );
  };

  // Jump from Lead Pipeline directly into WhatsApp Chat
  const handleSelectLeadForChat = (leadId: string) => {
    const conv = conversations.find((c) => c.leadId === leadId);
    if (conv) {
      setSelectedConvId(conv.id);
      setActiveTab('inbox');
    }
  };

  // Create new Lead handler
  const handleCreateLead = (leadData: Partial<Lead>) => {
    const newLeadId = `lead_${Date.now()}`;
    const newConvId = `conv_${Date.now()}`;

    const newLead: Lead = {
      id: newLeadId,
      name: leadData.name || 'New Lead',
      phone: leadData.phone || '+1 (555) 000-0000',
      email: leadData.email || 'lead@example.com',
      company: leadData.company || 'Individual',
      dealValue: leadData.dealValue || 5000,
      stage: leadData.stage || 'New',
      source: leadData.source || 'WhatsApp',
      assignedAgentId: currentAgent.id,
      assignedAgentName: currentAgent.name,
      tags: leadData.tags || ['Inbound'],
      lastContacted: 'Just now',
      notes: leadData.notes || '',
      score: 80
    };

    const newConv: Conversation = {
      id: newConvId,
      leadId: newLeadId,
      leadName: newLead.name,
      phone: newLead.phone,
      lastMessage: 'Conversation initialized in Clientum CRM.',
      lastMessageTimestamp: 'Just now',
      unreadCount: 0,
      assignedAgentId: currentAgent.id,
      assignedAgentName: currentAgent.name,
      tags: newLead.tags,
      stage: newLead.stage
    };

    const initialSystemMsg: WhatsAppMessage = {
      id: `msg_sys_${Date.now()}`,
      conversationId: newConvId,
      sender: 'system',
      text: `WhatsApp chat session created for ${newLead.name} (${newLead.company}).`,
      type: 'text',
      timestamp: 'Just now',
      status: 'read'
    };

    setLeads((prev) => [newLead, ...prev]);
    setConversations((prev) => [newConv, ...prev]);
    setMessages((prev) => ({ ...prev, [newConvId]: [initialSystemMsg] }));
    setSelectedConvId(newConvId);
  };

  // Launch Campaign
  const handleLaunchCampaign = (cmpData: Partial<Campaign>) => {
    const newCmp: Campaign = {
      id: `cmp_${Date.now()}`,
      name: cmpData.name || 'New Broadcast Campaign',
      templateId: cmpData.templateId || templates[0].id,
      templateName: cmpData.templateName || templates[0].name,
      targetSegment: cmpData.targetSegment || 'All Leads',
      totalRecipients: cmpData.totalRecipients || 500,
      sentCount: cmpData.sentCount || 500,
      deliveredCount: cmpData.deliveredCount || 480,
      readCount: cmpData.readCount || 390,
      repliedCount: cmpData.repliedCount || 95,
      status: 'COMPLETED',
      createdAt: new Date().toISOString().split('T')[0]
    };

    setCampaigns((prev) => [newCmp, ...prev]);
  };

  // Create Template
  const handleCreateTemplate = (tmpl: WhatsAppTemplate) => {
    setTemplates((prev) => [tmpl, ...prev]);
  };

  // Create Automation Rule
  const handleCreateRule = (rule: AutomationRule) => {
    setAutomationRules((prev) => [rule, ...prev]);
  };

  const handleToggleRule = (ruleId: string) => {
    setAutomationRules((prev) =>
      prev.map((r) => (r.id === ruleId ? { ...r, isEnabled: !r.isEnabled } : r))
    );
  };

  // AI Copilot Modal Custom Prompt Submit
  const handleRunAiCopilotPrompt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiCustomPrompt.trim()) return;
    setLoadingAiCustom(true);
    try {
      const response = await fetch('/api/ai/suggest-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatHistory: [{ text: aiCustomPrompt }],
          leadName: 'Prospect',
          agentName: currentAgent.name
        })
      });
      const data = await response.json();
      if (data.suggestions) {
        setAiCustomResult(data.suggestions.join('\n\n'));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAiCustom(false);
    }
  };

  const handleCreateErpSalesOrder = (newOrder: ErpSalesOrder) => {
    setErpSalesOrders((prev) => [newOrder, ...prev]);
  };

  const handleCreateErpItem = (newItem: ErpItem) => {
    setErpItems((prev) => [newItem, ...prev]);
  };

  const handleUpdateTableStatus = (tableId: string, newStatus: RestaurantTable['status']) => {
    setRestaurantTables(prev =>
      prev.map(t => (t.id === tableId ? { ...t, status: newStatus } : t))
    );
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: RestaurantOrderStatus) => {
    setRestaurantOrders(prev =>
      prev.map(o => (o.id === orderId ? { ...o, status: newStatus } : o))
    );
  };

  const handleCreateRestaurantOrder = (newOrder: RestaurantOrder) => {
    setRestaurantOrders(prev => [newOrder, ...prev]);
  };

  const handleToggleMenuItemAvailability = (itemId: string) => {
    setMenuItems(prev =>
      prev.map(m => (m.id === itemId ? { ...m, isAvailable: !m.isAvailable } : m))
    );
  };

  const handleCreateEcommerceProduct = (newProduct: EcommerceProduct) => {
    setEcommerceProducts(prev => [newProduct, ...prev]);
  };

  const handleCreateStoreOrder = (newOrder: StoreOrder) => {
    setStoreOrders(prev => [newOrder, ...prev]);
  };

  const handleCreateClusterSite = (newSite: SaaSClusterSite) => {
    setSaasClusterSites(prev => [newSite, ...prev]);
  };

  const handleUpdateClusterSiteStatus = (siteId: string, status: ClusterSiteStatus) => {
    setSaasClusterSites(prev =>
      prev.map(s => (s.id === siteId ? { ...s, status } : s))
    );
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 font-sans text-slate-100 overflow-hidden antialiased">
      {/* Top Header */}
      <Header
        tenant={tenant}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenAIModal={() => setShowAiCopilotModal(true)}
        activeTab={activeTab}
        currentUser={currentUser}
        onOpenAuthModal={() => setShowAuthModal(true)}
        onLogout={handleLogout}
      />

      {/* Main Body Workspace */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          agents={agents}
          currentAgent={currentAgent}
          setCurrentAgent={setCurrentAgent}
          unreadCountTotal={unreadCountTotal}
        />

        {/* View Router */}
        <main className="flex-1 flex flex-col min-w-0 bg-slate-50 text-slate-900 overflow-hidden">
          {activeTab === 'inbox' && (
            <InboxView
              conversations={conversations}
              messages={messages}
              leads={leads}
              agents={agents}
              templates={templates}
              currentAgent={currentAgent}
              selectedConvId={selectedConvId}
              setSelectedConvId={setSelectedConvId}
              onSendMessage={handleSendMessage}
              onUpdateLeadStage={handleUpdateLeadStage}
              onAssignAgent={handleAssignAgent}
            />
          )}

          {activeTab === 'pipeline' && (
            <PipelineView
              leads={leads}
              agents={agents}
              onUpdateLeadStage={handleUpdateLeadStage}
              onSelectLeadForChat={handleSelectLeadForChat}
              onCreateLead={handleCreateLead}
            />
          )}

          {activeTab === 'erp' && (
            <ErpView
              items={erpItems}
              salesOrders={erpSalesOrders}
              invoices={erpInvoices}
              leads={leads}
              onCreateSalesOrder={handleCreateErpSalesOrder}
              onCreateItem={handleCreateErpItem}
            />
          )}

          {activeTab === 'restaurant' && (
            <RestaurantView
              tables={restaurantTables}
              menuItems={menuItems}
              orders={restaurantOrders}
              onUpdateTableStatus={handleUpdateTableStatus}
              onUpdateOrderStatus={handleUpdateOrderStatus}
              onCreateOrder={handleCreateRestaurantOrder}
              onToggleMenuItemAvailability={handleToggleMenuItemAvailability}
            />
          )}

          {activeTab === 'ecommerce' && (
            <EcommerceView
              products={ecommerceProducts}
              storeOrders={storeOrders}
              onCreateProduct={handleCreateEcommerceProduct}
              onCreateStoreOrder={handleCreateStoreOrder}
            />
          )}

          {activeTab === 'cluster' && (
            <SaaSClusterView
              sites={saasClusterSites}
              geoData={geoStatesAndCities}
              onCreateSite={handleCreateClusterSite}
              onUpdateSiteStatus={handleUpdateClusterSiteStatus}
            />
          )}

          {activeTab === 'theme' && (
            <SaaSThemeView
              themeConfig={saasThemeConfig}
              onUpdateThemeConfig={(newConfig) => setSaasThemeConfig(newConfig)}
            />
          )}

          {activeTab === 'broadcasts' && (
            <BroadcastsView
              campaigns={campaigns}
              templates={templates}
              leads={leads}
              onLaunchCampaign={handleLaunchCampaign}
            />
          )}

          {activeTab === 'templates' && (
            <TemplateView
              templates={templates}
              onCreateTemplate={handleCreateTemplate}
            />
          )}

          {activeTab === 'automation' && (
            <AutomationView
              rules={automationRules}
              templates={templates}
              agents={agents}
              onCreateRule={handleCreateRule}
              onToggleRule={handleToggleRule}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView analytics={analytics} />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              tenant={tenant}
              agents={agents}
              onUpdateTenant={(updated) => setTenant((prev) => ({ ...prev, ...updated }))}
              onUpdateAgents={(updatedAgents) => setAgents(updatedAgents)}
            />
          )}
        </main>
      </div>

      {/* Bottom Operational Activity Bar */}
      <footer className="h-10 bg-slate-900 text-slate-400 px-6 flex items-center justify-between text-[10px] uppercase font-bold tracking-widest shrink-0 border-t border-slate-800">
        <div className="flex gap-6">
          <span>Sistema: En línea</span>
          <span>Procesador Webhook: Activo (id:481)</span>
          <span>Latencia CRM: 12ms</span>
        </div>
        <div className="flex gap-4">
          <span className="text-green-400 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
            Sincronizando 14 documentos...
          </span>
        </div>
      </footer>

      {/* Global AI Copilot Modal Drawer */}
      {showAiCopilotModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-100 flex items-center">
                <Sparkles className="w-4 h-4 mr-2 text-emerald-400 animate-pulse" />
                Copiloto de Ventas IA Gemini
              </h3>
              <button onClick={() => setShowAiCopilotModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Consultá a Gemini IA para redactar mensajes de prospección por WhatsApp, rebatir objeciones de clientes o generar guiones de venta para Clientum CRM.
            </p>

            <form onSubmit={handleRunAiCopilotPrompt} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tu Consulta o Disparador para la IA</label>
                <textarea
                  rows={3}
                  value={aiCustomPrompt}
                  onChange={(e) => setAiCustomPrompt(e.target.value)}
                  placeholder="ej. Redactá un seguimiento amigable por WhatsApp para un cliente que no respondió la propuesta de Clientum CRM en 3 días..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={loadingAiCustom || !aiCustomPrompt.trim()}
                  className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-lg transition"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{loadingAiCustom ? 'Generando...' : 'Generar Orientación IA'}</span>
                </button>
              </div>
            </form>

            {aiCustomResult && (
              <div className="p-3 bg-slate-950 rounded-lg border border-emerald-800/60 text-xs text-emerald-200 space-y-2 max-h-48 overflow-y-auto">
                <p className="font-bold text-emerald-400">Recomendación de la IA:</p>
                <p className="whitespace-pre-wrap">{aiCustomResult}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SaaS User Login & Registration Modal */}
      <AuthModal
        isOpen={showAuthModal || !currentUser}
        onClose={() => setShowAuthModal(false)}
        currentUser={currentUser}
        onLoginSuccess={handleLoginSuccess}
      />
    </div>
  );
}
