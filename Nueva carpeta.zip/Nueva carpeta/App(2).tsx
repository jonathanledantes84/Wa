/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Calendar, Users, Settings, AlignLeft, Send, Search } from 'lucide-react';

export default function App() {
  return (
    <div className="w-full h-screen bg-[#f8fafc] text-[#1e293b] flex flex-col font-sans overflow-hidden">
      {/* Top Navigation Bar */}
      <header className="h-12 bg-white border-b border-slate-200 flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center text-white font-bold text-xs">F</div>
            <span className="font-semibold text-sm tracking-tight">Frappe CRM + Whatomate</span>
          </div>
          <div className="h-4 w-[1px] bg-slate-300"></div>
          <nav className="flex gap-3 text-xs font-medium text-slate-500 uppercase tracking-wider">
            <a href="#" className="text-blue-600 border-b-2 border-blue-600 h-12 flex items-center">Dashboard</a>
            <a href="#" className="h-12 flex items-center hover:text-slate-800">Leads</a>
            <a href="#" className="h-12 flex items-center hover:text-slate-800">Deals</a>
            <a href="#" className="h-12 flex items-center hover:text-slate-800">WhatsApp</a>
            <a href="#" className="h-12 flex items-center hover:text-slate-800">Reports</a>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2" />
            <input type="text" placeholder="Search records..." className="bg-slate-100 border-none rounded pl-7 pr-3 py-1 text-xs w-64 focus:ring-1 focus:ring-blue-500 outline-none" />
          </div>
          <div className="w-8 h-8 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center text-[10px] font-bold">JD</div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar / Module Switcher */}
        <aside className="w-14 bg-[#1e293b] flex flex-col items-center py-4 gap-6 shrink-0">
          <div className="p-2 rounded bg-blue-500/20 text-blue-400 cursor-pointer"><AlignLeft className="w-5 h-5" /></div>
          <div className="p-2 text-slate-400 hover:text-white cursor-pointer"><Calendar className="w-5 h-5" /></div>
          <div className="p-2 text-slate-400 hover:text-white cursor-pointer"><Users className="w-5 h-5" /></div>
          <div className="mt-auto p-2 text-slate-500 cursor-pointer hover:text-slate-300"><Settings className="w-5 h-5" /></div>
        </aside>

        {/* Main Body Content */}
        <main className="flex-1 flex flex-col p-4 gap-4 overflow-hidden">
          {/* Top Stats Grid */}
          <div className="grid grid-cols-4 gap-4 shrink-0">
            <div className="bg-white p-3 rounded border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Total Leads</div>
              <div className="flex items-end justify-between mt-1">
                <div className="text-xl font-bold">1,284</div>
                <div className="text-xs text-green-600 font-medium">+12% ↑</div>
              </div>
            </div>
            <div className="bg-white p-3 rounded border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Active WhatsApp Chats</div>
              <div className="flex items-end justify-between mt-1">
                <div className="text-xl font-bold">42</div>
                <div className="text-xs text-blue-600 font-medium">Live</div>
              </div>
            </div>
            <div className="bg-white p-3 rounded border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Conversion Rate</div>
              <div className="flex items-end justify-between mt-1">
                <div className="text-xl font-bold">18.4%</div>
                <div className="text-xs text-slate-400">Avg 15%</div>
              </div>
            </div>
            <div className="bg-white p-3 rounded border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Avg. Response Time</div>
              <div className="flex items-end justify-between mt-1">
                <div className="text-xl font-bold">14m</div>
                <div className="text-xs text-green-600 font-medium">-4m ↓</div>
              </div>
            </div>
          </div>

          {/* Split Layout: Lead Grid and WhatsApp Panel */}
          <div className="flex-1 flex gap-4 overflow-hidden min-h-0">
            {/* Data Grid Section */}
            <div className="flex-[3] bg-white rounded border border-slate-200 flex flex-col shadow-sm overflow-hidden">
              <div className="p-3 border-b border-slate-100 flex justify-between items-center shrink-0">
                <h2 className="text-xs font-bold text-slate-700 uppercase">Recent Leads & Opportunities</h2>
                <button className="bg-blue-600 hover:bg-blue-700 transition-colors text-white text-[10px] font-bold px-3 py-1.5 rounded cursor-pointer">+ NEW LEAD</button>
              </div>
              <div className="flex-1 overflow-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 sticky top-0 z-10">
                    <tr className="border-b border-slate-200">
                      <th className="p-3 font-semibold text-slate-600">Full Name</th>
                      <th className="p-3 font-semibold text-slate-600">Source</th>
                      <th className="p-3 font-semibold text-slate-600">Status</th>
                      <th className="p-3 font-semibold text-slate-600">Value</th>
                      <th className="p-3 font-semibold text-slate-600 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr className="hover:bg-blue-50/50 transition-colors group">
                      <td className="p-3">
                        <div className="font-medium text-slate-800">Alex Thompson</div>
                        <div className="text-[10px] text-slate-400">alex.t@example.com</div>
                      </td>
                      <td className="p-3">
                        <span className="flex items-center gap-1 text-[10px] text-slate-600 font-medium bg-slate-100 w-fit px-1.5 py-0.5 rounded border border-slate-200">WhatsApp</span>
                      </td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-700 border border-green-200">HOT</span></td>
                      <td className="p-3 font-mono text-slate-600 font-medium">$4,200</td>
                      <td className="p-3 text-right text-blue-500 cursor-pointer font-bold hover:text-blue-700">View</td>
                    </tr>
                    <tr className="hover:bg-blue-50/50 transition-colors group">
                      <td className="p-3">
                        <div className="font-medium text-slate-800">Sarah Connor</div>
                        <div className="text-[10px] text-slate-400">s.connor@cyber.net</div>
                      </td>
                      <td className="p-3">
                        <span className="flex items-center gap-1 text-[10px] text-slate-600 font-medium bg-slate-100 w-fit px-1.5 py-0.5 rounded border border-slate-200">Website</span>
                      </td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700 border border-blue-200">QUALIFIED</span></td>
                      <td className="p-3 font-mono text-slate-600 font-medium">$12,500</td>
                      <td className="p-3 text-right text-blue-500 cursor-pointer font-bold hover:text-blue-700">View</td>
                    </tr>
                    <tr className="hover:bg-blue-50/50 transition-colors group">
                      <td className="p-3">
                        <div className="font-medium text-slate-800">Michael Scott</div>
                        <div className="text-[10px] text-slate-400">m.scott@dunder.com</div>
                      </td>
                      <td className="p-3">
                        <span className="flex items-center gap-1 text-[10px] text-slate-600 font-medium bg-slate-100 w-fit px-1.5 py-0.5 rounded border border-slate-200">WhatsApp</span>
                      </td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-yellow-100 text-yellow-700 border border-yellow-200">FOLLOW UP</span></td>
                      <td className="p-3 font-mono text-slate-600 font-medium">$1,800</td>
                      <td className="p-3 text-right text-blue-500 cursor-pointer font-bold hover:text-blue-700">View</td>
                    </tr>
                    <tr className="hover:bg-blue-50/50 transition-colors group">
                      <td className="p-3">
                        <div className="font-medium text-slate-800">Elena Rodriguez</div>
                        <div className="text-[10px] text-slate-400">elena.rod@global.es</div>
                      </td>
                      <td className="p-3">
                        <span className="flex items-center gap-1 text-[10px] text-slate-600 font-medium bg-slate-100 w-fit px-1.5 py-0.5 rounded border border-slate-200">Referral</span>
                      </td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">NEW</span></td>
                      <td className="p-3 font-mono text-slate-600 font-medium">$5,000</td>
                      <td className="p-3 text-right text-blue-500 cursor-pointer font-bold hover:text-blue-700">View</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="p-2 border-t border-slate-100 bg-slate-50 flex justify-between items-center text-[10px] text-slate-500 shrink-0">
                 <div>Showing 4 of 24 records</div>
                 <div className="flex gap-2">
                   <button className="px-2 py-1 border border-slate-200 hover:bg-slate-100 transition-colors bg-white rounded cursor-pointer font-medium text-slate-600">Prev</button>
                   <button className="px-2 py-1 border border-slate-200 hover:bg-slate-100 transition-colors bg-white rounded cursor-pointer font-medium text-slate-600">Next</button>
                 </div>
              </div>
            </div>

            {/* WhatsApp Feed / Right Panel */}
            <div className="flex-[1.2] bg-[#f0f2f5] rounded border border-slate-200 flex flex-col shadow-sm overflow-hidden">
              <div className="bg-[#075e54] p-3 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#25d366] rounded-full"></div>
                  <span className="text-white text-xs font-bold tracking-wide">WhatsApp Inbox</span>
                </div>
                <div className="text-white/80 text-[10px] uppercase font-bold tracking-wider">Live API</div>
              </div>
              <div className="flex-1 p-3 space-y-4 overflow-y-auto">
                {/* Message Bubble */}
                <div className="space-y-1">
                   <div className="flex justify-between items-center px-1">
                     <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tight">+1 (555) 012-3456</span>
                     <span className="text-[9px] text-slate-400 font-medium">2m ago</span>
                   </div>
                   <div className="bg-white p-2.5 rounded-lg rounded-tl-none shadow-[0_1px_1px_rgba(0,0,0,0.05)] text-xs text-slate-700 leading-relaxed">
                     Hi, I'm interested in the Premium SaaS plan. Can you provide more details?
                   </div>
                </div>
                {/* Message Bubble */}
                <div className="space-y-1">
                   <div className="flex justify-between items-center px-1">
                     <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tight">Julian Baker</span>
                     <span className="text-[9px] text-slate-400 font-medium">14m ago</span>
                   </div>
                   <div className="bg-white p-2.5 rounded-lg rounded-tl-none shadow-[0_1px_1px_rgba(0,0,0,0.05)] text-xs text-slate-700 leading-relaxed">
                     The payment link you sent isn't working for my credit card.
                   </div>
                </div>
                {/* Message Bubble Outgoing */}
                <div className="space-y-1 flex flex-col items-end">
                   <div className="flex justify-between items-center px-1 w-full">
                     <span className="text-[9px] text-slate-400 font-medium">Agent: Mike</span>
                     <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tight">ME</span>
                   </div>
                   <div className="bg-[#dcf8c6] p-2.5 rounded-lg rounded-tr-none shadow-[0_1px_1px_rgba(0,0,0,0.05)] text-xs text-slate-800 max-w-[90%] leading-relaxed">
                     Looking into it now, Julian. One moment.
                   </div>
                </div>
              </div>
              {/* Action Bar */}
              <div className="p-3 border-t border-slate-300 bg-[#f0f2f5] shrink-0">
                <div className="flex items-center gap-2 bg-white rounded-full pr-1.5 pl-4 py-1 border border-slate-300 shadow-sm">
                  <input type="text" placeholder="Type a response..." className="flex-1 bg-transparent border-none text-xs focus:ring-0 outline-none text-slate-700" />
                  <button className="bg-[#25d366] hover:bg-[#20b858] transition-colors p-2 rounded-full text-white cursor-pointer shadow-sm">
                    <Send className="w-3.5 h-3.5 ml-0.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Footer / Pipeline Mini Graph */}
          <div className="h-28 bg-white rounded border border-slate-200 p-3 flex flex-col shadow-sm shrink-0">
             <div className="text-[10px] font-bold text-slate-500 uppercase mb-2 tracking-wider flex justify-between items-center">
               <span>Sales Velocity (Last 10 Days)</span>
               <span className="text-slate-400 font-medium">Total: 48 deals</span>
             </div>
             <div className="flex-1 flex items-end gap-1.5">
               <div className="flex-1 bg-slate-100 hover:bg-slate-200 transition-colors h-[30%] rounded-t border-t border-x border-slate-200"></div>
               <div className="flex-1 bg-slate-100 hover:bg-slate-200 transition-colors h-[45%] rounded-t border-t border-x border-slate-200"></div>
               <div className="flex-1 bg-blue-400 hover:bg-blue-500 transition-colors h-[70%] rounded-t border-t border-x border-blue-500"></div>
               <div className="flex-1 bg-slate-100 hover:bg-slate-200 transition-colors h-[50%] rounded-t border-t border-x border-slate-200"></div>
               <div className="flex-1 bg-slate-100 hover:bg-slate-200 transition-colors h-[40%] rounded-t border-t border-x border-slate-200"></div>
               <div className="flex-1 bg-blue-400 hover:bg-blue-500 transition-colors h-[85%] rounded-t border-t border-x border-blue-500"></div>
               <div className="flex-1 bg-blue-600 hover:bg-blue-700 transition-colors h-[95%] rounded-t shadow-[0_-2px_4px_rgba(37,99,235,0.2)]"></div>
               <div className="flex-1 bg-slate-100 hover:bg-slate-200 transition-colors h-[60%] rounded-t border-t border-x border-slate-200"></div>
               <div className="flex-1 bg-slate-100 hover:bg-slate-200 transition-colors h-[55%] rounded-t border-t border-x border-slate-200"></div>
               <div className="flex-1 bg-blue-400 hover:bg-blue-500 transition-colors h-[75%] rounded-t border-t border-x border-blue-500"></div>
             </div>
          </div>
        </main>
      </div>
    </div>
  );
}

