import React, { useState } from 'react';
import { 
  Kanban as KanbanIcon, 
  Plus, 
  DollarSign, 
  Phone, 
  User, 
  Calendar, 
  MoreVertical, 
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { Deal } from '../types';

interface PipelineViewProps {
  deals: Deal[];
  onUpdateDealStage: (dealId: string, newStage: Deal['stage']) => void;
  onAddDeal: (newDeal: Deal) => void;
}

export const PipelineView: React.FC<PipelineViewProps> = ({
  deals,
  onUpdateDealStage,
  onAddDeal
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [value, setValue] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');

  const stages: { id: Deal['stage']; title: string; color: string }[] = [
    { id: 'nuevo', title: 'Nuevo Lead', color: 'border-cyan-500 text-cyan-400' },
    { id: 'contactado', title: 'Contactado', color: 'border-blue-500 text-blue-400' },
    { id: 'propuesta', title: 'Propuesta Enviada', color: 'border-amber-500 text-amber-400' },
    { id: 'negociacion', title: 'En Negociación', color: 'border-purple-500 text-purple-400' },
    { id: 'ganado', title: 'Cerrado Ganado', color: 'border-emerald-500 text-emerald-400' },
  ];

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !company) return;

    const newDeal: Deal = {
      id: `deal-${Date.now()}`,
      title,
      company,
      value: Number(value) || 5000,
      stage: 'nuevo',
      probability: 30,
      expectedCloseDate: '2026-08-30',
      contactName: contactName || 'Cliente Clientum',
      contactPhone: contactPhone || '+54 9 11 0000-0000'
    };

    onAddDeal(newDeal);
    setTitle('');
    setCompany('');
    setValue('');
    setContactName('');
    setContactPhone('');
    setShowAddModal(false);
  };

  const stageOrder: Deal['stage'][] = ['nuevo', 'contactado', 'propuesta', 'negociacion', 'ganado', 'perdido'];

  const moveStage = (dealId: string, currentStage: Deal['stage'], direction: 'next' | 'prev') => {
    const currentIndex = stageOrder.indexOf(currentStage);
    const targetIndex = direction === 'next' ? currentIndex + 1 : currentIndex - 1;
    if (targetIndex >= 0 && targetIndex < stageOrder.length) {
      onUpdateDealStage(dealId, stageOrder[targetIndex]);
    }
  };

  return (
    <div className="p-8 space-y-6 bg-[#070d1f] min-h-screen text-slate-100 flex flex-col">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs bg-blue-500/10 text-blue-400 font-semibold px-2.5 py-1 rounded-full border border-blue-500/30 flex items-center gap-1.5">
              <KanbanIcon className="w-3.5 h-3.5" /> Pipeline de Ventas Comercial
            </span>
            <span className="text-xs text-slate-400">{deals.length} Oportunidades Totales</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Kanban de Negocios WhatsApp</h1>
          <p className="text-sm text-slate-400">Arrastra o mueve las oportunidades comerciales por cada etapa del embudo.</p>
        </div>

        <button 
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition-all shadow-lg shadow-emerald-600/20 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Nueva Oportunidad
        </button>
      </div>

      {/* Kanban Board Columns */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-5 flex-1 items-start overflow-x-auto pb-6">
        {stages.map((stage) => {
          const columnDeals = deals.filter(d => d.stage === stage.id);
          const columnValue = columnDeals.reduce((sum, d) => sum + d.value, 0);

          return (
            <div key={stage.id} className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-4 flex flex-col min-h-[600px] shadow-xl">
              {/* Column Header */}
              <div className={`pb-3 mb-4 border-b border-[#1C2541] flex items-center justify-between border-l-4 pl-3 ${stage.color}`}>
                <div>
                  <h3 className="text-sm font-bold text-white">{stage.title}</h3>
                  <p className="text-[11px] text-slate-400">{columnDeals.length} trat. • ${columnValue.toLocaleString()}</p>
                </div>
              </div>

              {/* Deals List */}
              <div className="space-y-3.5 flex-1">
                {columnDeals.map((deal) => (
                  <div 
                    key={deal.id}
                    className="p-4 rounded-xl bg-[#1C2541]/50 border border-slate-700/60 hover:border-emerald-500/50 transition-all space-y-3 group shadow-md"
                  >
                    <div className="flex items-start justify-between">
                      <h4 className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors leading-tight">{deal.title}</h4>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded shrink-0">
                        ${deal.value.toLocaleString()}
                      </span>
                    </div>

                    <div className="space-y-1 text-xs text-slate-400">
                      <p className="flex items-center gap-1.5 text-white font-medium">
                        <User className="w-3.5 h-3.5 text-slate-400" /> {deal.company}
                      </p>
                      <p className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-emerald-400" /> {deal.contactPhone}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#1C2541] flex items-center justify-between">
                      <button 
                        onClick={() => moveStage(deal.id, deal.stage, 'prev')}
                        disabled={deal.stage === 'nuevo'}
                        className="p-1 rounded bg-[#1C2541] text-slate-400 hover:text-white disabled:opacity-30"
                        title="Mover atrás"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-[10px] text-slate-400 font-semibold">{deal.probability}% Prob.</span>
                      <button 
                        onClick={() => moveStage(deal.id, deal.stage, 'next')}
                        disabled={deal.stage === 'ganado'}
                        className="p-1 rounded bg-[#1C2541] text-slate-400 hover:text-white disabled:opacity-30"
                        title="Mover adelante"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {columnDeals.length === 0 && (
                  <div className="h-32 flex items-center justify-center text-xs text-slate-500 border border-dashed border-[#1C2541] rounded-xl">
                    Sin tratos en esta etapa
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Deal Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 w-full max-w-lg shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-[#1C2541]">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-400" /> Nueva Oportunidad Comercial
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Título del Trato</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej: Licenciamiento WhatsApp Enterprise"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Empresa / Cliente</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ej: AgroExport del Sur"
                  value={company}
                  onChange={e => setCompany(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Valor Estimado (USD)</label>
                  <input 
                    type="number" 
                    required
                    placeholder="10000"
                    value={value}
                    onChange={e => setValue(e.target.value)}
                    className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Teléfono WhatsApp</label>
                  <input 
                    type="text" 
                    placeholder="+54 9 11..."
                    value={contactPhone}
                    onChange={e => setContactPhone(e.target.value)}
                    className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white text-sm font-medium"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-lg shadow-emerald-600/20"
                >
                  Crear Oportunidad
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
