import React, { useState } from 'react';
import {
  Megaphone,
  Plus,
  Send,
  Users,
  CheckCircle2,
  Eye,
  MessageCircle,
  Sparkles,
  FileText,
  Clock,
  Play,
  Pause,
  AlertCircle,
  BarChart2,
  X
} from 'lucide-react';
import { Campaign, WhatsAppTemplate, Lead } from '../types';

interface BroadcastsViewProps {
  campaigns: Campaign[];
  templates: WhatsAppTemplate[];
  leads: Lead[];
  onLaunchCampaign: (campaign: Partial<Campaign>) => void;
}

export const BroadcastsView: React.FC<BroadcastsViewProps> = ({
  campaigns,
  templates,
  leads,
  onLaunchCampaign
}) => {
  const [showWizard, setShowWizard] = useState(false);
  const [campaignName, setCampaignName] = useState('');
  const [targetSegment, setTargetSegment] = useState('All Qualified Leads');
  const [selectedTemplateId, setSelectedTemplateId] = useState(templates[0]?.id || '');
  const [aiGoalPrompt, setAiGoalPrompt] = useState('Q3 Promotional Discount for CRM upgrades');
  const [loadingAiCopy, setLoadingAiCopy] = useState(false);
  const [generatedCopy, setGeneratedCopy] = useState<any>(null);
  const [isSimulatingDispatch, setIsSimulatingDispatch] = useState(false);
  const [dispatchProgress, setDispatchProgress] = useState(0);

  // Stats calculation
  const totalSent = campaigns.reduce((acc, c) => acc + c.sentCount, 0);
  const totalDelivered = campaigns.reduce((acc, c) => acc + c.deliveredCount, 0);
  const totalRead = campaigns.reduce((acc, c) => acc + c.readCount, 0);
  const totalReplied = campaigns.reduce((acc, c) => acc + c.repliedCount, 0);

  const deliveryRate = totalSent > 0 ? Math.round((totalDelivered / totalSent) * 100) : 0;
  const readRate = totalDelivered > 0 ? Math.round((totalRead / totalDelivered) * 100) : 0;
  const replyRate = totalRead > 0 ? Math.round((totalReplied / totalRead) * 100) : 0;

  const handleGenerateAiCopy = async () => {
    setLoadingAiCopy(true);
    try {
      const response = await fetch('/api/ai/generate-campaign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          campaignGoal: aiGoalPrompt,
          targetAudience: targetSegment,
          tone: 'Persuasive & Engaging'
        })
      });
      const data = await response.json();
      setGeneratedCopy(data);
    } catch (e) {
      console.error('Failed to generate AI broadcast copy', e);
    } finally {
      setLoadingAiCopy(false);
    }
  };

  const handleStartCampaign = () => {
    if (!campaignName) return;
    const selectedTmpl = templates.find((t) => t.id === selectedTemplateId) || templates[0];

    setIsSimulatingDispatch(true);
    setDispatchProgress(10);

    const interval = setInterval(() => {
      setDispatchProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsSimulatingDispatch(false);
          setShowWizard(false);

          onLaunchCampaign({
            name: campaignName,
            templateId: selectedTmpl.id,
            templateName: selectedTmpl.name,
            targetSegment,
            totalRecipients: 850,
            sentCount: 850,
            deliveredCount: 830,
            readCount: 640,
            repliedCount: 120,
            status: 'COMPLETED',
            createdAt: new Date().toISOString().split('T')[0]
          });

          setCampaignName('');
          return 100;
        }
        return prev + 25;
      });
    }, 600);
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-101px)] bg-slate-50 text-slate-900 overflow-y-auto">
      {/* Top Banner Header */}
      <div className="p-4 bg-white border-b border-slate-200 space-y-3 shrink-0 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold text-slate-900 flex items-center">
              <Megaphone className="w-5 h-5 mr-2 text-green-600" />
              Campañas de Difusión por WhatsApp
            </h1>
            <p className="text-xs text-slate-500">
              Envíos masivos de difusión por WhatsApp con plantillas Meta WABA y redactor de contenidos Gemini IA.
            </p>
          </div>

          <button
            onClick={() => setShowWizard(true)}
            className="flex items-center space-x-1.5 bg-green-600 hover:bg-green-700 text-white font-bold text-xs px-4 py-2 rounded transition shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Nueva Campaña de Difusión</span>
          </button>
        </div>

        {/* Global Broadcast Performance Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-1">
          <div className="bg-slate-50 border border-slate-200 p-3 rounded">
            <div className="flex items-center justify-between text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
              <span>Total Enviados</span>
              <Send className="w-4 h-4 text-green-600" />
            </div>
            <p className="text-lg font-extrabold text-slate-900 font-mono mt-1">
              {totalSent.toLocaleString()}
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3 rounded">
            <div className="flex items-center justify-between text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
              <span>Tasa de Entrega</span>
              <CheckCircle2 className="w-4 h-4 text-teal-600" />
            </div>
            <p className="text-lg font-extrabold text-teal-700 font-mono mt-1">
              {deliveryRate}%
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3 rounded">
            <div className="flex items-center justify-between text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
              <span>Tasa de Lectura</span>
              <Eye className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-lg font-extrabold text-blue-700 font-mono mt-1">
              {readRate}%
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3 rounded">
            <div className="flex items-center justify-between text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
              <span>Respuestas y Engagement</span>
              <MessageCircle className="w-4 h-4 text-purple-600" />
            </div>
            <p className="text-lg font-extrabold text-purple-700 font-mono mt-1">
              {replyRate}%
            </p>
          </div>
        </div>
      </div>

      {/* Campaign List Table */}
      <div className="p-4 space-y-4">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center">
          <BarChart2 className="w-4 h-4 mr-1.5 text-green-600" />
          Campañas Activas e Históricas
        </h2>

        <div className="bg-white border border-slate-200 rounded overflow-hidden shadow-sm">
          <table className="w-full text-left text-xs text-slate-800">
            <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-3">Nombre de Campaña</th>
                <th className="p-3">Plantilla Usada</th>
                <th className="p-3">Segmento Destino</th>
                <th className="p-3">Enviados / Recip.</th>
                <th className="p-3">Entregados</th>
                <th className="p-3">Leídos</th>
                <th className="p-3">Respondidos</th>
                <th className="p-3">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {campaigns.map((cmp) => {
                const statusColor =
                  cmp.status === 'COMPLETED'
                    ? 'bg-green-50 text-green-800 border-green-200'
                    : cmp.status === 'RUNNING'
                    ? 'bg-amber-50 text-amber-800 border-amber-200 animate-pulse'
                    : 'bg-slate-100 text-slate-600 border-slate-200';

                const statusText =
                  cmp.status === 'COMPLETED'
                    ? 'COMPLETADA'
                    : cmp.status === 'RUNNING'
                    ? 'EN CURSO'
                    : cmp.status;

                return (
                  <tr key={cmp.id} className="hover:bg-slate-50 transition">
                    <td className="p-3 font-bold text-slate-900">{cmp.name}</td>
                    <td className="p-3 font-mono text-purple-700 font-bold">{cmp.templateName}</td>
                    <td className="p-3 font-medium text-slate-700">{cmp.targetSegment}</td>
                    <td className="p-3 font-mono text-slate-800">
                      {cmp.sentCount} / {cmp.totalRecipients}
                    </td>
                    <td className="p-3 font-mono text-teal-700 font-bold">{cmp.deliveredCount}</td>
                    <td className="p-3 font-mono text-blue-700 font-bold">{cmp.readCount}</td>
                    <td className="p-3 font-mono text-purple-700 font-bold">{cmp.repliedCount}</td>
                    <td className="p-3">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${statusColor}`}>
                        {statusText}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Create Broadcast Campaign Wizard */}
      {showWizard && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center">
                <Megaphone className="w-4 h-4 mr-2 text-green-600" />
                Asistente para Iniciar Difusión de WhatsApp
              </h3>
              <button onClick={() => setShowWizard(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            {isSimulatingDispatch ? (
              <div className="py-8 text-center space-y-4">
                <div className="w-16 h-16 bg-green-100 text-green-700 border-2 border-green-600 rounded-full flex items-center justify-center mx-auto animate-bounce">
                  <Send className="w-8 h-8" />
                </div>
                <h4 className="text-sm font-bold text-slate-900">Enviando difusión mediante la API de Meta Cloud...</h4>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden border border-slate-200 max-w-md mx-auto">
                  <div
                    className="bg-green-600 h-full transition-all duration-300"
                    style={{ width: `${dispatchProgress}%` }}
                  ></div>
                </div>
                <p className="text-xs text-slate-500 font-mono font-bold">{dispatchProgress}% de los envíos completados</p>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                {/* Step 1: Campaign details */}
                <div className="space-y-2">
                  <label className="block text-slate-700 font-semibold">1. Título de la Campaña *</label>
                  <input
                    type="text"
                    required
                    placeholder="ej. Difusión Lanzamiento Nueva Colección"
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded p-2.5 text-slate-800 focus:outline-none focus:border-green-500 font-medium"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-slate-700 font-semibold">2. Segmento de Audiencia Destino</label>
                  <select
                    value={targetSegment}
                    onChange={(e) => setTargetSegment(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded p-2.5 text-slate-800 focus:outline-none focus:border-green-500 font-medium"
                  >
                    <option value="All Qualified Leads">Todos los leads calificados (850 Contactos)</option>
                    <option value="LATAM Leads (Tag: Enterprise)">Segmento Empresas LATAM (420 Contactos)</option>
                    <option value="Inbound WhatsApp Leads">Leads entrantes de WhatsApp (1.250 Contactos)</option>
                  </select>
                </div>

                {/* Step 2: Select Meta Template */}
                <div className="space-y-2">
                  <label className="block text-slate-700 font-semibold">3. Seleccionar Plantilla Aprobada por Meta</label>
                  <select
                    value={selectedTemplateId}
                    onChange={(e) => setSelectedTemplateId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded p-2.5 text-purple-700 font-mono font-bold focus:outline-none focus:border-purple-500"
                  >
                    {templates.map((tmpl) => (
                      <option key={tmpl.id} value={tmpl.id}>
                        {tmpl.name} ({tmpl.category})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Step 3: AI Copywriter generator */}
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 flex items-center">
                      <Sparkles className="w-3.5 h-3.5 mr-1 text-green-600" />
                      Redactor IA Gemini para Difusiones
                    </span>
                    <button
                      type="button"
                      onClick={handleGenerateAiCopy}
                      disabled={loadingAiCopy}
                      className="text-[10px] bg-green-600 hover:bg-green-700 text-white font-bold px-2.5 py-1 rounded transition"
                    >
                      {loadingAiCopy ? 'Generando...' : 'Generar Texto'}
                    </button>
                  </div>

                  <input
                    type="text"
                    placeholder="Ingresá el objetivo u oferta de la difusión ej. 20% de descuento en suscripción anual"
                    value={aiGoalPrompt}
                    onChange={(e) => setAiGoalPrompt(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded p-2 text-slate-800 focus:outline-none font-medium"
                  />

                  {generatedCopy && (
                    <div className="p-2.5 bg-white rounded border border-green-200 text-slate-800 space-y-1 shadow-xs">
                      <p className="font-bold text-green-800">{generatedCopy.headerText}</p>
                      <p className="text-[11px] text-slate-700">{generatedCopy.bodyText}</p>
                      <p className="text-[10px] text-slate-400">{generatedCopy.footerText}</p>
                    </div>
                  )}
                </div>

                {/* Footer Buttons */}
                <div className="pt-2 flex items-center justify-end space-x-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowWizard(false)}
                    className="px-3 py-1.5 rounded text-slate-600 hover:bg-slate-100 font-bold"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleStartCampaign}
                    disabled={!campaignName}
                    className="px-5 py-2 bg-green-600 hover:bg-green-700 text-white font-bold rounded shadow-sm disabled:opacity-50"
                  >
                    🚀 Enviar Difusión Ahora
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
