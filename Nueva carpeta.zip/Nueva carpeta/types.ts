export type ViewMode = 'dashboard' | 'inbox' | 'pipeline' | 'segments' | 'chatbot' | 'campaigns' | 'analytics' | 'settings';

export interface Lead {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  avatar: string;
  status: 'nuevo' | 'contactado' | 'propuesta' | 'negociacion' | 'ganado' | 'perdido';
  value: number;
  assignedAgent: string;
  tags: string[];
  lastContact: string;
  source: 'WhatsApp' | 'Web Chat' | 'Instagram' | 'Referido';
  createdAt: string;
}

export interface Message {
  id: string;
  sender: 'client' | 'agent' | 'bot';
  senderName: string;
  content: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  mediaUrl?: string;
}

export interface Conversation {
  id: string;
  leadId: string;
  leadName: string;
  leadPhone: string;
  avatar: string;
  company: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  assignedAgent: string;
  channel: 'WhatsApp' | 'Instagram' | 'Web';
  sentiment: 'positive' | 'neutral' | 'urgent';
  tags: string[];
  messages: Message[];
  status: 'abierta' | 'en_espera' | 'resuelta';
}

export interface Deal {
  id: string;
  title: string;
  company: string;
  value: number;
  stage: 'nuevo' | 'contactado' | 'propuesta' | 'negociacion' | 'ganado' | 'perdido';
  probability: number;
  expectedCloseDate: string;
  contactName: string;
  contactPhone: string;
}

export interface CustomerSegment {
  id: string;
  name: string;
  description: string;
  filterTag: string;
  leadCount: number;
  color: string;
  createdAt: string;
}

export interface ChatbotRule {
  id: string;
  name: string;
  triggerKeyword: string;
  responseMessage: string;
  enabled: boolean;
  triggerCount: number;
  action: 'auto_reply' | 'assign_agent' | 'tag_lead' | 'send_catalog';
}

export interface Campaign {
  id: string;
  name: string;
  segmentId: string;
  segmentName: string;
  messageTemplate: string;
  status: 'borrador' | 'programada' | 'enviada' | 'en_progreso';
  recipientsCount: number;
  deliveredCount: number;
  responseRate: number;
  scheduledDate: string;
}

export interface Agent {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'Supervisor' | 'Agente Venta';
  avatar: string;
  status: 'online' | 'busy' | 'offline';
  activeChatsCount: number;
  closedDealsThisMonth: number;
}
