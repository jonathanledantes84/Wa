import React, { useState } from 'react';
import { 
  Search, 
  Send, 
  Phone, 
  MoreVertical, 
  Paperclip, 
  Smile, 
  Sparkles, 
  CheckCheck, 
  Clock, 
  Tag, 
  User, 
  Building, 
  CheckCircle2, 
  Bot, 
  Zap,
  Filter,
  BookOpen,
  Plus
} from 'lucide-react';
import { Conversation, Message, Agent } from '../types';

interface InboxViewProps {
  conversations: Conversation[];
  onSendMessage: (conversationId: string, text: string) => void;
  selectedConversationId: string | null;
  onSelectConversation: (id: string) => void;
  agents: Agent[];
}

interface QuickTemplate {
  id: string;
  title: string;
  category: string;
  content: string;
}

export interface ScheduledMessage {
  id: string;
  conversationId: string;
  leadName: string;
  content: string;
  scheduledAt: string;
  status: 'pending' | 'sent' | 'cancelled';
  createdAt: string;
}

export const InboxView: React.FC<InboxViewProps> = ({
  conversations,
  onSendMessage,
  selectedConversationId,
  onSelectConversation,
  agents
}) => {
  const [inputText, setInputText] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterChannel, setFilterChannel] = useState<'all' | 'WhatsApp' | 'Instagram'>('all');
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [templateSearch, setTemplateSearch] = useState('');
  
  // Scheduled messages state
  const [scheduledMessages, setScheduledMessages] = useState<ScheduledMessage[]>([
    {
      id: 'sch-1',
      conversationId: conversations[0]?.id || '1',
      leadName: conversations[0]?.leadName || 'Carlos Mendoza',
      content: 'Hola Carlos, te recuerdo nuestra reunión programada para mañana a las 10:00 AM sobre la implementación de Clientum AI.',
      scheduledAt: '2026-08-02T10:00',
      status: 'pending',
      createdAt: '2026-08-01T14:30'
    },
    {
      id: 'sch-2',
      conversationId: conversations[1]?.id || '2',
      leadName: conversations[1]?.leadName || 'María Fernanda',
      content: 'Estimada María, le enviamos adjunto el plan corporativo con 15% de descuento por pago anual.',
      scheduledAt: '2026-08-02T15:30',
      status: 'pending',
      createdAt: '2026-08-01T15:00'
    }
  ]);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduleDatetime, setScheduleDatetime] = useState('2026-08-02T10:00');
  const [showScheduledListModal, setShowScheduledListModal] = useState(false);
  const [scheduleMessageText, setScheduleMessageText] = useState('');

  // Attachment modal state
  const [showAttachModal, setShowAttachModal] = useState(false);
  const [customFileQuery, setCustomFileQuery] = useState('');
  const [attachments, setAttachments] = useState([
    { id: 'att-1', name: 'Cotizacion_Clientum_PRO_2026.pdf', type: 'PDF Document', size: '2.4 MB', category: 'PDF' },
    { id: 'att-2', name: 'Catalogo_Servicios_WhatsApp_API.pdf', type: 'PDF Brochure', size: '4.1 MB', category: 'PDF' },
    { id: 'att-3', name: 'Logo_Clientum_Corporativo.png', type: 'Image PNG', size: '850 KB', category: 'Imagen' },
    { id: 'att-4', name: 'Plan_Implementacion_CRM.docx', type: 'Word Document', size: '1.2 MB', category: 'Documento' },
    { id: 'att-5', name: 'Tabla_Comparativa_Planes.xlsx', type: 'Excel Spreadsheet', size: '940 KB', category: 'Hoja de Cálculo' }
  ]);
  const [selectedFileName, setSelectedFileName] = useState('');

  const handleSimulateUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customFileQuery.trim()) return;
    const newFile = {
      id: `att-${Date.now()}`,
      name: customFileQuery.trim().endsWith('.pdf') || customFileQuery.trim().endsWith('.png') || customFileQuery.trim().endsWith('.docx') ? customFileQuery.trim() : `${customFileQuery.trim()}.pdf`,
      type: 'Archivo Personalizado',
      size: '1.5 MB',
      category: 'Otro'
    };
    setAttachments([newFile, ...attachments]);
    setCustomFileQuery('');
  };

  const handleOpenScheduleModal = () => {
    if (!inputText.trim()) {
      alert('Por favor escribe un mensaje en la barra de texto antes de programarlo.');
      return;
    }
    setScheduleMessageText(inputText.trim());
    setShowScheduleModal(true);
  };

  const handleConfirmSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scheduleMessageText.trim() || !activeConv) return;
    const newItem: ScheduledMessage = {
      id: `sch-${Date.now()}`,
      conversationId: activeConv.id,
      leadName: activeConv.leadName,
      content: scheduleMessageText.trim(),
      scheduledAt: scheduleDatetime,
      status: 'pending',
      createdAt: new Date().toISOString().slice(0, 16)
    };
    setScheduledMessages([newItem, ...scheduledMessages]);
    setInputText('');
    setScheduleMessageText('');
    setShowScheduleModal(false);
  };
  
  // Custom templates state
  const [templates, setTemplates] = useState<QuickTemplate[]>([
    { id: 't-1', title: 'Cotización PDF formal', category: 'Ventas', content: '¡Hola! Claro que sí, te envío nuestra cotización formal en PDF con todos los planes y descuentos corporativos vigentes.' },
    { id: 't-2', title: 'Agendar Demo 15 min', category: 'Ventas', content: 'Perfecto, agendamos una llamada de demostración de 15 minutos con un especialista. ¿Qué horario te queda cómodo hoy?' },
    { id: 't-3', title: 'Link de pago Mercado Pago', category: 'Cobros', content: 'El link de pago seguro de Mercado Pago está listo para procesar la suscripción mensual de Clientum PRO.' },
    { id: 't-4', title: 'Soporte Técnico prioritario', category: 'Soporte', content: 'Nuestro equipo técnico ya está revisando tu caso con prioridad alta en el servidor de WhatsApp API.' },
    { id: 't-5', title: 'Bienvenida automatizada', category: 'General', content: '¡Hola! Bienvenido a Clientum 🚀. Automatizamos tus ventas y WhatsApp con IA. ¿En qué podemos ayudarte hoy?' }
  ]);

  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('Ventas');
  const [newContent, setNewContent] = useState('');
  const [showAddTemplateForm, setShowAddTemplateForm] = useState(false);

  const activeConv = conversations.find(c => c.id === (selectedConversationId || conversations[0]?.id)) || conversations[0];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeConv) return;
    onSendMessage(activeConv.id, inputText.trim());
    setInputText('');
  };

  const filteredConversations = conversations.filter(c => {
    const matchesSearch = c.leadName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.lastMessage.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesChannel = filterChannel === 'all' || c.channel === filterChannel;
    return matchesSearch && matchesChannel;
  });

  const handleAddTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;
    const item: QuickTemplate = {
      id: `t-${Date.now()}`,
      title: newTitle.trim(),
      category: newCategory,
      content: newContent.trim()
    };
    setTemplates([item, ...templates]);
    setNewTitle('');
    setNewContent('');
    setShowAddTemplateForm(false);
  };

  const filteredTemplates = templates.filter(t => 
    t.title.toLowerCase().includes(templateSearch.toLowerCase()) ||
    t.content.toLowerCase().includes(templateSearch.toLowerCase()) ||
    t.category.toLowerCase().includes(templateSearch.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-[#070d1f] text-slate-100 overflow-hidden">
      {/* Left Chat List Sidebar */}
      <div className="w-80 md:w-96 border-r border-[#1C2541] bg-[#0B132B] flex flex-col shrink-0">
        {/* Header */}
        <div className="p-4 border-b border-[#1C2541]">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              WhatsApp Inbox
            </h2>
            <span className="text-xs bg-emerald-500/10 text-emerald-400 font-semibold px-2 py-0.5 rounded border border-emerald-500/20">
              {conversations.length} Activos
            </span>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Buscar por cliente, empresa o mensaje..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#1C2541]/70 border border-slate-700/60 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Channel Filters */}
          <div className="flex gap-2 mt-3">
            {(['all', 'WhatsApp', 'Instagram'] as const).map((ch) => (
              <button
                key={ch}
                onClick={() => setFilterChannel(ch)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                  filterChannel === ch 
                    ? 'bg-emerald-500 text-slate-950 font-bold' 
                    : 'bg-[#1C2541] text-slate-400 hover:text-white'
                }`}
              >
                {ch === 'all' ? 'Todos' : ch}
              </button>
            ))}
          </div>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#1C2541]/40">
          {filteredConversations.map((conv) => {
            const isSelected = activeConv?.id === conv.id;
            return (
              <div
                key={conv.id}
                onClick={() => onSelectConversation(conv.id)}
                className={`p-3.5 cursor-pointer transition-all flex items-start gap-3 relative ${
                  isSelected ? 'bg-[#1C2541]/80 border-l-4 border-emerald-500' : 'hover:bg-[#1C2541]/30'
                }`}
              >
                <div className="relative shrink-0">
                  <img src={conv.avatar} alt={conv.leadName} className="w-12 h-12 rounded-full object-cover border border-slate-700" />
                  <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#0B132B] ${
                    conv.channel === 'WhatsApp' ? 'bg-emerald-500' : 'bg-pink-500'
                  }`}></span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-bold text-white truncate">{conv.leadName}</h4>
                    <span className="text-[10px] text-slate-400 shrink-0">{conv.lastMessageTime}</span>
                  </div>
                  <p className="text-xs text-slate-400 truncate mb-1.5">{conv.lastMessage}</p>
                  
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">{conv.company}</span>
                    {conv.sentiment === 'positive' && (
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded">✨ Positivo</span>
                    )}
                    {conv.sentiment === 'urgent' && (
                      <span className="text-[10px] bg-rose-500/10 text-rose-400 px-1.5 py-0.5 rounded">⚡ Urgente</span>
                    )}
                  </div>
                </div>

                {conv.unreadCount > 0 && (
                  <span className="absolute right-3 top-8 w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold text-[10px] flex items-center justify-center">
                    {conv.unreadCount}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Center Chat Window */}
      {activeConv ? (
        <div className="flex-1 flex flex-col bg-[#070d1f]">
          {/* Chat Header */}
          <div className="p-4 bg-[#0B132B] border-b border-[#1C2541] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={activeConv.avatar} alt={activeConv.leadName} className="w-10 h-10 rounded-full object-cover border border-slate-700" />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white">{activeConv.leadName}</h3>
                  <span className="text-xs text-emerald-400 font-medium">({activeConv.leadPhone})</span>
                </div>
                <p className="text-xs text-slate-400">{activeConv.company} • Asignado a: <span className="text-white font-medium">{activeConv.assignedAgent}</span></p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowScheduledListModal(true)}
                className="px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-xs text-amber-400 font-medium border border-amber-500/30 transition-all flex items-center gap-1.5"
              >
                <Clock className="w-3.5 h-3.5" /> Programados ({scheduledMessages.filter(m => m.status === 'pending').length})
              </button>
              <span className="text-xs bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full border border-emerald-500/20 font-medium flex items-center gap-1.5">
                <Bot className="w-3.5 h-3.5 text-emerald-400" /> IA Copilot Activo
              </span>
              <button className="p-2 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white">
                <Phone className="w-4 h-4 text-emerald-400" />
              </button>
              <button className="p-2 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white">
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Container */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#070d1f] bg-[radial-gradient(#1c2541_1px,transparent_1px)] [background-size:24px_24px]">
            {activeConv.messages.map((msg) => {
              const isAgent = msg.sender === 'agent';
              const isBot = msg.sender === 'bot';
              return (
                <div 
                  key={msg.id}
                  className={`flex flex-col ${isAgent || isBot ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-center gap-1.5 mb-1 px-1">
                    <span className="text-[10px] text-slate-400 font-medium">{msg.senderName}</span>
                    <span className="text-[10px] text-slate-500">• {msg.timestamp}</span>
                  </div>

                  <div 
                    className={`max-w-lg rounded-2xl px-4 py-3 text-sm shadow-md ${
                      isAgent 
                        ? 'bg-emerald-600 text-white rounded-br-sm' 
                        : isBot
                        ? 'bg-indigo-950/80 border border-indigo-500/40 text-indigo-100 rounded-br-sm'
                        : 'bg-[#1C2541] text-slate-100 border border-slate-700/60 rounded-bl-sm'
                    }`}
                  >
                    <p className="leading-relaxed">{msg.content}</p>
                  </div>

                  <div className="flex items-center gap-1 mt-1 px-1 text-[10px] text-slate-500">
                    {isAgent && <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />}
                    <span>{msg.status}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Canned Replies */}
          <div className="px-6 py-2 bg-[#0B132B]/80 border-t border-[#1C2541] flex items-center justify-between gap-2 overflow-x-auto">
            <div className="flex gap-2 items-center overflow-x-auto py-1">
              {templates.slice(0, 3).map((tpl) => (
                <button
                  key={tpl.id}
                  onClick={() => onSendMessage(activeConv.id, tpl.content)}
                  className="px-3 py-1.5 rounded-lg bg-[#1C2541] hover:bg-[#253258] text-xs text-slate-300 hover:text-white whitespace-nowrap border border-slate-700/60 transition-all flex items-center gap-1.5"
                >
                  <Sparkles className="w-3 h-3 text-emerald-400" /> {tpl.title}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowTemplateModal(true)}
              className="px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-xs text-emerald-400 font-semibold border border-emerald-500/30 whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0"
            >
              <BookOpen className="w-3.5 h-3.5" /> Biblioteca de Respuestas ({templates.length})
            </button>
          </div>

          {/* Input Box */}
          <form onSubmit={handleSend} className="p-4 bg-[#0B132B] border-t border-[#1C2541] flex items-center gap-3">
            <button 
              type="button" 
              onClick={() => setShowTemplateModal(true)}
              title="Biblioteca de Respuestas Rápidas"
              className="p-2.5 text-emerald-400 hover:text-emerald-300 rounded-xl bg-emerald-500/10 border border-emerald-500/30 transition-colors flex items-center gap-1 text-xs font-semibold px-3"
            >
              <BookOpen className="w-4 h-4" /> Respuestas
            </button>
            <button 
              type="button" 
              onClick={handleOpenScheduleModal}
              title="Programar mensaje para más tarde"
              className="p-2.5 text-amber-400 hover:text-amber-300 rounded-xl bg-amber-500/10 border border-amber-500/30 transition-colors flex items-center gap-1 text-xs font-semibold px-3"
            >
              <Clock className="w-4 h-4" /> Programar
            </button>
            <button 
              type="button" 
              onClick={() => setShowAttachModal(true)}
              title="Adjuntar archivo o documento"
              className="p-2.5 text-slate-400 hover:text-white rounded-xl bg-[#1C2541] border border-slate-700 transition-colors flex items-center gap-1.5"
            >
              <Paperclip className="w-5 h-5 text-emerald-400" />
            </button>
            <input 
              type="text" 
              placeholder="Escribe un mensaje de WhatsApp o usa una respuesta rápida..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 bg-[#1C2541]/70 border border-slate-700/80 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
            <button type="button" className="p-2.5 text-slate-400 hover:text-white rounded-xl bg-[#1C2541] transition-colors">
              <Smile className="w-5 h-5" />
            </button>
            <button 
              type="submit"
              className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-all shadow-lg shadow-emerald-600/20 flex items-center gap-2"
            >
              <Send className="w-4 h-4" /> Enviar
            </button>
          </form>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-slate-400">
          Selecciona una conversación para comenzar
        </div>
      )}

      {/* Quick Response Library Modal */}
      {showTemplateModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-[#1C2541] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Biblioteca de Respuestas Rápidas</h3>
                  <p className="text-xs text-slate-400">Selecciona o inserta plantillas prediseñadas para agilizar la atención por WhatsApp</p>
                </div>
              </div>
              <button 
                onClick={() => setShowTemplateModal(false)}
                className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-[#1C2541]"
              >
                ✕
              </button>
            </div>

            {/* Modal Search & Add Toggle */}
            <div className="p-5 border-b border-[#1C2541] bg-[#070d1f] flex flex-col sm:flex-row gap-3 items-center justify-between">
              <div className="relative w-full sm:w-80">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Buscar plantilla por título o contenido..."
                  value={templateSearch}
                  onChange={e => setTemplateSearch(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <button
                onClick={() => setShowAddTemplateForm(!showAddTemplateForm)}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-all shadow-md flex items-center justify-center gap-1.5 shrink-0"
              >
                <Plus className="w-4 h-4" /> {showAddTemplateForm ? 'Cancelar' : 'Nueva Plantilla'}
              </button>
            </div>

            {/* Add New Template Form */}
            {showAddTemplateForm && (
              <form onSubmit={handleAddTemplate} className="p-5 bg-[#070d1f]/90 border-b border-[#1C2541] space-y-4">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Crear Nueva Plantilla de Respuesta</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">Título de la Plantilla</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ej: Seguimiento de Presupuesto"
                      value={newTitle}
                      onChange={e => setNewTitle(e.target.value)}
                      className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">Categoría</label>
                    <select
                      value={newCategory}
                      onChange={e => setNewCategory(e.target.value)}
                      className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                    >
                      <option value="Ventas">Ventas</option>
                      <option value="Cobros">Cobros</option>
                      <option value="Soporte">Soporte</option>
                      <option value="General">General</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">Contenido del Mensaje</label>
                  <textarea 
                    rows={3}
                    required
                    placeholder="Escribe el texto de la respuesta rápida..."
                    value={newContent}
                    onChange={e => setNewContent(e.target.value)}
                    className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  ></textarea>
                </div>
                <div className="flex justify-end gap-2">
                  <button 
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow"
                  >
                    Guardar Plantilla
                  </button>
                </div>
              </form>
            )}

            {/* Template List */}
            <div className="flex-1 overflow-y-auto p-5 space-y-3.5 divide-y divide-[#1C2541]/50">
              {filteredTemplates.map((tpl) => (
                <div key={tpl.id} className="pt-3.5 first:pt-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4 group">
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">{tpl.title}</h4>
                      <span className="text-[10px] bg-[#1C2541] text-emerald-400 px-2 py-0.5 rounded border border-slate-700 font-medium">{tpl.category}</span>
                    </div>
                    <p className="text-xs text-slate-300 bg-[#1C2541]/40 p-3 rounded-xl border border-slate-700/60 leading-relaxed font-mono">
                      "{tpl.content}"
                    </p>
                  </div>

                  <div className="flex sm:flex-col gap-2 shrink-0">
                    <button
                      onClick={() => {
                        setInputText(tpl.content);
                        setShowTemplateModal(false);
                      }}
                      className="px-3.5 py-2 rounded-xl bg-[#1C2541] hover:bg-[#253258] text-xs text-white font-semibold transition-all border border-slate-700 flex items-center justify-center gap-1.5"
                    >
                      Copiar a Input
                    </button>
                    <button
                      onClick={() => {
                        if (activeConv) {
                          onSendMessage(activeConv.id, tpl.content);
                          setShowTemplateModal(false);
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs text-white font-semibold transition-all shadow-md flex items-center justify-center gap-1.5"
                    >
                      <Send className="w-3 h-3" /> Enviar Directo
                    </button>
                  </div>
                </div>
              ))}

              {filteredTemplates.length === 0 && (
                <div className="py-12 text-center text-slate-500 text-xs">
                  No se encontraron plantillas con ese criterio.
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-[#070d1f] border-t border-[#1C2541] flex items-center justify-between text-xs text-slate-400">
              <span>{filteredTemplates.length} plantillas disponibles</span>
              <button 
                onClick={() => setShowTemplateModal(false)}
                className="px-4 py-2 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Message Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl w-full max-w-lg shadow-2xl flex flex-col overflow-hidden">
            <div className="p-5 border-b border-[#1C2541] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Programar Mensaje para Más Tarde</h3>
                  <p className="text-xs text-slate-400">Destinatario: <span className="text-emerald-400 font-medium">{activeConv?.leadName}</span></p>
                </div>
              </div>
              <button 
                onClick={() => setShowScheduleModal(false)}
                className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-[#1C2541]"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmSchedule} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Contenido del Mensaje</label>
                <textarea 
                  rows={3}
                  value={scheduleMessageText}
                  onChange={(e) => setScheduleMessageText(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                  required
                ></textarea>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Fecha y Hora de Envío Programado</label>
                <div className="relative">
                  <input 
                    type="datetime-local" 
                    value={scheduleDatetime}
                    onChange={(e) => setScheduleDatetime(e.target.value)}
                    className="w-full bg-[#1C2541] border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">El mensaje se enviará automáticamente en la fecha y hora seleccionada a través de la API de WhatsApp.</p>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-[#1C2541]">
                <button 
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="px-4 py-2 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white text-xs font-medium"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shadow flex items-center gap-1.5"
                >
                  <Clock className="w-3.5 h-3.5" /> Confirmar Programación
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Scheduled Messages Queue Modal */}
      {showScheduledListModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-5 border-b border-[#1C2541] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Cola de Mensajes Programados</h3>
                  <p className="text-xs text-slate-400">Mensajes listos para entregarse de forma automática</p>
                </div>
              </div>
              <button 
                onClick={() => setShowScheduledListModal(false)}
                className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-[#1C2541]"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-3.5 divide-y divide-[#1C2541]/50">
              {scheduledMessages.map((item) => (
                <div key={item.id} className="pt-3.5 first:pt-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white">{item.leadName}</h4>
                      <span className="text-[10px] bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded border border-amber-500/30 font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Programado: {item.scheduledAt.replace('T', ' ')}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 bg-[#1C2541]/50 p-3 rounded-xl border border-slate-700/60 font-mono">
                      "{item.content}"
                    </p>
                    <div className="text-[10px] text-slate-500">Creado el {item.createdAt}</div>
                  </div>

                  <div className="flex sm:flex-col gap-2 shrink-0">
                    <button
                      onClick={() => {
                        onSendMessage(item.conversationId, item.content);
                        setScheduledMessages(scheduledMessages.filter(m => m.id !== item.id));
                      }}
                      className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs text-white font-semibold transition-all shadow flex items-center justify-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" /> Enviar Ahora
                    </button>
                    <button
                      onClick={() => {
                        setScheduledMessages(scheduledMessages.filter(m => m.id !== item.id));
                      }}
                      className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-xs text-rose-400 font-semibold transition-all border border-rose-500/30 flex items-center justify-center gap-1.5"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              ))}

              {scheduledMessages.length === 0 && (
                <div className="py-12 text-center text-slate-500 text-xs">
                  No hay mensajes programados en la cola actualmente.
                </div>
              )}
            </div>

            <div className="p-4 bg-[#070d1f] border-t border-[#1C2541] flex items-center justify-between text-xs text-slate-400">
              <span>{scheduledMessages.length} en la cola de envío</span>
              <button 
                onClick={() => setShowScheduledListModal(false)}
                className="px-4 py-2 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* File Picker & Attachment Modal */}
      {showAttachModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-5 border-b border-[#1C2541] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  <Paperclip className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Biblioteca de Archivos y Documentos</h3>
                  <p className="text-xs text-slate-400">Selecciona imágenes, PDFs o documentos para adjuntar a la conversación con <span className="text-emerald-400 font-medium">{activeConv?.leadName}</span></p>
                </div>
              </div>
              <button 
                onClick={() => setShowAttachModal(false)}
                className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-[#1C2541]"
              >
                ✕
              </button>
            </div>

            {/* Simulated Upload Bar */}
            <form onSubmit={handleSimulateUpload} className="p-5 border-b border-[#1C2541] bg-[#070d1f] flex gap-3 items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Simular subir archivo (ej: Factura_Marzo.pdf, Contrato.docx)..."
                  value={customFileQuery}
                  onChange={(e) => setCustomFileQuery(e.target.value)}
                  className="w-full bg-[#1C2541] border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-all shadow-md flex items-center gap-1.5 shrink-0"
              >
                <Plus className="w-4 h-4" /> Agregar Archivo
              </button>
            </form>

            {/* Attachment List */}
            <div className="flex-1 overflow-y-auto p-5 space-y-3 divide-y divide-[#1C2541]/50">
              {attachments.map((file) => (
                <div key={file.id} className="pt-3 first:pt-0 flex items-center justify-between gap-4 group">
                  <div className="flex items-center gap-3.5 flex-1">
                    <div className="w-10 h-10 rounded-xl bg-[#1C2541] border border-slate-700 flex items-center justify-center text-emerald-400 shrink-0 font-bold text-xs">
                      {file.category}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors">{file.name}</h4>
                      <p className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>{file.type}</span> • <span>{file.size}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setInputText(prev => prev ? `${prev} 📎 [Adjunto: ${file.name}]` : `📎 [Adjunto: ${file.name}]`);
                        setShowAttachModal(false);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-[#1C2541] hover:bg-[#253258] text-xs text-white font-semibold transition-all border border-slate-700"
                    >
                      Añadir al Input
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (activeConv) {
                          onSendMessage(activeConv.id, `📎 Archivo adjunto enviado: ${file.name} (${file.size})`);
                          setShowAttachModal(false);
                        }
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs text-white font-semibold transition-all shadow flex items-center gap-1.5"
                    >
                      <Send className="w-3 h-3" /> Enviar Directo
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-[#070d1f] border-t border-[#1C2541] flex items-center justify-between text-xs text-slate-400">
              <span>{attachments.length} archivos disponibles en biblioteca</span>
              <button 
                onClick={() => setShowAttachModal(false)}
                className="px-4 py-2 rounded-xl bg-[#1C2541] text-slate-300 hover:text-white"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Right Lead Details Panel */}
      {activeConv && (
        <div className="w-80 border-l border-[#1C2541] bg-[#0B132B] p-5 hidden xl:flex flex-col overflow-y-auto">
          <div className="text-center pb-5 border-b border-[#1C2541]">
            <img src={activeConv.avatar} alt={activeConv.leadName} className="w-20 h-20 rounded-full object-cover mx-auto mb-3 border-2 border-emerald-500/40 shadow-xl" />
            <h3 className="text-base font-bold text-white">{activeConv.leadName}</h3>
            <p className="text-xs text-emerald-400 font-medium">{activeConv.company}</p>
            <p className="text-xs text-slate-400 mt-1">{activeConv.leadPhone}</p>
          </div>

          <div className="py-5 space-y-4 border-b border-[#1C2541]">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Detalles del Lead</h4>
            
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Canal:</span>
              <span className="text-white font-medium bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded">{activeConv.channel}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Agente Asignado:</span>
              <span className="text-white font-medium">{activeConv.assignedAgent}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Estado Conversación:</span>
              <span className="text-amber-400 font-medium uppercase">{activeConv.status}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Sentimiento IA:</span>
              <span className="text-emerald-400 font-bold">✨ Positivo (94%)</span>
            </div>
          </div>

          <div className="py-5">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Etiquetas CRM</h4>
            <div className="flex flex-wrap gap-1.5">
              {activeConv.tags.map((tag, i) => (
                <span key={i} className="text-xs bg-[#1C2541] text-emerald-400 px-2.5 py-1 rounded-lg border border-slate-700 font-medium">
                  #{tag}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-auto pt-5">
            <button className="w-full py-2.5 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/40 font-semibold text-xs hover:bg-emerald-600/30 transition-all flex items-center justify-center gap-2">
              <Zap className="w-4 h-4" /> Automatizar Secuencia WhatsApp
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
