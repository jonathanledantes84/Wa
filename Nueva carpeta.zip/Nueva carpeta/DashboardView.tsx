import React from 'react';
import { 
  Users, 
  MessageSquare, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  ArrowUpRight, 
  Sparkles, 
  PhoneCall, 
  Send,
  PlusCircle,
  ExternalLink
} from 'lucide-react';
import { Lead, Conversation, Deal, ViewMode } from '../types';

interface DashboardViewProps {
  leads: Lead[];
  conversations: Conversation[];
  deals: Deal[];
  onNavigate: (view: ViewMode) => void;
  onSelectConversation: (convId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  leads,
  conversations,
  deals,
  onNavigate,
  onSelectConversation
}) => {
  const totalRevenue = deals
    .filter(d => d.stage === 'ganado')
    .reduce((sum, d) => sum + d.value, 0);

  const pipelineValue = deals
    .filter(d => d.stage !== 'ganado' && d.stage !== 'perdido')
    .reduce((sum, d) => sum + d.value, 0);

  const activeChats = conversations.filter(c => c.status === 'abierta').length;

  return (
    <div className="p-8 space-y-8 bg-[#070d1f] min-h-screen text-slate-100">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs bg-emerald-500/10 text-emerald-400 font-semibold px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> Panel de Control en Tiempo Real
            </span>
            <span className="text-xs text-slate-400">Actualizado recién</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Hola, Equipo Clientum 👋</h1>
          <p className="text-sm text-slate-400">Aquí está el pulso de tus ventas y automatizaciones de WhatsApp hoy.</p>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={() => onNavigate('inbox')}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition-all shadow-lg shadow-emerald-600/20 flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" /> Abrir WhatsApp Inbox ({activeChats})
          </button>
          <button 
            onClick={() => onNavigate('pipeline')}
            className="px-4 py-2.5 rounded-xl bg-[#1C2541] hover:bg-[#253258] text-slate-200 font-medium text-sm border border-slate-700 transition-all flex items-center gap-2"
          >
            <TrendingUp className="w-4 h-4 text-emerald-400" /> Ver Pipeline
          </button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-5 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20">
              <DollarSign className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" /> +24% este mes
            </span>
          </div>
          <h3 className="text-2xl font-bold text-white">${totalRevenue.toLocaleString()} USD</h3>
          <p className="text-xs text-slate-400 mt-1">Ventas Cerradas (Ganadas)</p>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 to-cyan-500"></div>
        </div>

        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-5 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20">
              <TrendingUp className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">
              {deals.length} Oportunidades
            </span>
          </div>
          <h3 className="text-2xl font-bold text-white">${pipelineValue.toLocaleString()} USD</h3>
          <p className="text-xs text-slate-400 mt-1">Valor en Pipeline Activo</p>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-indigo-500"></div>
        </div>

        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-5 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 border border-cyan-500/20">
              <MessageSquare className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span> En vivo
            </span>
          </div>
          <h3 className="text-2xl font-bold text-white">{activeChats} Chats</h3>
          <p className="text-xs text-slate-400 mt-1">Conversaciones Activas WhatsApp</p>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 to-teal-500"></div>
        </div>

        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-5 relative overflow-hidden shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 border border-purple-500/20">
              <Clock className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
              -45% vs ayer
            </span>
          </div>
          <h3 className="text-2xl font-bold text-white">1.8 min</h3>
          <p className="text-xs text-slate-400 mt-1">Tiempo Promedio de Respuesta</p>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 to-pink-500"></div>
        </div>
      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent WhatsApp Conversations */}
        <div className="lg:col-span-2 bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Inbox WhatsApp Reciente</h3>
                <p className="text-xs text-slate-400">Mensajes entrantes y estado de atención</p>
              </div>
            </div>
            <button 
              onClick={() => onNavigate('inbox')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
            >
              Ver todos <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {conversations.map((conv) => (
              <div 
                key={conv.id}
                onClick={() => {
                  onSelectConversation(conv.id);
                  onNavigate('inbox');
                }}
                className="p-4 rounded-xl bg-[#1C2541]/40 border border-[#1C2541] hover:border-emerald-500/40 transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3.5">
                  <div className="relative">
                    <img src={conv.avatar} alt={conv.leadName} className="w-11 h-11 rounded-full object-cover border border-slate-700" />
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#0B132B]"></span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">{conv.leadName}</h4>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">{conv.company}</span>
                      {conv.sentiment === 'positive' && (
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-medium">✨ Positivo</span>
                      )}
                      {conv.sentiment === 'urgent' && (
                        <span className="text-[10px] bg-rose-500/20 text-rose-400 px-1.5 py-0.5 rounded font-medium">⚡ Urgente</span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 truncate max-w-md mt-0.5">{conv.lastMessage}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs text-slate-400 block">{conv.lastMessageTime}</span>
                  {conv.unreadCount > 0 && (
                    <span className="mt-1 inline-flex items-center justify-center w-5 h-5 text-[10px] font-bold text-slate-950 bg-emerald-400 rounded-full">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sales Pipeline Stage Overview */}
        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 mb-6">
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Embudo de Ventas</h3>
                <p className="text-xs text-slate-400">Distribución por etapa comercial</p>
              </div>
            </div>

            <div className="space-y-4">
              {[
                { label: 'Nuevos Leads', count: leads.filter(l => l.status === 'nuevo').length, color: 'bg-cyan-500', pct: 25 },
                { label: 'Contactados', count: leads.filter(l => l.status === 'contactado').length, color: 'bg-blue-500', pct: 40 },
                { label: 'Propuesta Enviada', count: leads.filter(l => l.status === 'propuesta').length, color: 'bg-amber-500', pct: 60 },
                { label: 'En Negociación', count: leads.filter(l => l.status === 'negociacion').length, color: 'bg-purple-500', pct: 80 },
                { label: 'Cerrados Ganados', count: leads.filter(l => l.status === 'ganado').length, color: 'bg-emerald-500', pct: 100 },
              ].map((stage, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">{stage.label}</span>
                    <span className="text-white font-bold">{stage.count} leads</span>
                  </div>
                  <div className="w-full bg-[#1C2541] h-2 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${stage.color}`} 
                      style={{ width: `${Math.max(stage.pct, 12)}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-[#1C2541]">
            <button 
              onClick={() => onNavigate('pipeline')}
              className="w-full py-2.5 rounded-xl bg-[#1C2541] hover:bg-[#253258] text-white font-semibold text-xs transition-all border border-slate-700 flex items-center justify-center gap-2"
            >
              Gestionar Kanban Comercial <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
