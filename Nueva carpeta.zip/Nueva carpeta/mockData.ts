import { Lead, Conversation, Deal, CustomerSegment, ChatbotRule, Campaign, Agent } from '../types';

export const initialAgents: Agent[] = [
  {
    id: 'ag-1',
    name: 'Sofía Martínez',
    email: 'sofia@clientum.ar',
    role: 'Admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    status: 'online',
    activeChatsCount: 4,
    closedDealsThisMonth: 18,
  },
  {
    id: 'ag-2',
    name: 'Mateo Rossi',
    email: 'mateo@clientum.ar',
    role: 'Supervisor',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    status: 'online',
    activeChatsCount: 6,
    closedDealsThisMonth: 24,
  },
  {
    id: 'ag-3',
    name: 'Valentina Gómez',
    email: 'valentina@clientum.ar',
    role: 'Agente Venta',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    status: 'online',
    activeChatsCount: 3,
    closedDealsThisMonth: 12,
  },
  {
    id: 'ag-4',
    name: 'Lucas Fernández',
    email: 'lucas@clientum.ar',
    role: 'Agente Venta',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    status: 'busy',
    activeChatsCount: 5,
    closedDealsThisMonth: 9,
  },
];

export const initialLeads: Lead[] = [
  {
    id: 'lead-1',
    name: 'Esteban Acuña',
    company: 'AgroExport del Sur',
    email: 'e.acuna@agroexportsur.com.ar',
    phone: '+54 9 11 4321-8765',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    status: 'negociacion',
    value: 12500,
    assignedAgent: 'Sofía Martínez',
    tags: ['VIP', 'Agro', 'WhatsApp Pro'],
    lastContact: 'Hace 10 mins',
    source: 'WhatsApp',
    createdAt: '2026-07-20',
  },
  {
    id: 'lead-2',
    name: 'Mariana Benítez',
    company: 'TechSolutions BA',
    email: 'mbenitez@techsolutions.io',
    phone: '+54 9 11 5544-3322',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    status: 'propuesta',
    value: 8400,
    assignedAgent: 'Mateo Rossi',
    tags: ['SaaS', 'Software', 'Interesado'],
    lastContact: 'Hace 1 hora',
    source: 'Web Chat',
    createdAt: '2026-07-22',
  },
  {
    id: 'lead-3',
    name: 'Carlos Mendoza',
    company: 'Logística Austral S.A.',
    email: 'cmendoza@logisticaustral.com',
    phone: '+54 9 351 678-9012',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    status: 'contactado',
    value: 19000,
    assignedAgent: 'Valentina Gómez',
    tags: ['Logística', 'Enterprise'],
    lastContact: 'Hace 3 horas',
    source: 'WhatsApp',
    createdAt: '2026-07-25',
  },
  {
    id: 'lead-4',
    name: 'Lucía Pardo',
    company: 'Fintech Nova Argentina',
    email: 'lpardo@novafintech.ar',
    phone: '+54 9 11 9876-5432',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    status: 'ganado',
    value: 24000,
    assignedAgent: 'Sofía Martínez',
    tags: ['Fintech', 'Cerrado', 'Cliente Anual'],
    lastContact: 'Ayer',
    source: 'WhatsApp',
    createdAt: '2026-07-15',
  },
  {
    id: 'lead-5',
    name: 'Julián Rivas',
    company: 'Retail Buenos Aires',
    email: 'jrivas@retailba.com.ar',
    phone: '+54 9 11 2345-6789',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    status: 'nuevo',
    value: 5500,
    assignedAgent: 'Lucas Fernández',
    tags: ['Retail', 'Campaña Julio'],
    lastContact: 'Hace 5 horas',
    source: 'Instagram',
    createdAt: '2026-07-30',
  },
  {
    id: 'lead-6',
    name: 'Camila Duarte',
    company: 'Estudio Jurídico Duarte',
    email: 'cduarte@duartelex.com.ar',
    phone: '+54 9 341 456-7890',
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=150&auto=format&fit=crop&q=80',
    status: 'propuesta',
    value: 7200,
    assignedAgent: 'Mateo Rossi',
    tags: ['Legal', 'Servicios'],
    lastContact: 'Hace 1 día',
    source: 'WhatsApp',
    createdAt: '2026-07-24',
  }
];

export const initialConversations: Conversation[] = [
  {
    id: 'conv-1',
    leadId: 'lead-1',
    leadName: 'Esteban Acuña',
    leadPhone: '+54 9 11 4321-8765',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    company: 'AgroExport del Sur',
    lastMessage: 'Perfecto Sofía, mandame el link de pago para confirmar los 5 agentes adicionales.',
    lastMessageTime: '14:28',
    unreadCount: 2,
    assignedAgent: 'Sofía Martínez',
    channel: 'WhatsApp',
    sentiment: 'positive',
    tags: ['VIP', 'Agro', 'WhatsApp Pro'],
    status: 'abierta',
    messages: [
      {
        id: 'm-1',
        sender: 'bot',
        senderName: 'Asistente IA Clientum',
        content: '¡Hola Esteban! Gracias por contactarte con Clientum WhatsApp CRM. ¿En qué podemos ayudarte hoy?',
        timestamp: '14:00',
        status: 'read'
      },
      {
        id: 'm-2',
        sender: 'client',
        senderName: 'Esteban Acuña',
        content: 'Hola, estuvimos probando la automatización con la API de WhatsApp y queremos sumar 5 puestos más para nuestro equipo de ventas.',
        timestamp: '14:15',
        status: 'read'
      },
      {
        id: 'm-3',
        sender: 'agent',
        senderName: 'Sofía Martínez',
        content: '¡Hola Esteban qué excelente noticia! Con gusto te preparo la cotización corporativa con descuento por volumen.',
        timestamp: '14:20',
        status: 'read'
      },
      {
        id: 'm-4',
        sender: 'client',
        senderName: 'Esteban Acuña',
        content: 'Perfecto Sofía, mandame el link de pago para confirmar los 5 agentes adicionales.',
        timestamp: '14:28',
        status: 'delivered'
      }
    ]
  },
  {
    id: 'conv-2',
    leadId: 'lead-2',
    leadName: 'Mariana Benítez',
    leadPhone: '+54 9 11 5544-3322',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    company: 'TechSolutions BA',
    lastMessage: '¿Tienen integración disponible con Mercado Pago y Salesforce?',
    lastMessageTime: '13:45',
    unreadCount: 0,
    assignedAgent: 'Mateo Rossi',
    channel: 'WhatsApp',
    sentiment: 'neutral',
    tags: ['SaaS', 'Software'],
    status: 'abierta',
    messages: [
      {
        id: 'm-21',
        sender: 'client',
        senderName: 'Mariana Benítez',
        content: 'Hola buenos días. ¿Tienen integración disponible con Mercado Pago y Salesforce?',
        timestamp: '13:40',
        status: 'read'
      },
      {
        id: 'm-22',
        sender: 'agent',
        senderName: 'Mateo Rossi',
        content: '¡Hola Mariana! Sí, contamos con conector nativo para Mercado Pago y webhooks avanzados para sincronizar con Salesforce y cualquier CRM.',
        timestamp: '13:45',
        status: 'read'
      }
    ]
  },
  {
    id: 'conv-3',
    leadId: 'lead-3',
    leadName: 'Carlos Mendoza',
    leadPhone: '+54 9 351 678-9012',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    company: 'Logística Austral S.A.',
    lastMessage: 'Necesitamos resolver urgente el tema de los reportes diarios de entrega por WhatsApp.',
    lastMessageTime: '11:12',
    unreadCount: 1,
    assignedAgent: 'Valentina Gómez',
    channel: 'WhatsApp',
    sentiment: 'urgent',
    tags: ['Logística', 'Enterprise'],
    status: 'en_espera',
    messages: [
      {
        id: 'm-31',
        sender: 'client',
        senderName: 'Carlos Mendoza',
        content: 'Necesitamos resolver urgente el tema de los reportes diarios de entrega por WhatsApp.',
        timestamp: '11:12',
        status: 'delivered'
      }
    ]
  },
  {
    id: 'conv-4',
    leadId: 'lead-5',
    leadName: 'Julián Rivas',
    leadPhone: '+54 9 11 2345-6789',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    company: 'Retail Buenos Aires',
    lastMessage: 'Hola vi el anuncio en Instagram sobre la demo gratuita del CRM.',
    lastMessageTime: 'Ayer',
    unreadCount: 0,
    assignedAgent: 'Lucas Fernández',
    channel: 'Instagram',
    sentiment: 'neutral',
    tags: ['Retail', 'Campaña Julio'],
    status: 'resuelta',
    messages: [
      {
        id: 'm-41',
        sender: 'client',
        senderName: 'Julián Rivas',
        content: 'Hola vi el anuncio en Instagram sobre la demo gratuita del CRM.',
        timestamp: 'Ayer',
        status: 'read'
      },
      {
        id: 'm-42',
        sender: 'agent',
        senderName: 'Lucas Fernández',
        content: '¡Hola Julián! Claro que sí, te paso el link directo para agendar con un especialista: clientum.ar/demo',
        timestamp: 'Ayer',
        status: 'read'
      }
    ]
  }
];

export const initialDeals: Deal[] = [
  { id: 'd-1', title: 'Implementación WhatsApp Business API', company: 'AgroExport del Sur', value: 12500, stage: 'negociacion', probability: 85, expectedCloseDate: '2026-08-10', contactName: 'Esteban Acuña', contactPhone: '+54 9 11 4321-8765' },
  { id: 'd-2', title: 'Licenciamiento Anual Enterprise', company: 'TechSolutions BA', value: 8400, stage: 'propuesta', probability: 60, expectedCloseDate: '2026-08-15', contactName: 'Mariana Benítez', contactPhone: '+54 9 11 5544-3322' },
  { id: 'd-3', title: 'Automatización Flotas & Envíos', company: 'Logística Austral S.A.', value: 19000, stage: 'contactado', probability: 40, expectedCloseDate: '2026-08-30', contactName: 'Carlos Mendoza', contactPhone: '+54 9 351 678-9012' },
  { id: 'd-4', title: 'SaaS Omnicanal Central', company: 'Fintech Nova Argentina', value: 24000, stage: 'ganado', probability: 100, expectedCloseDate: '2026-07-28', contactName: 'Lucía Pardo', contactPhone: '+54 9 11 9876-5432' },
  { id: 'd-5', title: 'Bot de Respuestas Automáticas', company: 'Retail Buenos Aires', value: 5500, stage: 'nuevo', probability: 20, expectedCloseDate: '2026-09-05', contactName: 'Julián Rivas', contactPhone: '+54 9 11 2345-6789' },
  { id: 'd-6', title: 'Módulo Legal de Atención', company: 'Estudio Jurídico Duarte', value: 7200, stage: 'propuesta', probability: 55, expectedCloseDate: '2026-08-20', contactName: 'Camila Duarte', contactPhone: '+54 9 341 456-7890' }
];

export const initialSegments: CustomerSegment[] = [
  { id: 'seg-1', name: 'Clientes VIP & Enterprise', description: 'Cuentas con valor mayor a $10,000 USD y alta interacción.', filterTag: 'VIP', leadCount: 14, color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30', createdAt: '2026-07-01' },
  { id: 'seg-2', name: 'Agroindustria & Interior', description: 'Leads del sector agrícola y provincias del interior de Argentina.', filterTag: 'Agro', leadCount: 28, color: 'bg-blue-500/10 text-blue-400 border-blue-500/30', createdAt: '2026-07-05' },
  { id: 'seg-3', name: 'Prospectos Fríos (Julio)', description: 'Leads ingresados por campañas de redes sociales pendientes de cierre.', filterTag: 'Campaña Julio', leadCount: 45, color: 'bg-amber-500/10 text-amber-400 border-amber-500/30', createdAt: '2026-07-10' },
  { id: 'seg-4', name: 'SaaS & Software Startups', description: 'Empresas tecnológicas y de software B2B.', filterTag: 'SaaS', leadCount: 22, color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30', createdAt: '2026-07-15' }
];

export const initialChatbotRules: ChatbotRule[] = [
  { id: 'cb-1', name: 'Saludo Inicial Automático', triggerKeyword: 'hola, buenos dias, ola', responseMessage: '¡Hola! Bienvenido a Clientum 🚀. Automatizamos tus ventas y WhatsApp con IA. ¿En qué podemos ayudarte hoy?', enabled: true, triggerCount: 1420, action: 'auto_reply' },
  { id: 'cb-2', name: 'Derivación a Ventas', triggerKeyword: 'precio, planes, cotizar, comprar', responseMessage: 'Entendido. Un asesor especialista de nuestro equipo te contactará en menos de 5 minutos.', enabled: true, triggerCount: 834, action: 'assign_agent' },
  { id: 'cb-3', name: 'Envío de Catálogo PDF', triggerKeyword: 'catalogo, pdf, folleto, info', responseMessage: '📄 Aquí tienes nuestro brochure oficial con todas las funcionalidades de WhatsApp CRM: https://clientum.ar/brochure.pdf', enabled: true, triggerCount: 512, action: 'send_catalog' },
  { id: 'cb-4', name: 'Soporte Técnico Urgente', triggerKeyword: 'ayuda, error, soporte, urgente', responseMessage: '⚠️ Tu caso fue derivado con prioridad alta a nuestro equipo de soporte técnico.', enabled: true, triggerCount: 96, action: 'tag_lead' }
];

export const initialCampaigns: Campaign[] = [
  { id: 'cmp-1', name: 'Lanzamiento WhatsApp IA 2.0', segmentId: 'seg-1', segmentName: 'Clientes VIP & Enterprise', messageTemplate: '¡Hola {nombre}! Ya está disponible la nueva actualización de automatización IA en Clientum. ¿Querés agendar una demo exclusiva?', status: 'enviada', recipientsCount: 14, deliveredCount: 14, responseRate: 78.5, scheduledDate: '2026-07-28' },
  { id: 'cmp-2', name: 'Campaña Reactivación Leads', segmentId: 'seg-3', segmentName: 'Prospectos Fríos (Julio)', messageTemplate: 'Hola {nombre}, notamos interés en nuestro CRM. ¿Te gustaría retomar la propuesta con 20% OFF este mes?', status: 'programada', recipientsCount: 45, deliveredCount: 0, responseRate: 0, scheduledDate: '2026-08-02' }
];
