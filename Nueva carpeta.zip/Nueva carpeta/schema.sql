-- PostgreSQL Database Schema Migration for ERPNext SaaS Control Plane

CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(64) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'customer',
    company_name VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bench_nodes (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    hostname VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    region VARCHAR(100) NOT NULL,
    provider VARCHAR(50) NOT NULL,
    status VARCHAR(50) DEFAULT 'healthy',
    active_sites_count INT DEFAULT 0,
    max_sites_capacity INT DEFAULT 100,
    cpu_usage_pct INT DEFAULT 0,
    memory_usage_pct INT DEFAULT 0,
    disk_usage_pct INT DEFAULT 0,
    frappe_branch VARCHAR(100) DEFAULT 'version-15',
    last_heartbeat TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sites (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    subdomain VARCHAR(255) UNIQUE NOT NULL,
    custom_domain VARCHAR(255),
    company_name VARCHAR(255) NOT NULL,
    owner_email VARCHAR(255) NOT NULL,
    plan VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    bench_id VARCHAR(64) REFERENCES bench_nodes(id),
    bench_name VARCHAR(255) NOT NULL,
    frappe_version VARCHAR(50) DEFAULT '15.x',
    erpnext_version VARCHAR(50) DEFAULT '15.x',
    installed_apps TEXT[],
    disk_usage_mb INT DEFAULT 0,
    disk_quota_mb INT DEFAULT 10240,
    users_count INT DEFAULT 1,
    max_users INT DEFAULT 10,
    db_name VARCHAR(255) NOT NULL,
    ssl_status VARCHAR(50) DEFAULT 'active',
    sso_token VARCHAR(255),
    country VARCHAR(100) DEFAULT 'US',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS site_backups (
    id VARCHAR(64) PRIMARY KEY,
    site_id VARCHAR(64) REFERENCES sites(id) ON DELETE CASCADE,
    site_subdomain VARCHAR(255) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    size_mb INT NOT NULL,
    backup_type VARCHAR(50) NOT NULL,
    s3_url VARCHAR(500),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS subscriptions (
    id VARCHAR(64) PRIMARY KEY,
    site_id VARCHAR(64) REFERENCES sites(id) ON DELETE CASCADE,
    customer_email VARCHAR(255) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    plan VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    monthly_price INT NOT NULL,
    billing_cycle VARCHAR(50) DEFAULT 'monthly',
    next_billing_date DATE,
    stripe_subscription_id VARCHAR(255),
    payment_method VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS async_jobs (
    id VARCHAR(64) PRIMARY KEY,
    type VARCHAR(100) NOT NULL,
    target_site_id VARCHAR(64),
    status VARCHAR(50) NOT NULL,
    progress_pct INT DEFAULT 0,
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE IF NOT EXISTS email_notifications (
    id VARCHAR(64) PRIMARY KEY,
    to_email VARCHAR(255) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    body_text TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'sent',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS system_logs (
    id VARCHAR(64) PRIMARY KEY,
    level VARCHAR(20) NOT NULL,
    source VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    site_subdomain VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
