const fs = require('fs');
let content = fs.readFileSync('src/components/Header.tsx', 'utf-8');

const importRegex = /import React, { useState } from 'react';/;
content = content.replace(importRegex, "import React, { useState, useEffect } from 'react';");

const stateRegex = /const \[showUserMenu, setShowUserMenu\] = useState\(false\);/;
const baileysState = `  const [showUserMenu, setShowUserMenu] = useState(false);
  const [baileysConnected, setBaileysConnected] = useState(true);

  useEffect(() => {
    const handleBaileysStatus = (e: any) => {
      setBaileysConnected(e.detail.isConnected);
    };
    window.addEventListener('baileys-status-change', handleBaileysStatus);
    return () => window.removeEventListener('baileys-status-change', handleBaileysStatus);
  }, []);
`;
content = content.replace(stateRegex, baileysState);

const metaBadgeRegex = /<span className="hidden md:inline">Verificado Meta<\/span>\s*<\/div>/;
const newBadges = `<span className="hidden md:inline">Verificado Meta</span>
        </div>

        {/* Baileys Gateway Status Badge */}
        <div className={\`flex items-center space-x-1.5 text-xs border px-2.5 py-1 rounded-full font-medium \${baileysConnected ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'}\`}>
          <div className={\`w-2 h-2 rounded-full \${baileysConnected ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}\`}></div>
          <span className="hidden md:inline">{baileysConnected ? 'Baileys: Activo' : 'Baileys: Error'}</span>
        </div>`;
content = content.replace(metaBadgeRegex, newBadges);

fs.writeFileSync('src/components/Header.tsx', content);
