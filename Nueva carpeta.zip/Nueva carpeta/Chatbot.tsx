import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as Icons from 'lucide-react';

// Local cn helper to guarantee self-containment
const cn = (...classes: any[]) => classes.filter(Boolean).join(' ');

interface Product {
  id: string;
  nombre: string;
  precio: string;
  categoria: string;
  descripcion: string;
  imagen?: string;
  enStock?: boolean;
}

interface ChatbotProps {
  products: Product[];
  config: any;
  darkMode: boolean;
  onSelectProduct: (p: Product) => void;
  currency: string;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  productsToShow?: Product[];
  timestamp: Date;
}

export default function Chatbot({
  products,
  config,
  darkMode,
  onSelectProduct,
  currency
}: ChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize welcome messages and FAQ buttons
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: 'welcome-1',
          sender: 'bot',
          text: `¡Hola! 👋 Soy *CleanBot*, el asistente virtual de *${config.brand.name}*.`,
          timestamp: new Date()
        },
        {
          id: 'welcome-2',
          sender: 'bot',
          text: 'Estoy listo para ayudarte a encontrar productos de desinfección, responder preguntas frecuentes sobre envíos o pagos, y guiarte en tu pedido automatizado. ¿En qué te puedo asesorar hoy?',
          timestamp: new Date()
        }
      ]);
    }
  }, [config]);

  // Handle messages auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  // Extract FAQs from config dynamically
  const faqList = useMemo(() => {
    if (config?.faq && Array.isArray(config.faq)) {
      return config.faq;
    }
    return [
      { q: "¿Hacen envíos a domicilio?", a: "Sí, realizamos envíos en General Roca y zonas aledañas. Consultanos por el costo según tu zona." },
      { q: "¿Tienen precios para revendedores?", a: "¡Sí! Tenemos una lista de precios especial para compras mayoristas. Contactanos por WhatsApp." },
      { q: "¿Cuáles son los medios de pago?", a: "Aceptamos efectivo, transferencia bancaria y Mercado Pago." }
    ];
  }, [config]);

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsgId = `usr-${Date.now()}`;
    const newMsg: ChatMessage = {
      id: userMsgId,
      sender: 'user',
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMsg]);
    setUserInput('');

    // Trigger typing / quick automated response logic
    setTimeout(() => {
      const botResponse = generateBotResponse(textToSend);
      setMessages(prev => [...prev, {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: botResponse.text,
        productsToShow: botResponse.products,
        timestamp: new Date()
      }]);
    }, 600);
  };

  // Chat logic & keyword matcher
  const generateBotResponse = (input: string): { text: string; products?: Product[] } => {
    const text = input.toLowerCase();

    // 1. Matches exact or partial question from spreadsheets FAQ
    const faqMatch = faqList.find((item: any) => {
      const question = item.q.toLowerCase();
      return text.includes(question) || question.includes(text) || 
             (text.includes('envio') && question.includes('envío')) ||
             (text.includes('pago') && question.includes('pago')) ||
             (text.includes('mayor') && question.includes('revendedor'));
    });

    if (faqMatch) {
      return { text: faqMatch.a };
    }

    // 2. Help/Guide instructions
    if (text.includes('ayuda') || text.includes('como comprar') || text.includes('pedido') || text.includes('carrito')) {
      return {
        text: `¡Comprar en *${config.brand.name}* es súper sencillo! \n\n1. Buscá tus insumos en el **Catálogo**.\n2. Presioná sobre cualquier elemento para ver los detalles.\n3. Elegí la cantidad y agregalo al **Carrito** (o pedilo directo mediante el botón verde).\n4. Cuando termines, abrí tu Carrito de compras arriba en la barra de navegación y presioná "Enviar Pedido por WhatsApp" para enviarnos el detalle formateado automáticamente para entrega en General Roca. \n\n¿Deseás que te recomiende algún tipo de producto? Escribime cosas como "detergente" or "lavandina" y te los busco.`
      };
    }

    // 3. Address location info
    if (text.includes('direccion') || text.includes('donde') || text.includes('ubicacion') || text.includes('sucursal') || text.includes('local') || text.includes('mapa')) {
      return {
        text: `Nuestra central de distribución está ubicada en *${config.contact.address || 'La Pampa 1672, General Roca, RN'}*. \n\nNuestros horarios de atención son: *${config.contact.hours || 'Lunes a Viernes de 09:00 a 18:00 hs'}*. ¡Te esperamos!`
      };
    }

    // 4. Products search/fuzzy matcher
    // Find matching categories or names
    const matchedProducts = products.filter(p => {
      const name = p.nombre.toLowerCase();
      const cat = p.categoria.toLowerCase();
      const desc = p.descripcion.toLowerCase();
      return name.includes(text) || cat.includes(text) || desc.includes(text) ||
             (text.includes('lavandina') && name.includes('lavandina')) ||
             (text.includes('detergente') && name.includes('detergente')) ||
             (text.includes('jabon') && name.includes('jabón')) ||
             (text.includes('suavizante') && name.includes('suavizante')) ||
             (text.includes('cloro') && name.includes('cloro')) ||
             (text.includes('oferta') && name.includes('oferta'));
    });

    if (matchedProducts.length > 0) {
      const visibleProducts = matchedProducts.slice(0, 3);
      return {
        text: `¡Qué bueno! Encontré estos *${matchedProducts.length}* productos que coinciden con tu búsqueda. Presioná el botón debajo de cualquiera de ellos para ver detalles y cargarlo al carrito:`,
        products: visibleProducts
      };
    }

    // 5. Greets
    if (text.includes('hola') || text.includes('buenos dias') || text.includes('buenas tardes') || text.includes('buen dia')) {
      return {
        text: '¡Hola! Es un gusto saludarte. ¿Querés consultarme sobre algún producto, medios de pago, o envíos a domicilio?'
      };
    }

    // 6. Generic Default Fallback
    return {
      text: 'Disculpame, no logré comprender tu consulta exacta. 🤔\n\n¿Podrías reformular tu pregunta? También podés indicarme qué producto buscás (ej: "lavandina", "detergente") o hacer clic directamente en las **preguntas frecuentes rápidas** que tengo preparadas para vos debajo.'
    };
  };

  return (
    <div className="fixed bottom-8 right-24 z-55 flex flex-col items-end">
      {/* Dynamic Animated Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.85, y: 30 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className={cn(
              "w-[90vw] sm:w-[380px] h-[500px] mb-4 rounded-3xl shadow-2xl border flex flex-col overflow-hidden origin-bottom-right",
              darkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-100 text-slate-800"
            )}
          >
            {/* Window Header */}
            <div className={cn(
              "px-5 py-4 border-b flex justify-between items-center shrink-0",
              darkMode ? "bg-slate-950/80 border-slate-800" : "bg-blue-600 border-blue-700 text-white"
            )}>
              <div className="flex items-center gap-2.5">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white shrink-0 font-black">
                    <Icons.Bot size={20} className={darkMode ? "text-blue-400 animate-pulse" : "text-white"} />
                  </div>
                  <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-black tracking-tight leading-none mb-0.5">Asistente CleanBot</h4>
                  <span className="text-[10px] opacity-80 font-bold">Respuesta Automatizada • Online</span>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1 px-2 rounded-lg hover:bg-black/10 transition-colors text-white/90"
              >
                <Icons.X size={18} />
              </button>
            </div>

            {/* Conversation Flow Area */}
            <div className="flex-grow overflow-y-auto p-4 space-y-4 flex flex-col">
              {messages.map((msg) => {
                const isUser = msg.sender === 'user';
                return (
                  <div 
                    key={msg.id} 
                    className={cn(
                      "flex flex-col max-w-[85%] text-left space-y-1.5",
                      isUser ? "self-end items-end" : "self-start items-start"
                    )}
                  >
                    <div className={cn(
                      "p-3.5 rounded-2xl text-xs font-semibold leading-relaxed shadow-sm",
                      isUser
                        ? "bg-blue-600 text-white rounded-tr-none"
                        : darkMode
                          ? "bg-slate-950 text-slate-100 rounded-tl-none border border-slate-850"
                          : "bg-slate-100 text-slate-800 rounded-tl-none border border-slate-150"
                    )}>
                      {/* Match simple bold markers for custom titles, with multi lines support */}
                      {msg.text.split('\n').map((line, i) => (
                        <p key={i} className="mb-1 leading-normal last:mb-0">
                          {line.split('**').map((chunk, j) => {
                            // Match bolding markdown **word**
                            if (j % 2 !== 0) return <strong key={j} className="font-extrabold">{chunk}</strong>;
                            
                            // Match single bold marks like *word*
                            return chunk.split('*').map((subchunk, k) => {
                              if (k % 2 !== 0) return <strong key={k} className="font-extrabold text-blue-500 dark:text-blue-400">{subchunk}</strong>;
                              return subchunk;
                            });
                          })}
                        </p>
                      ))}

                      {/* Product Carousel attachment */}
                      {msg.productsToShow && msg.productsToShow.length > 0 && (
                        <div className="mt-3.5 space-y-2.5">
                          {msg.productsToShow.map(p => (
                            <div 
                              key={p.id}
                              onClick={() => {
                                onSelectProduct(p);
                                setIsOpen(false);
                              }}
                              className={cn(
                                "p-2.5 rounded-xl border flex items-center gap-3 cursor-pointer hover:scale-[1.02] active:scale-95 transition-all text-left",
                                darkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-800"
                              )}
                            >
                              <div className="w-10 h-10 rounded-lg overflow-hidden border p-0.5 shrink-0 bg-white">
                                {p.imagen ? (
                                  <img src={p.imagen} alt={p.nombre} className="w-full h-full object-contain" />
                                ) : (
                                  <Icons.Package size={14} className="text-blue-500 opacity-20" />
                                )}
                              </div>
                              <div className="min-w-0 flex-grow">
                                <h5 className="text-[10px] font-black uppercase tracking-tight text-blue-500 leading-none mb-0.5">{p.categoria}</h5>
                                <h6 className="text-[11px] font-bold truncate leading-tight">{p.nombre}</h6>
                                <span className="text-[10px] text-slate-450 dark:text-slate-350 font-black">{currency}{p.precio}</span>
                              </div>
                              <Icons.ChevronRight size={14} className="text-slate-400 shrink-0" />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <span className="text-[9px] text-slate-400 px-1 font-bold">
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* In-chat FAQ Recommendations Panel */}
            <div className={cn(
              "px-3 py-2.5 border-t overflow-x-auto whitespace-nowrap flex gap-1.5 shrink-0 scrollbar-none",
              darkMode ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-100"
            )}>
              {faqList.map((faq: any, idx: number) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(faq.q)}
                  className={cn(
                    "inline-block px-3 py-1.5 rounded-xl border text-[10px] font-black uppercase transition-all hover:scale-105 active:scale-95 cursor-pointer flex-shrink-0 select-none",
                    darkMode 
                      ? "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850 hover:text-white" 
                      : "bg-white border-slate-200 text-slate-600 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200"
                  )}
                >
                  {faq.q}
                </button>
              ))}
              <button
                onClick={() => handleSendMessage('¿Cómo comprar?')}
                className={cn(
                  "inline-block px-3 py-1.5 rounded-xl border border-dashed text-[10px] font-black uppercase transition-all hover:scale-105 active:scale-95 cursor-pointer flex-shrink-0 select-none",
                  darkMode 
                    ? "bg-slate-900 border-slate-800 text-blue-400" 
                    : "bg-white border-slate-200 text-blue-600 hover:bg-blue-50"
                )}
              >
                💬 Guía de Compra
              </button>
            </div>

            {/* Input Form Block */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(userInput);
              }}
              className={cn(
                "p-3.5 border-t flex gap-2 shrink-0",
                darkMode ? "bg-slate-950 border-slate-800" : "bg-white border-slate-100"
              )}
            >
              <input
                type="text"
                placeholder="Escribí tu consulta o producto..."
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                className={cn(
                  "flex-grow px-4 py-2.5 rounded-xl border text-xs font-semibold outline-none transition-all",
                  darkMode 
                    ? "bg-slate-900 border-slate-800 text-white focus:border-slate-700" 
                    : "bg-slate-50 border-slate-200 text-slate-800 focus:border-slate-300 focus:bg-white"
                )}
              />
              <button
                type="submit"
                className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white cursor-pointer active:scale-90 transition-transform flex items-center justify-center"
                title="Enviar mensaje"
              >
                <Icons.Send size={15} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggler Chat Bubble Button */}
      <button
        onClick={() => setIsOpen(prev => !prev)}
        className={cn(
          "p-4 rounded-full shadow-2xl transition-all hover:scale-110 active:scale-90 flex items-center justify-center select-none cursor-pointer",
          isOpen 
            ? "bg-slate-850 text-white rotate-90" 
            : "bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/20"
        )}
        title="Chat de Preguntas Frecuentes y Asistente"
      >
        {isOpen ? (
          <Icons.Minimize2 size={24} />
        ) : (
          <div className="relative">
            <Icons.Bot size={24} />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-white animate-ping" />
          </div>
        )}
      </button>
    </div>
  );
}
