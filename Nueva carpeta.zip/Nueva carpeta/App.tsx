import React, { useState } from 'react';
import { ViewMode, Lead, Conversation, Deal, CustomerSegment, ChatbotRule, Campaign, Agent } from './types';
import { 
  initialAgents, 
  initialLeads, 
  initialConversations, 
  initialDeals, 
  initialSegments, 
  initialChatbotRules, 
  initialCampaigns 
} from './data/mockData';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { InboxView } from './components/InboxView';
import { PipelineView } from './components/PipelineView';
import { SegmentsView } from './components/SegmentsView';
import { ChatbotView } from './components/ChatbotView';
import { CampaignsView } from './components/CampaignsView';
import { AnalyticsView } from './components/AnalyticsView';
import { SettingsView } from './components/SettingsView';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewMode>('dashboard');
  const [agents] = useState<Agent[]>(initialAgents);
  const [leads, setLeads] = useState<Lead[]>(initialLeads);
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [deals, setDeals] = useState<Deal[]>(initialDeals);
  const [segments, setSegments] = useState<CustomerSegment[]>(initialSegments);
  const [chatbotRules, setChatbotRules] = useState<ChatbotRule[]>(initialChatbotRules);
  const [campaigns, setCampaigns] = useState<Campaign[]>(initialCampaigns);

  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);

  const currentUser = agents[0]; // Sofía Martínez (Admin)

  const unreadTotal = conversations.reduce((acc, c) => acc + c.unreadCount, 0);

  // Handle sending a message in WhatsApp Inbox
  const handleSendMessage = (conversationId: string, text: string) => {
    setConversations(prev => prev.map(conv => {
      if (conv.id === conversationId) {
        const newMsg = {
          id: `msg-${Date.now()}`,
          sender: 'agent' as const,
          senderName: currentUser.name,
          content: text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'sent' as const
        };
        return {
          ...conv,
          lastMessage: text,
          lastMessageTime: newMsg.timestamp,
          messages: [...conv.messages, newMsg]
        };
      }
      return conv;
    }));
  };

  // Handle updating deal stage in Kanban
  const handleUpdateDealStage = (dealId: string, newStage: Deal['stage']) => {
    setDeals(prev => prev.map(d => d.id === dealId ? { ...d, stage: newStage } : d));
  };

  const handleAddDeal = (newDeal: Deal) => {
    setDeals(prev => [newDeal, ...prev]);
  };

  const handleAddSegment = (newSeg: CustomerSegment) => {
    setSegments(prev => [newSeg, ...prev]);
  };

  const handleToggleRule = (ruleId: string) => {
    setChatbotRules(prev => prev.map(r => r.id === ruleId ? { ...r, enabled: !r.enabled } : r));
  };

  const handleAddRule = (newRule: ChatbotRule) => {
    setChatbotRules(prev => [newRule, ...prev]);
  };

  const handleAddCampaign = (newCamp: Campaign) => {
    setCampaigns(prev => [newCamp, ...prev]);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#070d1f] font-sans">
      <Sidebar 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        currentUser={currentUser}
        unreadTotal={unreadTotal}
      />

      <main className="flex-1 overflow-y-auto">
        {currentView === 'dashboard' && (
          <DashboardView 
            leads={leads}
            conversations={conversations}
            deals={deals}
            onNavigate={setCurrentView}
            onSelectConversation={setSelectedConversationId}
          />
        )}
        {currentView === 'inbox' && (
          <InboxView 
            conversations={conversations}
            onSendMessage={handleSendMessage}
            selectedConversationId={selectedConversationId}
            onSelectConversation={setSelectedConversationId}
            agents={agents}
          />
        )}
        {currentView === 'pipeline' && (
          <PipelineView 
            deals={deals}
            onUpdateDealStage={handleUpdateDealStage}
            onAddDeal={handleAddDeal}
          />
        )}
        {currentView === 'segments' && (
          <SegmentsView 
            segments={segments}
            leads={leads}
            onAddSegment={handleAddSegment}
          />
        )}
        {currentView === 'chatbot' && (
          <ChatbotView 
            rules={chatbotRules}
            onToggleRule={handleToggleRule}
            onAddRule={handleAddRule}
          />
        )}
        {currentView === 'campaigns' && (
          <CampaignsView 
            campaigns={campaigns}
            segments={segments}
            onAddCampaign={handleAddCampaign}
          />
        )}
        {currentView === 'analytics' && (
          <AnalyticsView agents={agents} />
        )}
        {currentView === 'settings' && (
          <SettingsView />
        )}
      </main>
    </div>
  );
}
