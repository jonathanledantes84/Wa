import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  Filter,
  Layers,
  Cpu,
  Briefcase,
  Code,
  MessageSquare,
  Cloud,
  Zap,
  Globe,
  Star,
  ExternalLink,
  Plus,
  Minus,
  CheckCircle,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  BookOpen,
  GitFork,
  X,
  RefreshCw,
  Terminal,
  Activity,
  Award
} from 'lucide-react';
import { ECOSYSTEM_DATA, CATEGORIES } from './data/ecosystemData';
import { EcosystemItem } from './types';

export default function App() {
  // Navigation & Filtering States
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [ownerFilter, setOwnerFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Interactive UI States
  const [activeProject, setActiveProject] = useState<EcosystemItem | null>(ECOSYSTEM_DATA.find(p => p.id === 'frappe-core') || null);
  const [compareList, setCompareList] = useState<string[]>([]);
  const [isCompareViewActive, setIsCompareViewActive] = useState<boolean>(false);

  // Customized localization configuration simulator states
  const [simulatatingProject, setSimulatingProject] = useState<string>('erpnext');
  const [simulatedIntegrationType, setSimulatedIntegrationType] = useState<string>('afip_invoice');

  // Icons mapper for dynamic category widgets
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layers': return <Layers className="w-5 h-5" id="icon-layers" />;
      case 'Cpu': return <Cpu className="w-5 h-5" id="icon-cpu" />;
      case 'Briefcase': return <Briefcase className="w-5 h-5" id="icon-briefcase" />;
      case 'Code': return <Code className="w-5 h-5" id="icon-code" />;
      case 'MessageSquare': return <MessageSquare className="w-5 h-5" id="icon-message" />;
      case 'Cloud': return <Cloud className="w-5 h-5" id="icon-cloud" />;
      case 'Zap': return <Zap className="w-5 h-5" id="icon-zap" />;
      case 'Globe': return <Globe className="w-5 h-5" id="icon-globe" />;
      default: return <Layers className="w-5 h-5" id="icon-default" />;
    }
  };

  // Filtered List computations
  const filteredProjects = useMemo(() => {
    return ECOSYSTEM_DATA.filter((project) => {
      // Category Match
      const categoryMatch = selectedCategory === 'all' || project.category === selectedCategory;
      
      // Search Bar Match (Fuzzy matches item name, description, tags, and features)
      const query = searchQuery.toLowerCase().trim();
      const textMatch = 
        !query ||
        project.name.toLowerCase().includes(query) ||
        project.description.toLowerCase().includes(query) ||
        (project.subcategory && project.subcategory.toLowerCase().includes(query)) ||
        (project.language && project.language.toLowerCase().includes(query)) ||
        project.keyFeatures.some((feat) => feat.toLowerCase().includes(query));

      // Owner filter match
      const ownerMatch = ownerFilter === 'all' || project.owner === ownerFilter;

      // Status filter match
      const statusMatch = statusFilter === 'all' || project.status === statusFilter;

      return categoryMatch && textMatch && ownerMatch && statusMatch;
    });
  }, [selectedCategory, searchQuery, ownerFilter, statusFilter]);

  // Handle comparative list addition
  const toggleSelectionForCompare = (id: string) => {
    if (compareList.includes(id)) {
      setCompareList(compareList.filter((item) => item !== id));
    } else {
      if (compareList.length >= 3) {
        // limit comparison matrix to maximum 3 items
        return;
      }
      setCompareList([...compareList, id]);
    }
  };

  // Generate mock integration schema codes based on user customization selection
  const generatedMockIntegrationCode = useMemo(() => {
    const projObj = ECOSYSTEM_DATA.find((p) => p.id === simulatatingProject) || ECOSYSTEM_DATA[0];
    
    if (simulatedIntegrationType === 'afip_invoice') {
      return `// Express Server Endpoint - AFIP Argentina Invoice webhook pipeline
// Route listens to CRM or ERP triggers and sends invoice requests directly output to AFIP Web Service
import axios from 'axios';
import { getStripe } from './paymentGateway';

export async function submitToAFIPInvoice(req: any, res: any) {
  const { docId, clientTaxId, items, voucherType } = req.body;
  
  try {
    // 1. Authenticate with AFIP using local PKCS#12 secure certificate (.p12)
    const secureToken = await fetchAFIPAuthToken({
      environment: process.env.AFIP_ENV || 'homologation',
      serviceName: 'wsfe'
    });

    // 2. Fetch last authorized Voucher ID (Punto de Venta & Tipo)
    const lastVoucherIdResponse = await axios.post('https://wswhomo.afip.gov.ar/wsfev1/service.asmx', {
      Token: secureToken.auth,
      Sign: secureToken.signature,
      Cuit: process.env.ARGENTINA_COMPANY_CUIT,
      VoucherType: voucherType || 11, // 11 is 'Factura C'
    });

    const nextVoucherNum = lastVoucherIdResponse.data.lastNumber + 1;

    // 3. Format payload using strict AR compliance variables mapped from ${projObj.name}
    const afipInvoicePayload = {
      Id: docId,
      PtoVta: process.env.ARG_PUNTO_VENTA || 1,
      CbteTipo: voucherType || 11,
      Concepto: 1, // Products only
      DocTipo: 80, // 80 is CUIT
      DocNro: clientTaxId, // Argentine Client CUIT
      CbteDesde: nextVoucherNum,
      CbteHasta: nextVoucherNum,
      CbteFch: new Date().toISOString().slice(0,10).replace(/-/g, ''),
      ImpTotal: items.reduce((sum: number, i: any) => sum + (i.price * i.qty), 0),
      ImpTotConc: 0,
      ImpNeto: items.reduce((sum: number, i: any) => sum + (i.price * i.qty), 0),
      ImpOpEx: 0,
      ImpIVA: 0, // 0 for Monotributo or calculated based on IIBB
      MonId: 'PES', // ARS Argentine Pesos
      MonCotiz: 1
    };

    // 4. Send request to AFIP Web Services Registry
    const emitResponse = await axios.post('https://wswhomo.afip.gov.ar/wsfev1/service.asmx/FECAESolicitar', afipInvoicePayload);

    // 5. Update local record back into database/workspace
    return res.status(200).json({
      success: true,
      cae: emitResponse.data.cae,
      caeVoidDate: emitResponse.data.expirationDate,
      voucherNumber: nextVoucherNum,
      syncedWith: '${projObj.name}'
    });

  } catch (error: any) {
    return res.status(500).json({
      error: 'AFIP WSFE Authorization Failed',
      message: error.message
    });
  }
}`;
    } else if (simulatedIntegrationType === 'mercadopago_alert') {
      return `// Express Real-time Webhook Receiver - MercadoPago instant payment notification
// Mapped instantly output to ${projObj.name} sales updates for real-time order dispatching
import express from 'express';

export async function handleMercadoPagoNotification(req: express.Request, res: express.Response) {
  const { action, data } = req.body;
  
  if (action === 'payment.created' || action === 'payment.updated') {
    const paymentId = data.id;
    
    try {
      // 1. Secure validation against MercadoPago API
      const mpResponse = await fetch(\`https://api.mercadopago.com/v1/payments/\${paymentId}\`, {
        headers: {
          'Authorization': \`Bearer \${process.env.MERCADOPAGO_ACCESS_TOKEN}\`
        }
      });
      const paymentDetails = await mpResponse.json();

      if (paymentDetails.status === 'approved') {
        const orderId = paymentDetails.external_reference;
        const totalPaidARS = paymentDetails.transaction_amount;

        console.log(\`[MercadoPago] Order \${orderId} fully authorized for \${totalPaidARS} ARS.\`);

        // 2. Dispatch automated web update mutation directly back to your SME deployment
        const updateResult = await updateLocalAccountingLedger({
          sourceDoc: orderId,
          targetDocType: 'Sales Invoice',
          clearedAmount: totalPaidARS,
          paymentGateway: 'MercadoPago AR',
          status: 'Paid',
          verifiedToken: paymentDetails.id
        });

        return res.status(200).json({ 
          status: 'success', 
          orderStatus: 'updated',
          syncedWith: '${projObj.name}'
        });
      }
    } catch (err: any) {
      return res.status(500).json({ error: 'MercadoPago Webhook Processing Failed', detail: err.message });
    }
  }

  return res.status(200).json({ received: true });
}`;
    } else {
      return `// Gemini AI Smart Agent Integrations
// Generates summary prompts and extracts automatic categorization fields out of unstructured SME records in ${projObj.name}
import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function processSMELeadSentiment(unstructuredInteraction: string, currentCompanyContext: string) {
  const prompt = \`
    You are an expert sales analyst for Argentine SMEs.
    Analyze the following unstructured customer message/email interaction and produce a strict JSON output matching these attributes:
    1. primaryTopic: string (e.g. "quote_request", "complaint", "billing_delay", "bulk_order_discount")
    2. urgencyLevel: "high" | "medium" | "low"
    3. clientIntentionScore: number (0 to 10 scale of intent)
    4. argTaxCategoryEstimation: "Monotributista" | "Responsable Inscripto" | "Consumidor Final" based on tone and context clues
    5. recommendedResponseDraftARS: string (polite, informative response drafted in local Argentine Spanish, emphasizing payment in ARS)

    Company Context: \${currentCompanyContext}
    Interaction Log: "\${unstructuredInteraction}"
  \`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.1
      }
    });

    const structuredJSON = JSON.parse(response.text);
    return {
      success: true,
      analysis: structuredJSON,
      timestamp: new Date().toISOString()
    };
  } catch (error: any) {
    throw new Error('Gemini classification pipelines failed: ' + error.message);
  }
}`;
    }
  }, [simulatatingProject, simulatedIntegrationType]);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans selection:bg-indigo-500 selection:text-white flex flex-col lg:flex-row" id="root-viewport">
      
      {/* Premium Sidebar - Visible on Desktop */}
      <aside className="hidden lg:flex w-76 bg-white border-r border-slate-200 shrink-0 flex-col sticky top-0 h-screen overflow-y-auto z-40" id="desktop-sidebar">
        
        {/* Brand Header block */}
        <div className="p-6 border-b border-slate-100 animate-fade-in" id="sidebar-brand-block">
          <div className="flex items-center gap-3" id="sidebar-logo-group">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-xl font-bold font-sans shadow-md shadow-indigo-600/10" id="logo-icon">+</div>
            <div id="brand-text">
              <span className="font-extrabold text-base tracking-tight text-slate-950 block leading-tight">FRA ECO</span>
              <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-600 font-bold block mt-0.5">Ecosystem Explorer</span>
            </div>
          </div>
        </div>

        {/* Directory Navigator / Category Select List inside sidebar */}
        <div className="flex-1 px-4 py-6" id="sidebar-nav-container">
          <span className="block px-2 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 mb-3" id="nav-header">Segments Directory</span>
          <nav className="space-y-1" id="nav-list">
            {CATEGORIES.map((cat) => {
              const isActive = selectedCategory === cat.key;
              const count = cat.key === 'all' 
                ? ECOSYSTEM_DATA.length 
                : ECOSYSTEM_DATA.filter(p => p.category === cat.key).length;

              return (
                <button
                  key={cat.key}
                  id={`side-cat-${cat.key}`}
                  onClick={() => setSelectedCategory(cat.key)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl transition-all duration-200 flex items-center justify-between group cursor-pointer border border-transparent ${
                    isActive
                      ? 'bg-indigo-55/80 text-indigo-700 font-semibold border-indigo-100 shadow-xs'
                      : 'hover:bg-slate-50 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3" id={`side-icon-label-${cat.key}`}>
                    <div className={`p-1.5 rounded-lg transition-colors ${
                      isActive ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-500 group-hover:bg-slate-200 group-hover:text-slate-700'
                    }`} id={`side-icon-box-${cat.key}`}>
                      {getCategoryIcon(cat.icon)}
                    </div>
                    <span className="text-xs font-sans font-medium">{cat.label}</span>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full transition-colors ${
                    isActive ? 'bg-indigo-105 text-indigo-805 font-bold' : 'bg-slate-101 text-slate-500'
                  }`} id={`side-count-${cat.key}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Action items in desktop sidebar */}
        <div className="p-4 border-t border-slate-100 space-y-3" id="sidebar-footer">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/65" id="sidebar-compare-widget">
            <span className="block text-[10px] font-mono text-slate-400 uppercase font-bold">Active Comparison Queue</span>
            <div className="flex items-center justify-between mt-2" id="sidebar-comp-actions">
              <span className="text-sm font-bold text-slate-800">{compareList.length} / 3 Items</span>
              <button
                id="btn-side-trigger-compare"
                disabled={compareList.length === 0}
                onClick={() => setIsCompareViewActive(true)}
                className={`px-3 py-1.5 text-[11px] font-semibold rounded-lg transition-all ${
                  compareList.length > 0
                    ? 'bg-indigo-600 text-white cursor-pointer hover:bg-indigo-500 shadow-xs'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                Open Matrix
              </button>
            </div>
          </div>
        </div>

      </aside>

      {/* Main Content Pane */}
      <div className="flex-1 min-w-0 flex flex-col min-h-screen" id="main-content-pane">
        
        {/* Visual Workspace Accent Bar */}
        <div className="h-1 bg-gradient-to-r from-teal-400 via-indigo-500 to-rose-400 w-full" id="premium-top-bar"></div>

        {/* Hero Banner Header Container */}
        <header className="bg-white border-b border-slate-200 shadow-xs" id="header-container">
          <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div id="header-titles">
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-3 py-1 text-[10px] font-mono font-bold tracking-widest bg-indigo-100 text-indigo-800 rounded-md uppercase animate-pulse" id="badge-production">
                    Ecosystem Hub
                  </span>
                  <span className="flex items-center gap-1 text-teal-600 text-xs font-mono" id="badge-sync">
                    <Activity className="w-3.5 h-3.5 animate-pulse text-emerald-500" id="meta-activity" />
                    Live Verified Map
                  </span>
                </div>
                <h1 className="text-3xl sm:text-4xl font-sans font-extrabold tracking-tight text-slate-900 mb-2 leading-none" id="header-main-title">
                  Frappe <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-indigo-800 to-indigo-950">Ecosystem Explorer</span>
                </h1>
                <p className="text-slate-500 text-xs sm:text-sm max-w-2xl mt-1.5 leading-relaxed" id="header-desc">
                  An advanced directory covering both official releases and custom community applications inside the Frappe Framework and ERPNext universe. Curated specifically for modern cloud builders and Argentinian SME localizations.
                </p>
              </div>
              
              {/* Action buttons (Comparison Quick-Access and Local Opportunity status) */}
              <div className="flex flex-wrap items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200" id="comparison-drawer-indicator">
                <div id="compare-text-data">
                  <p className="text-[10px] text-slate-400 font-mono" id="comp-label">Active Comparisons</p>
                  <p className="text-lg font-extrabold text-indigo-600" id="comp-count">
                    {compareList.length} <span className="text-xs font-normal text-slate-400">/ 3 items chosen</span>
                  </p>
                </div>
                <button
                  id="btn-trigger-compare"
                  disabled={compareList.length === 0}
                  onClick={() => setIsCompareViewActive(true)}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 flex items-center gap-1.5 ${
                    compareList.length > 0 
                      ? 'bg-indigo-600 text-white font-semibold shadow-xs cursor-pointer hover:bg-indigo-505' 
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <RefreshCw className="w-3.5 h-3.5 animate-spin-slow" id="comp-refresh-icon" />
                  Compare Matrix
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Global Main Contents Layout */}
        <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8 w-full flex-1 space-y-8" id="main-content-layout">
        
        {/* Argentina Niche Opportunity Banner */}
        <div className="mb-8 p-6 bg-gradient-to-r from-indigo-900 to-slate-900 text-white rounded-2xl border border-indigo-500/10 shadow-xs relative overflow-hidden" id="argentina-compliance-banner">
          <div className="absolute right-0 bottom-0 opacity-10 translate-x-12 translate-y-12 select-none" id="bg-globe">
            <Globe className="w-72 h-72 text-indigo-400" id="glow-globe-svg" />
          </div>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
            <div className="flex-1" id="banner-text-block">
              <div className="flex items-center gap-2 mb-2" id="banner-tagline">
                <span className="flex h-2 w-2 relative" id="pink-pulse-span">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-450 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                </span>
                <span className="text-xs uppercase font-mono tracking-wider text-rose-400 font-bold animate-pulse" id="opportunity-text">
                  Market Gap Analyzer (Argentina 🇦🇷)
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold font-sans tracking-tight mb-2" id="banner-main-title">
                No official AFIP or Local Payment App currently exists in the Awesome Registry.
              </h2>
              <p className="text-indigo-200/90 text-xs sm:text-sm max-w-3xl leading-relaxed" id="banner-main-desc">
                While India, Nepal, Thailand and Germany are backed by robust, official compliance repositories, Argentine SMEs must construct independent scripts to communicate their billing ledgers to AFIP and process transfers with local credit cards. This void is a massive SaaS opportunity.
              </p>
            </div>
            <button
              id="cta-jump-integration-simulator"
              onClick={() => {
                const element = document.getElementById('integration-simulator-card');
                if (element) {
                  element.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="px-5 py-3 bg-indigo-600 hover:bg-indigo-550 text-white font-medium text-xs sm:text-sm rounded-xl transition-all shadow-md shadow-indigo-900/10 shrink-0 flex items-center gap-1.5 cursor-pointer hover:scale-102"
            >
              <Sparkles className="w-4 h-4 text-indigo-200" id="sparkle-svg" />
              Build Local Integration Addon
            </button>
          </div>
        </div>

        {/* Categories Tabs Selector */}
        <section className="mb-0" id="category-scroller-section">
          <div className="flex items-center justify-between mb-4" id="cat-header-row">
            <h3 className="text-xs uppercase tracking-wider font-extrabold text-slate-500 font-mono" id="nav-by-category-title">
              Navigate by Segment
            </h3>
            <span className="text-xs text-slate-550" id="project-count-indicator">
              Showing {filteredProjects.length} of {ECOSYSTEM_DATA.length} modules
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3" id="categories-grid">
            {CATEGORIES.map((cat) => {
              const isActive = selectedCategory === cat.key;
              const belongsToSelected = cat.key === 'all' 
                ? ECOSYSTEM_DATA.length 
                : ECOSYSTEM_DATA.filter(p => p.category === cat.key).length;

              return (
                <button
                  key={cat.key}
                  id={`cat-tab-${cat.key}`}
                  onClick={() => {
                    setSelectedCategory(cat.key);
                  }}
                  className={`flex flex-col items-center justify-center p-3 text-center rounded-xl border transition-all duration-200 cursor-pointer group ${
                    isActive
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm font-semibold'
                      : 'bg-white border-slate-200 text-slate-650 hover:border-indigo-400 hover:bg-indigo-50/10 hover:text-indigo-700'
                  }`}
                >
                  <div className={`p-2 rounded-lg mb-1.5 transition-colors ${
                    isActive ? 'bg-indigo-500 text-white' : 'bg-slate-50 text-slate-500 group-hover:bg-indigo-100/50 group-hover:text-indigo-600'
                  }`} id={`cat-icon-container-${cat.key}`}>
                    {getCategoryIcon(cat.icon)}
                  </div>
                  <span className="text-xs font-sans tracking-tight font-semibold" id={`cat-label-${cat.key}`}>{cat.label}</span>
                  <span className={`text-[10px] mt-1 font-mono px-1.5 py-0.2 rounded-full transition-colors ${
                    isActive ? 'bg-indigo-800 text-indigo-100 font-bold' : 'bg-slate-100 text-slate-505 group-hover:bg-indigo-100/30'
                  }`} id={`cat-count-${cat.key}`}>
                    {belongsToSelected}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Dynamic Filters and Search controls */}
        <section className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs mb-8" id="search-filter-section">
          <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between" id="filter-wrapper-div">
            {/* Search Input Box */}
            <div className="relative flex-1" id="search-box-wrap">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" id="search-icon" />
              <input
                id="input-ecosystem-search"
                type="text"
                placeholder="Search projects by keywords, language (Python/Vue/TS), features or potential use cases..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-all duration-200"
              />
              {searchQuery && (
                <button
                  id="btn-clear-search"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 bg-slate-200/50 hover:bg-slate-200 p-1 rounded-full cursor-pointer"
                >
                  <X className="w-3 h-3" id="clear-svg-icon" />
                </button>
              )}
            </div>

            {/* Selector Filters */}
            <div className="flex flex-wrap items-center gap-3" id="select-filters-grid">
              {/* Creator segment selector */}
              <div className="flex items-center gap-1.5" id="creator-filter-wrap">
                <Filter className="w-3.5 h-3.5 text-slate-400" id="filter-icon-1" />
                <span className="text-xs text-slate-550 font-medium whitespace-nowrap" id="origin-label">Origin:</span>
                <select
                  id="select-owner-filter"
                  value={ownerFilter}
                  onChange={(e) => setOwnerFilter(e.target.value)}
                  className="bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg py-1.5 px-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                >
                  <option value="all">All Ecosystem Origins</option>
                  <option value="frappe">Official Frappe Tech LLC</option>
                  <option value="community">Independent Devs & Community</option>
                  <option value="partner">Certified Silver/Gold Partners</option>
                </select>
              </div>

              {/* Status indicator selector */}
              <div className="flex items-center gap-1.5" id="status-filter-wrap">
                <span className="text-xs text-slate-550 font-medium whitespace-nowrap" id="status-label">Status:</span>
                <select
                  id="select-status-filter"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg py-1.5 px-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                >
                  <option value="all">All Project Statuses</option>
                  <option value="stable">Stable / Standard</option>
                  <option value="active">Active Development</option>
                  <option value="newer">New Release (Next-Gen)</option>
                  <option value="unmaintained">Void Niche / Open Slot</option>
                </select>
              </div>

              {/* Reset filter trigger */}
              {(ownerFilter !== 'all' || statusFilter !== 'all' || searchQuery !== '') && (
                <button
                  id="btn-reset-filters"
                  onClick={() => {
                    setOwnerFilter('all');
                    setStatusFilter('all');
                    setSearchQuery('');
                  }}
                  className="text-xs text-indigo-600 hover:text-indigo-805 font-bold bg-indigo-50 hover:bg-indigo-100 rounded-lg py-1.5 px-3 transition-colors cursor-pointer"
                >
                  Reset Active Filters
                </button>
              )}
            </div>
          </div>
        </section>

        {/* Content Section: Lists on the Left, Rich detailed review panel on the Right */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12" id="lists-and-details-section">
          
          {/* List catalog of packages. Grid spans 7 columns of the 12 total */}
          <div className="lg:col-span-7 flex flex-col gap-4" id="catalog-col">
            <h3 className="text-xs uppercase tracking-wider font-extrabold text-slate-400 font-mono mb-1" id="section-catalog-title">
              Ecosystem Registries
            </h3>

            {filteredProjects.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-xs animate-fade-in" id="empty-state-search">
                <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-3" id="empty-state-alert-icon" />
                <h4 className="text-base font-bold text-slate-800 mb-1" id="empty-state-title">No matching modules found</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4" id="empty-state-desc">
                  Try clearing some filter criteria, adjusting the origin, or searching for other keywords like "Python", "AFIP", or "WhatsApp".
                </p>
                <button
                  id="btn-clear-empty-filters"
                  onClick={() => {
                    setSelectedCategory('all');
                    setOwnerFilter('all');
                    setStatusFilter('all');
                    setSearchQuery('');
                  }}
                  className="px-4 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg cursor-pointer"
                >
                  Clear All Search Parameters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4" id="repositories-items-stack">
                {filteredProjects.map((project) => {
                  const isSelected = activeProject?.id === project.id;
                  const isQueuedForCompare = compareList.includes(project.id);
                  
                  return (
                    <div
                      key={project.id}
                      id={`project-card-${project.id}`}
                      onClick={() => setActiveProject(project)}
                      className={`group rounded-2xl border transition-all duration-200 p-5 cursor-pointer relative ${
                        isSelected
                          ? 'bg-white border-indigo-600 shadow-sm ring-1 ring-indigo-505/20'
                          : 'bg-white border-slate-200 hover:border-indigo-300 hover:shadow-xs'
                      }`}
                    >
                      {/* Left vertical indication border */}
                      <div className={`absolute top-0 bottom-0 left-0 w-1 rounded-l-2xl ${
                        project.category === 'core' ? 'bg-teal-400' :
                        project.category === 'erp' ? 'bg-indigo-500' :
                        project.category === 'dev' ? 'bg-amber-550' :
                        project.category === 'comms' ? 'bg-pink-500' :
                        project.category === 'infra' ? 'bg-sky-500' :
                        project.category === 'integrations' ? 'bg-emerald-500' :
                        project.category === 'regional' ? 'bg-violet-500' : 'bg-slate-400'
                      }`} id={`colour-bar-${project.id}`}></div>

                      <div className="flex items-start justify-between gap-4 pl-2" id="project-top-row">
                        <div id="project-title-area">
                          <div className="flex flex-wrap items-center gap-2 mb-1.5" id="project-meta-badges">
                            <span className="px-2.5 py-0.5 text-[10px] font-mono tracking-wider font-semibold text-slate-500 bg-slate-100 rounded-md capitalize" id={`badge-sub-${project.id}`}>
                              {project.subcategory || project.category}
                            </span>
                            {project.language && (
                              <span className="px-2 py-0.5 text-[10px] font-mono text-indigo-700 bg-indigo-50 rounded-md font-semibold" id={`badge-lang-${project.id}`}>
                                {project.language}
                              </span>
                            )}
                            {project.owner === 'frappe' && (
                              <span className="px-2 py-0.5 text-[10px] font-mono text-teal-850 bg-teal-50 rounded-md font-bold flex items-center gap-0.5" id={`badge-owner-${project.id}`}>
                                <CheckCircle className="w-2.5 h-2.5 text-teal-600" id={`owner-check-${project.id}`} />
                                Official
                              </span>
                            )}
                          </div>
                          
                          <h4 className="text-base font-extrabold text-slate-905 flex items-center gap-1.5" id={`project-header-title-${project.id}`}>
                            {project.name}
                            {project.stars !== undefined && project.stars > 0 && (
                              <span className="inline-flex items-center gap-0.5 text-xs text-amber-500 font-mono font-medium" id={`stars-count-${project.id}`}>
                                <Star className="w-3 h-3 fill-amber-500 text-amber-500" id={`star-svg-${project.id}`} />
                                {project.stars >= 1000 ? `${(project.stars/1000).toFixed(1)}k` : project.stars}
                              </span>
                            )}
                          </h4>
                        </div>

                        {/* Interactive Compare toggles */}
                        <div className="flex items-center gap-2 shrink-0" id="project-compare-actions">
                          <button
                            id={`btn-queue-compare-${project.id}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleSelectionForCompare(project.id);
                            }}
                            title={isQueuedForCompare ? "Remove from Compare Matrix" : "Queue into Compare Matrix (Max 3)"}
                            className={`p-2 rounded-lg border transition-all cursor-pointer ${
                              isQueuedForCompare
                                ? 'bg-rose-50 border-rose-250 text-rose-600'
                                : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            {isQueuedForCompare ? (
                              <Minus className="w-4 h-4" id={`minus-${project.id}`} />
                            ) : (
                              <Plus className="w-4 h-4" id={`plus-${project.id}`} />
                            )}
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-slate-500 mt-2 line-clamp-2 pl-2" id={`project-short-desc-${project.id}`}>
                        {project.description}
                      </p>

                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100 pl-2 text-[11px] text-slate-400 font-mono" id="project-card-footer">
                        <span className="capitalize" id={`origin-type-${project.id}`}>Origin: <strong className="text-slate-650 font-bold">{project.owner}</strong></span>
                        <div className="flex items-center gap-3" id="project-card-links">
                          {project.repoUrl && (
                            <span className="flex items-center gap-0.5 text-indigo-650 group-hover:underline" id={`git-link-${project.id}`}>
                              <GitFork className="w-3 h-3" id={`fork-icon-${project.id}`} /> Source
                            </span>
                          )}
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            project.status === 'stable' ? 'bg-emerald-50 text-emerald-700' :
                            project.status === 'active' ? 'bg-indigo-50 text-indigo-700' :
                            project.status === 'newer' ? 'bg-sky-50 text-sky-700' : 'bg-amber-50 text-amber-700'
                          }`} id={`status-pill-${project.id}`}>
                            {project.status === 'unmaintained' ? 'Void / Niche' : project.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Detailed Review Sheet. Grid spans 5 columns of 12 total */}
          <div className="lg:col-span-5" id="detail-sheet-col">
            <h3 className="text-xs uppercase tracking-wider font-extrabold text-slate-400 font-mono mb-2" id="section-detail-sheet-title">
              Structural Specs Review
            </h3>

            {activeProject ? (
              <div className="bg-white text-slate-800 rounded-2xl border border-slate-205 shadow-xs sticky top-6 overflow-hidden animate-fade-in" id="spec-detail-panel-active">
                
                {/* Accent Top Bar based on active selected category */}
                <div className={`h-1.5 w-full ${
                  activeProject.category === 'core' ? 'bg-teal-400' :
                  activeProject.category === 'erp' ? 'bg-indigo-500' :
                  activeProject.category === 'dev' ? 'bg-amber-500' :
                  activeProject.category === 'comms' ? 'bg-pink-500' :
                  activeProject.category === 'infra' ? 'bg-sky-450' :
                  activeProject.category === 'integrations' ? 'bg-emerald-500' :
                  activeProject.category === 'regional' ? 'bg-violet-500' : 'bg-slate-400'
                }`} id="category-colored-stripe"></div>

                <div className="p-6" id="panel-spec-inner">
                  {/* Category + Owner Tags */}
                  <div className="flex items-center justify-between gap-4 mb-4" id="panel-meta-tags">
                    <span className="px-2.5 py-1 text-[10px] font-mono tracking-widest uppercase bg-slate-100 text-slate-600 rounded font-semibold" id="panel-category-badge">
                      {activeProject.category} / {activeProject.subcategory}
                    </span>
                    <span className={`text-[10px] font-mono uppercase tracking-wider font-semibold ${
                      activeProject.owner === 'frappe' ? 'text-teal-600' : 
                      activeProject.owner === 'partner' ? 'text-indigo-600' : 'text-slate-500'
                    }`} id="panel-owner-badge">
                      Owner: {activeProject.owner}
                    </span>
                  </div>

                  {/* Program Title and Stars counter */}
                  <div className="flex items-start justify-between gap-4 mb-4" id="panel-title-block">
                    <h4 className="text-2xl font-extrabold font-sans tracking-tight text-slate-900" id="panel-project-name">
                      {activeProject.name}
                    </h4>
                    {activeProject.stars !== undefined && activeProject.stars > 0 ? (
                      <div className="flex items-center gap-1 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200" id="stars-capsule">
                        <Star className="w-4 h-4 fill-amber-500 text-amber-500" id="panel-star-icon" />
                        <span className="text-xs font-mono font-bold text-slate-800" id="panel-star-count">
                          {activeProject.stars}
                        </span>
                      </div>
                    ) : (
                      <span className="px-2.5 py-1 text-[10px] font-mono uppercase bg-rose-50 text-rose-700 border border-rose-100 rounded font-semibold" id="void-niche-badge">
                        Open Market Gap
                      </span>
                    )}
                  </div>

                  {/* Main Description */}
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6" id="panel-description">
                    {activeProject.description}
                  </p>

                  {/* Actions Links */}
                  <div className="flex flex-wrap items-center gap-3 mb-6" id="panel-external-links">
                    {activeProject.repoUrl && (
                      <a
                        href={activeProject.repoUrl}
                        target="_blank"
                        rel="noreferrer"
                        id="link-github-repo"
                        className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-lg transition-colors flex items-center gap-1.5"
                      >
                        <ExternalLink className="w-3.5 h-3.5" id="github-ext-icon" />
                        GitHub Repository
                      </a>
                    )}
                    {activeProject.docsUrl && (
                      <a
                        href={activeProject.docsUrl}
                        target="_blank"
                        rel="noreferrer"
                        id="link-documentation"
                        className="py-2 px-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
                      >
                        <BookOpen className="w-3.5 h-3.5" id="docs-book-icon" />
                        Official Docs
                      </a>
                    )}
                  </div>

                  {/* Target Features Bullets */}
                  <div className="mb-6" id="panel-features-block">
                    <h5 className="text-xs uppercase tracking-wider font-extrabold text-indigo-700 font-mono mb-2.5 flex items-center gap-1" id="key-features-heading">
                      <Sparkles className="w-3 h-3 text-indigo-550" id="bullets-spark-icon" />
                      Key Capabilities Included
                    </h5>
                    <ul className="space-y-2 text-xs text-slate-600" id="bullets-list">
                      {activeProject.keyFeatures.map((feat, i) => (
                        <li key={i} className="flex items-start gap-2" id={`bullet-item-${i}`}>
                          <CheckCircle className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" id={`check-item-${i}`} />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Core engineering relevance - tailored output */}
                  {activeProject.relevanceToClientum && (
                    <div className="bg-indigo-50/70 p-4 rounded-xl border border-indigo-100 mb-6 animate-fade-in" id="panel-relevance-card">
                      <h5 className="text-xs uppercase tracking-wider font-extrabold text-indigo-700 font-mono mb-1.5 flex items-center gap-1" id="relevance-heading">
                        <Terminal className="w-3.5 h-3.5 text-indigo-650" id="term-icon-panel" />
                        Relevance to Modern Cloud Apps (Clientum Stack)
                      </h5>
                      <p className="text-xs text-slate-600 leading-relaxed" id="relevance-text-panel">
                        {activeProject.relevanceToClientum}
                      </p>
                    </div>
                  )}

                  {/* Opportunities targeting Argentina local market context */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 mb-2" id="panel-argentina-context">
                    <div className="flex items-center gap-2 mb-1.5" id="arg-panel-header">
                      <Globe className="w-4 h-4 text-rose-500 animate-spin-slow" id="panel-arg-globe" />
                      <h5 className="text-xs uppercase tracking-wider font-extrabold text-rose-700 font-mono" id="arg-panel-heading">
                        Argentinian Biz Potential 🇦🇷
                      </h5>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed" id="arg-panel-potential-desc">
                      {activeProject.argentinaPotential || "Provides foundational architecture which, once expanded with local tax calculation maps, completely overrides high-cost licensing setups."}
                    </p>
                  </div>

                </div>
              </div>
            ) : (
              <div className="bg-white text-slate-500 rounded-2xl p-12 text-center border border-slate-200 shadow-xs h-96 flex flex-col items-center justify-center animate-fade-in" id="spec-detail-panel-empty">
                <Layers className="w-12 h-12 text-slate-300 mx-auto mb-3" id="empty-state-layer-icon" />
                <h4 className="text-base font-extrabold text-slate-800 mb-1" id="empty-detail-title-font-sans">No project selected</h4>
                <p className="text-xs text-slate-450 max-w-xs mx-auto leading-relaxed" id="empty-detail-desc text-slate-505">
                  Select a repository cards from the left registry index row to read its full architectural profiles, capabilities, and local Argentine integration potential.
                </p>
              </div>
            )}
          </div>
        </section>

        {/* Customized localization configuration simulator - Interactive Developer Feature */}
        <section className="mb-12" id="integration-simulator-card">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8" id="simulator-card-wrapper">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-100" id="simulator-header">
              <div id="simulator-header-text">
                <span className="px-2.5 py-1 text-[10px] font-mono tracking-widest uppercase bg-indigo-50 text-indigo-700 rounded font-semibold" id="sim-badge">
                  Developer Code Sandbox Generator
                </span>
                <h3 className="text-2xl font-bold font-sans tracking-tight text-slate-900 mt-1.5" id="sim-title">
                  Argentina Local Addon Simulator
                </h3>
                <p className="text-slate-500 text-xs sm:text-sm mt-1" id="sim-desc">
                  Select a target Frappe ecosystem module and generate custom, production-ready server integration scripts connecting to AFIP web services, MercadoPago webhooks, or Gemini classifiers.
                </p>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100" id="sim-indicator">
                <CheckCircle className="w-4 h-4 text-emerald-500 animate-pulse" id="check-icon-sim" />
                <span>Node Full-Stack Compliant</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="simulator-row">
              
              {/* Controls Column */}
              <div className="lg:col-span-5 flex flex-col gap-5" id="simulator-controls">
                {/* Step 1: Select target app */}
                <div id="sim-step-1-wrap">
                  <label className="block text-xs font-mono uppercase tracking-wider font-bold text-slate-500 mb-2" id="label-target-app">
                    1. Select Target Ecosystem Module
                  </label>
                  <select
                    id="select-sim-module"
                    value={simulatatingProject}
                    onChange={(e) => setSimulatingProject(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-sm rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {ECOSYSTEM_DATA.filter(p => p.status !== 'unmaintained').map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.subcategory || p.category})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Step 2: Select integration action */}
                <div id="sim-step-2-wrap">
                  <label className="block text-xs font-mono uppercase tracking-wider font-bold text-slate-500 mb-2" id="label-action-type">
                    2. Select Integration Pipeline Protocol
                  </label>
                  <div className="grid grid-cols-1 gap-2.5" id="integration-selectors-group">
                    
                    {/* AFIP Option */}
                    <button
                      id="opt-afip-invoice"
                      onClick={() => setSimulatedIntegrationType('afip_invoice')}
                      className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                        simulatedIntegrationType === 'afip_invoice'
                          ? 'bg-rose-50/50 border-rose-400 ring-1 ring-rose-400/20'
                          : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <Globe className={`w-5 h-5 shrink-0 mt-0.5 ${simulatedIntegrationType === 'afip_invoice' ? 'text-rose-500' : 'text-slate-400'}`} id="arg-logo-globe-sim" />
                      <div id="afip-desc-block">
                        <span className="block text-xs font-bold text-slate-800" id="lbl-afip">AFIP Factura Electrónica WSFE</span>
                        <span className="block text-[11px] text-slate-500 mt-0.5 leading-tight" id="desc-afip">
                          Automate local fiscal billing authorizations using secure PKCS#12 tokens and XML soap mappings.
                        </span>
                      </div>
                    </button>

                    {/* MercadoPago Option */}
                    <button
                      id="opt-mp-alert"
                      onClick={() => setSimulatedIntegrationType('mercadopago_alert')}
                      className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                        simulatedIntegrationType === 'mercadopago_alert'
                          ? 'bg-indigo-50/50 border-indigo-400 ring-1 ring-indigo-400/20'
                          : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <Zap className={`w-5 h-5 shrink-0 mt-0.5 ${simulatedIntegrationType === 'mercadopago_alert' ? 'text-indigo-600' : 'text-slate-400'}`} id="mp-logo-zap-sim" />
                      <div id="mp-desc-block">
                        <span className="block text-xs font-bold text-slate-800" id="lbl-mp">MercadoPago Instant Alerts Hook</span>
                        <span className="block text-[11px] text-slate-500 mt-0.5 leading-tight" id="desc-mp">
                          Listen to incoming customer transfers in Argentina and trigger instant ledger updates.
                        </span>
                      </div>
                    </button>

                    {/* Gemini AI Option */}
                    <button
                      id="opt-gemini-chat"
                      onClick={() => setSimulatedIntegrationType('gemini_classify')}
                      className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                        simulatedIntegrationType === 'gemini_classify'
                          ? 'bg-teal-55/20 border-teal-400 ring-1 ring-teal-400/20'
                          : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <Sparkles className={`w-5 h-5 shrink-0 mt-0.5 ${simulatedIntegrationType === 'gemini_classify' ? 'text-teal-560' : 'text-slate-400'}`} id="gemini-sparkle-sim" />
                      <div id="gemini-desc-block">
                        <span className="block text-xs font-bold text-slate-800" id="lbl-gemini">Gemini Smart AI SME Classifier</span>
                        <span className="block text-[11px] text-slate-500 mt-0.5 leading-tight" id="desc-gemini">
                          Classify customer sentiment, estimate tax profiles, and draft targeted native replies.
                        </span>
                      </div>
                    </button>

                  </div>
                </div>
                {/* Additional Developer Advice Box */}
                <div className="p-4 bg-slate-50 text-slate-650 rounded-xl border border-slate-200" id="simulator-info-tip-box">
                  <div className="flex items-center gap-2 mb-1.5" id="tip-header">
                    <Terminal className="text-indigo-650 w-4 h-4" id="tip-term-svg" />
                    <span className="text-[10px] font-mono tracking-wider font-extrabold text-indigo-700" id="tip-badge">SME Architectural Pattern</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-slate-550" id="tip-descr">
                    These wrappers are engineered conceptually using standard Express.js and ES6 TypeScript. By hosting these integration endpoints on a secure server-side setup, sensitive private tokens like MercadoPago keys and your AFIP certs are kept safe from the browser.
                  </p>
                </div>
              </div>

              {/* Code Generator Output Column. Grid spans 7 columns */}
              <div className="lg:col-span-7 flex flex-col" id="simulator-code-display">
                <div className="bg-slate-900 rounded-t-xl px-4 py-2 border-b border-slate-800 flex items-center justify-between font-mono text-[10px] text-slate-400" id="code-terminal-header">
                  <div className="flex items-center gap-1.5" id="code-header-dots">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
                    <span className="ml-1 text-slate-200" id="terminal-filename">server/integrations/argentinaAddon.ts</span>
                  </div>
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-305 rounded" id="code-extension-badge">TypeScript (ES6)</span>
                </div>

                <div className="relative flex-1" id="code-content-wrapper">
                  <pre className="bg-slate-950 text-slate-200 p-4 rounded-b-xl overflow-x-auto font-mono text-[11px] leading-normal h-112 border border-slate-900" id="generated-code-pre">
                    <code>{generatedMockIntegrationCode}</code>
                  </pre>
                </div>
              </div>

            </div>
          </div>
        </section>

      </main>

      {/* Slide-over Compare View panel */}
      <AnimatePresence id="compare-animate-presence">
        {isCompareViewActive && (
          <motion.div
            id="compare-modal-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in"
            onClick={() => setIsCompareViewActive(false)}
          >
            <motion.div
              id="compare-modal-body"
              initial={{ scale: 0.97, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.97, y: 10 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-5xl w-full overflow-hidden"
            >
              {/* Header */}
              <div className="bg-white border-b border-slate-150 px-6 py-5 flex items-center justify-between" id="compare-modal-head">
                <div id="compare-head-text">
                  <h3 className="text-lg font-extrabold font-sans tracking-tight text-slate-900" id="mdl-title">Architectural Comparison Matrix</h3>
                  <p className="text-xs text-slate-500" id="mdl-desc">Side-by-side performance, stack and business parameters of selected modules</p>
                </div>
                <button
                  id="btn-close-compare-modal"
                  onClick={() => setIsCompareViewActive(false)}
                  className="p-2 text-slate-400 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors border border-slate-200/50"
                >
                  <X className="w-4 h-4" id="mdl-close-svg" />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 overflow-y-auto max-h-160" id="compare-matrix-scroll">
                {compareList.length === 0 ? (
                  <div className="py-12 text-center" id="empty-modal-alert">
                    <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-3" id="alert-compare-modal" />
                    <p className="text-sm font-semibold text-slate-705" id="empty-modal-text">No items chosen for comparison</p>
                    <p className="text-xs text-slate-500 mt-1" id="empty-modal-subtext">Click the "+" icon on the project cards in the background to queue items here.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6" id="compare-grid-layout">
                    
                    {/* Parameters Header side-col */}
                    <div className="hidden md:flex flex-col gap-4 font-mono text-[10px] uppercase font-bold text-slate-400 pt-32" id="grid-header-parameters">
                      <div className="h-14 flex items-center font-bold" id="p1">Owner & Origin</div>
                      <div className="h-14 flex items-center font-bold border-t border-slate-100" id="p2">Primary Language</div>
                      <div className="h-14 flex items-center font-bold border-t border-slate-100" id="p3">Current Status</div>
                      <div className="h-32 flex items-start pt-3 border-t border-slate-100" id="p4">Ecosystem Category</div>
                      <div className="h-32 flex items-start pt-3 border-t border-slate-100" id="p5">Local Business Value</div>
                    </div>

                    {/* Columns representing selected items in list */}
                    {ECOSYSTEM_DATA.filter((p) => compareList.includes(p.id)).map((project) => (
                      <div key={project.id} className="bg-slate-50 p-4 rounded-xl border border-slate-200 relative" id={`comp-col-${project.id}`}>
                        
                        {/* Remove item trigger button */}
                        <button
                          id={`btn-remove-comp-col-${project.id}`}
                          onClick={() => setCompareList(compareList.filter(id => id !== project.id))}
                          className="absolute top-2 right-2 text-slate-400 hover:text-red-500 bg-white hover:bg-red-50 p-1.5 rounded-full border border-slate-200 shadow-sm cursor-pointer"
                        >
                          <Minus className="w-3" id={`minus-icon-${project.id}`} />
                        </button>

                        <div className="h-28 flex flex-col justify-between pb-4" id={`p-head-${project.id}`}>
                          <div id="sub-type-box">
                            <span className="text-[9px] uppercase tracking-wider bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded font-mono font-bold" id={`p-sub-${project.id}`}>
                              {project.subcategory || project.category}
                            </span>
                          </div>
                          <h4 className="font-bold text-slate-900 mt-2 text-base line-clamp-1" id={`p-name-${project.id}`}>{project.name}</h4>
                          <span className="text-xs text-amber-500 font-mono flex items-center gap-0.5 mt-0.5" id={`p-stars-${project.id}`}>
                            <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" id={`star-p-${project.id}`} />
                            {project.stars || 'Void Slot'}
                          </span>
                        </div>

                        {/* Attribute Matrix Fields */}
                        <div className="space-y-4" id={`matrix-attributes-${project.id}`}>
                          
                          {/* Owner description */}
                          <div className="md:h-14 flex flex-col justify-center border-t border-slate-200/60 pt-2 md:pt-0" id={`p-owner-block-${project.id}`}>
                            <span className="text-[10px] md:hidden font-mono uppercase font-bold text-slate-400">Owner</span>
                            <span className="text-xs font-semibold capitalize text-slate-850" id={`p-owner-val-${project.id}`}>{project.owner}</span>
                          </div>

                          {/* Code Language description */}
                          <div className="md:h-14 flex flex-col justify-center border-t border-slate-200/60 pt-2 md:pt-0" id={`p-lang-block-${project.id}`}>
                            <span className="text-[10px] md:hidden font-mono uppercase font-bold text-slate-400">Language</span>
                            <span className="text-xs font-mono text-indigo-700 bg-indigo-50 block py-0.5 px-2 rounded w-fit font-semibold" id={`p-lang-val-${project.id}`}>
                              {project.language || "None"}
                            </span>
                          </div>

                          {/* Development status description */}
                          <div className="md:h-14 flex flex-col justify-center border-t border-slate-200/60 pt-2 md:pt-0" id={`p-status-block-${project.id}`}>
                            <span className="text-[10px] md:hidden font-mono uppercase font-bold text-slate-400">Status</span>
                            <span className="text-xs capitalize font-semibold text-slate-800" id={`p-status-val-${project.id}`}>{project.status}</span>
                          </div>

                          {/* Category Description */}
                          <div className="md:h-32 flex flex-col border-t border-slate-200/60 pt-2" id={`p-desc-block-${project.id}`}>
                            <span className="text-[10px] md:hidden font-mono uppercase font-bold text-slate-400">Category & Purpose</span>
                            <p className="text-xs text-slate-600 leading-relaxed mt-1 scrollbar-hidden overflow-y-auto max-h-24" id={`p-desc-val-${project.id}`}>
                              {project.description}
                            </p>
                          </div>

                          {/* Potential Argentine client values */}
                          <div className="md:h-32 flex flex-col border-t border-slate-200/60 pt-2" id={`p-arg-block-${project.id}`}>
                            <span className="text-[10px] md:hidden font-mono uppercase font-bold text-slate-400">Local Value</span>
                            <p className="text-xs text-slate-650 leading-relaxed font-sans mt-1 scrollbar-hidden overflow-y-auto max-h-24" id={`p-arg-val-${project.id}`}>
                              {project.argentinaPotential || "Stable enterprise resource management patterns that solve administrative fragmentation natively."}
                            </p>
                          </div>

                        </div>

                      </div>
                    ))}

                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="bg-slate-55 px-6 py-4 border-t border-slate-150 flex justify-end" id="compare-modal-foot">
                <button
                  id="btn-close-modal-footer"
                  onClick={() => setIsCompareViewActive(false)}
                  className="px-5 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-550 text-white rounded-lg transition-colors cursor-pointer shadow-sm hover:scale-102"
                >
                  Close Matrix
                </button>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer copyright */}
      <footer className="bg-white text-slate-450 py-8 border-t border-slate-200 text-center text-xs" id="footer-credits">
        <p id="credits-p1">Frappe Ecosystem Explorer © 2026. Made with Google AI Studio and Antigravity Agent.</p>
        <p className="mt-1.5 text-slate-500 font-mono" id="credits-p2">This directory is for software engineering research purposes. All trademark rights of Frappe / ERPNext remain reserved by Frappe Tech LLC.</p>
      </footer>

      </div>
    </div>
  );
}
