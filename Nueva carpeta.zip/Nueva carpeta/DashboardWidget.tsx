import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { TrendingUp, CreditCard, Users, ShieldAlert, BarChart3 } from 'lucide-react';
import { SubscriptionRecord } from '../types';

interface DashboardWidgetProps {
  subscriptions: SubscriptionRecord[];
  mrrAmount: number;
}

const MRR_HISTORY_DATA = [
  { month: 'Feb', mrr: 11200, activeSubs: 38, churnRate: 1.2 },
  { month: 'Mar', mrr: 12100, activeSubs: 41, churnRate: 0.9 },
  { month: 'Apr', mrr: 12900, activeSubs: 44, churnRate: 1.5 },
  { month: 'May', mrr: 13450, activeSubs: 45, churnRate: 0.8 },
  { month: 'Jun', mrr: 13900, activeSubs: 47, churnRate: 0.5 },
  { month: 'Jul', mrr: 14250, activeSubs: 48, churnRate: 0.6 },
];

export const DashboardWidget: React.FC<DashboardWidgetProps> = ({ subscriptions, mrrAmount }) => {
  const [activeTab, setActiveTab] = useState<'mrr' | 'churn' | 'plans'>('mrr');

  // Calculate plan distribution from subscriptions
  const planCounts = subscriptions.reduce((acc, sub) => {
    acc[sub.planId] = (acc[sub.planId] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const planDistributionData = [
    { name: 'Starter ($49)', count: planCounts['starter'] || 1, fill: '#3b82f6' },
    { name: 'Professional ($149)', count: planCounts['professional'] || 3, fill: '#8b5cf6' },
    { name: 'Enterprise ($399)', count: planCounts['enterprise'] || 2, fill: '#10b981' },
  ];

  return (
    <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-5">
      
      {/* Header and Tab Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-400" />
            SaaS Financial Analytics & Churn Metrics
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time Recharts visualization of MRR expansion, active tenant counts, and churn rates
          </p>
        </div>

        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('mrr')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'mrr'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            MRR Trend
          </button>
          <button
            onClick={() => setActiveTab('churn')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'churn'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Churn Rate
          </button>
          <button
            onClick={() => setActiveTab('plans')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'plans'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Plan Tiers
          </button>
        </div>
      </div>

      {/* Recharts Container */}
      <div className="h-72 w-full pt-2">
        {activeTab === 'mrr' && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={MRR_HISTORY_DATA} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="mrrGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" stroke="#64748b" textAnchor="end" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} tickFormatter={(val) => `$${val}`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                formatter={(value: any) => [`$${value.toLocaleString()}`, 'Monthly Recurring Revenue']}
              />
              <Area type="monotone" dataKey="mrr" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#mrrGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        )}

        {activeTab === 'churn' && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={MRR_HISTORY_DATA} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="churnGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} tickFormatter={(val) => `${val}%`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                formatter={(value: any) => [`${value}%`, 'Customer Churn Rate']}
              />
              <Area type="monotone" dataKey="churnRate" stroke="#a855f7" strokeWidth={2.5} fillOpacity={1} fill="url(#churnGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        )}

        {activeTab === 'plans' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={planDistributionData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                formatter={(value: any) => [`${value} Tenants`, 'Active Subscriptions']}
              />
              <Bar dataKey="count" fill="#6366f1" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Mini Financial Summary Cards */}
      <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-800 text-xs">
        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
          <span className="text-slate-500 block text-[10px] uppercase">Current MRR</span>
          <span className="text-emerald-400 font-bold font-mono text-sm">${mrrAmount.toLocaleString()}</span>
        </div>
        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
          <span className="text-slate-500 block text-[10px] uppercase">Avg Churn Rate</span>
          <span className="text-purple-400 font-bold font-mono text-sm">0.65%</span>
        </div>
        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
          <span className="text-slate-500 block text-[10px] uppercase">LTV (Customer Lifetime)</span>
          <span className="text-indigo-400 font-bold font-mono text-sm">$4,850</span>
        </div>
      </div>

    </div>
  );
};
