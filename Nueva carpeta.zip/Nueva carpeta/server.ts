import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Lazy initialize Gemini client
  let aiClient: GoogleGenAI | null = null;
  function getAIClient() {
    if (!aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        aiClient = new GoogleGenAI({ apiKey });
      }
    }
    return aiClient;
  }

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'Frappe WhatsApp SaaS CRM' });
  });

  // AI Endpoint: Smart WhatsApp Reply Generator
  app.post('/api/ai/suggest-reply', async (req, res) => {
    try {
      const { chatHistory, leadName, company, agentName } = req.body;
      const ai = getAIClient();

      if (!ai) {
        // Fallback response if Gemini API key is not configured
        return res.json({
          suggestions: [
            `Hi ${leadName}! Thank you for your message. How can I assist you with Frappe CRM today?`,
            `Hello ${leadName}, I reviewed your inquiry regarding ${company || 'our services'}. Would you like to schedule a 10-minute demo?`,
            `Thanks for reaching out! Here is a link to our WhatsApp WABA setup guide: https://frappecrm.io/waba-docs`
          ]
        });
      }

      const prompt = `You are an AI Sales Assistant for Frappe WhatsApp SaaS CRM.
Lead Name: ${leadName || 'Valued Lead'}
Company: ${company || 'N/A'}
Agent Name: ${agentName || 'Sales Representative'}

Recent WhatsApp Conversation History:
${JSON.stringify(chatHistory, null, 2)}

Task: Provide 3 short, professional, friendly, and high-converting WhatsApp reply options that ${agentName} can send to ${leadName}.
Keep replies concise, formatted cleanly for WhatsApp (with optional emojis), and actionable.
Return JSON array format: ["Option 1", "Option 2", "Option 3"]`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const text = response.text || '[]';
      let suggestions = [];
      try {
        suggestions = JSON.parse(text);
      } catch (e) {
        suggestions = [
          `Hi ${leadName}, thanks for your message! How can I help you today?`,
          `Hello ${leadName}, happy to provide more details about our WhatsApp CRM features.`,
          `Thanks for reaching out! Would you be free for a quick call today?`
        ];
      }

      res.json({ suggestions });
    } catch (error: any) {
      console.error('AI suggest reply error:', error);
      res.status(500).json({ error: error.message || 'Failed to generate AI replies' });
    }
  });

  // AI Endpoint: Lead Qualification & Sentiment Analysis
  app.post('/api/ai/qualify-lead', async (req, res) => {
    try {
      const { chatHistory, leadName } = req.body;
      const ai = getAIClient();

      if (!ai) {
        return res.json({
          score: 85,
          summary: 'High purchase intent expressed for multi-agent WhatsApp inbox.',
          recommendedStage: 'Qualified',
          keyTakeaways: ['Wants multi-agent workspace', 'Budget approved', 'Needs fast implementation']
        });
      }

      const prompt = `Analyze this WhatsApp chat with lead "${leadName}":
${JSON.stringify(chatHistory, null, 2)}

Provide JSON response with:
1. "score": number from 0 to 100 (Intent score)
2. "summary": short 1-2 sentence executive summary
3. "recommendedStage": string choice from ["New", "Contacted", "Qualified", "Proposal", "Won", "Lost"]
4. "keyTakeaways": string array of 3 key pain points or requirements

Respond strictly in JSON format.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const result = JSON.parse(response.text || '{}');
      res.json(result);
    } catch (error: any) {
      console.error('AI qualify lead error:', error);
      res.status(500).json({ error: error.message || 'Failed to analyze lead' });
    }
  });

  // AI Endpoint: Broadcast Campaign Copywriting
  app.post('/api/ai/generate-campaign', async (req, res) => {
    try {
      const { campaignGoal, targetAudience, tone } = req.body;
      const ai = getAIClient();

      if (!ai) {
        return res.json({
          headerText: 'Exclusive WhatsApp Upgrade Offer 🚀',
          bodyText: `Hi {{1}}, boost your team's sales speed by 3x with automated WhatsApp CRM workflows! Claim 2,000 free broadcast credits today.`,
          footerText: 'Frappe CRM Growth Plan',
          buttons: [
            { type: 'QUICK_REPLY', text: 'Claim Offer Now' },
            { type: 'QUICK_REPLY', text: 'Talk to Sales' }
          ]
        });
      }

      const prompt = `Create a Meta-approved WhatsApp Broadcast Template for marketing.
Goal: ${campaignGoal}
Target Audience: ${targetAudience}
Tone: ${tone || 'Professional & Engaging'}

Output JSON schema:
{
  "headerText": "Short catchy header (max 60 chars)",
  "bodyText": "Body text with {{1}} variable for lead name",
  "footerText": "Short footer disclaimer",
  "buttons": [
    {"type": "QUICK_REPLY", "text": "Button 1"},
    {"type": "QUICK_REPLY", "text": "Button 2"}
  ]
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const result = JSON.parse(response.text || '{}');
      res.json(result);
    } catch (error: any) {
      console.error('AI campaign copy error:', error);
      res.status(500).json({ error: error.message || 'Failed to generate campaign copy' });
    }
  });

  // Simulate Webhook trigger or incoming message test
  app.post('/api/whatsapp/webhook', (req, res) => {
    console.log('Incoming WhatsApp Webhook:', req.body);
    res.json({ status: 'received', timestamp: new Date().toISOString() });
  });

  // Vite middleware setup for development vs static build in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Frappe WhatsApp CRM server running on http://localhost:${PORT}`);
  });
}

startServer();
