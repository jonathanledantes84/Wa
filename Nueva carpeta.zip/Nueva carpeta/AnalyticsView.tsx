import React from 'react';
import { BarChart3, TrendingUp, DollarSign, Clock, Users, ArrowUpRight } from 'lucide-react';
import { Agent } from '../types';

interface AnalyticsViewProps {
  agents: Agent[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ agents }) => {
  return (
    <div className="p-8 space-y-8 bg-[#070d1f] min-h-screen text-slate-100">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs bg-emerald-500/10 text-emerald-400 font-semibold px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1.5">
            <BarChart3 className="w-3.5 h-3.5" /> Métricas y Rendimiento Comercial
          </span>
          <span className="text-xs text-slate-400">Mes en curso</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-white">Analíticas y Reportes de Ventas</h1>
        <p className="text-sm text-slate-400">Analiza el rendimiento de tus agentes, tiempos de respuesta y conversiones por WhatsApp.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Tasa de Conversión General</span>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">+12.4%</span>
          </div>
          <h3 className="text-3xl font-bold text-white">34.8%</h3>
          <p className="text-xs text-slate-400">De leads nuevos a clientes cerrados en WhatsApp</p>
        </div>

        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Mensajes Procesados IA</span>
            <span className="text-xs font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">24/7 Bot</span>
          </div>
          <h3 className="text-3xl font-bold text-white">14,820</h3>
          <p className="text-xs text-slate-400">Atendidos automáticamente por Clientum IA</p>
        </div>

        <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Ingresos Totales Mes</span>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">+31% vs Julio</span>
          </div>
          <h3 className="text-3xl font-bold text-white">$65,900 USD</h3>
          <p className="text-xs text-slate-400">Suma de tratos ganados</p>
        </div>
      </div>

      <div className="bg-[#0B132B] border border-[#1C2541] rounded-2xl p-6 shadow-xl space-y-6">
        <h3 className="text-base font-bold text-white">Rendimiento por Agente de Ventas</h3>
        
        <div className="space-y-4">
          {agents.map((ag) => (
            <div key={ag.id} className="p-4 rounded-xl bg-[#1C2541]/50 border border-slate-700/60 flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <img src={ag.avatar} alt={ag.name} className="w-11 h-11 rounded-full object-cover border border-slate-700" />
                <div>
                  <h4 className="text-sm font-bold text-white">{ag.name}</h4>
                  <p className="text-xs text-emerald-400">{ag.role} • {ag.activeChatsCount} chats activos</p>
                </div>
              </div>

              <div className="flex items-center gap-8">
                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Tratos Cerrados</span>
                  <span className="text-sm font-bold text-white">{ag.closedDealsThisMonth} este mes</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Estado</span>
                  <span className="text-xs font-semibold text-emerald-400 uppercase">{ag.status}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
