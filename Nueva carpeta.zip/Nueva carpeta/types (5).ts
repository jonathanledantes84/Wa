export type LeadStage = 'New' | 'Contacted' | 'Qualified' | 'Proposal' | 'Won' | 'Lost';

export type Role = 'admin' | 'manager' | 'agent';

export interface Tenant {
  id: string;
  name: string;
  domain: string;
  wabaId: string;
  phoneNumberId: string;
  displayPhoneNumber: string;
  isConnected: boolean;
  plan: 'Starter' | 'Growth' | 'Enterprise';
  monthlyCredits: number;
  creditsUsed: number;
  webhookUrl: string;
  webhookSecret: string;
}

export interface AgentPermissions {
  canCreateCampaigns: boolean;
  canUseAiCopilot: boolean;
  canManageTemplates: boolean;
  canExportLeads: boolean;
  canManageErpOrders: boolean;
  canManageCluster: boolean;
  canViewAnalytics: boolean;
}

export interface AgentGoal {
  id: string;
  title: string;
  target: number;
  current: number;
  unit: string;
  deadline: string;
  status: 'In Progress' | 'Achieved' | 'At Risk';
}

export interface AgentTask {
  id: string;
  title: string;
  leadId?: string;
  leadName?: string;
  convId?: string;
  priority: 'High' | 'Medium' | 'Low';
  status: 'Pending' | 'In Progress' | 'Completed';
  assignedAt: string;
  dueDate: string;
  notes?: string;
  assignedBy?: string;
}

export interface Agent {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: Role;
  status: 'online' | 'busy' | 'offline';
  assignedLeadsCount: number;
  permissions?: AgentPermissions;
  goals?: AgentGoal[];
  active_tasks?: AgentTask[];
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  company: string;
  dealValue: number;
  stage: LeadStage;
  source: 'WhatsApp' | 'Meta Ads' | 'Website' | 'Manual' | 'Referral';
  assignedAgentId?: string;
  assignedAgentName?: string;
  tags: string[];
  lastContacted: string;
  notes: string;
  score: number; // 0-100 AI Intent Score
  summary?: string;
  city?: string;
  unreadCount?: number;
}

export type MessageType = 'text' | 'image' | 'document' | 'audio' | 'template' | 'interactive';
export type MessageStatus = 'sent' | 'delivered' | 'read' | 'failed';

export interface WhatsAppMessage {
  id: string;
  conversationId: string;
  sender: 'lead' | 'agent' | 'system' | 'bot';
  senderName?: string;
  text: string;
  type: MessageType;
  mediaUrl?: string;
  mediaFileName?: string;
  timestamp: string;
  status: MessageStatus;
  templateName?: string;
  interactiveButtons?: string[];
  isNote?: boolean; // Internal team note
}

export interface Conversation {
  id: string;
  leadId: string;
  leadName: string;
  phone: string;
  avatar?: string;
  lastMessage: string;
  lastMessageTimestamp: string;
  unreadCount: number;
  assignedAgentId?: string;
  assignedAgentName?: string;
  tags: string[];
  stage: LeadStage;
  pinned?: boolean;
}

export type TemplateCategory = 'MARKETING' | 'UTILITY' | 'AUTHENTICATION';
export type TemplateStatus = 'APPROVED' | 'PENDING' | 'REJECTED' | 'DRAFT';

export interface TemplateButton {
  type: 'QUICK_REPLY' | 'URL' | 'PHONE_NUMBER';
  text: string;
  value?: string;
}

export interface WhatsAppTemplate {
  id: string;
  name: string;
  language: string;
  category: TemplateCategory;
  status: TemplateStatus;
  headerType?: 'NONE' | 'TEXT' | 'IMAGE' | 'DOCUMENT';
  headerText?: string;
  bodyText: string;
  footerText?: string;
  buttons?: TemplateButton[];
  createdAt: string;
}

export type CampaignStatus = 'DRAFT' | 'SCHEDULED' | 'RUNNING' | 'COMPLETED' | 'PAUSED';

export interface Campaign {
  id: string;
  name: string;
  templateId: string;
  templateName: string;
  targetSegment: string;
  totalRecipients: number;
  sentCount: number;
  deliveredCount: number;
  readCount: number;
  repliedCount: number;
  status: CampaignStatus;
  scheduledAt?: string;
  createdAt: string;
}

export interface AutomationRule {
  id: string;
  name: string;
  triggerKeyword: string;
  matchType: 'exact' | 'contains' | 'any';
  actionType: 'send_template' | 'assign_agent' | 'update_stage' | 'ai_reply' | 'direct_text';
  actionValue: string;
  actionValueName?: string;
  replyText?: string;
  isEnabled: boolean;
}

export interface AnalyticsSummary {
  totalLeads: number;
  activeChats: number;
  broadcastMessagesSent: number;
  avgResponseTimeMinutes: number;
  conversionRate: number;
  messagesTrend: { date: string; incoming: number; outgoing: number }[];
  leadStagesCount: Record<LeadStage, number>;
}

export interface ErpItem {
  id: string;
  itemCode: string;
  itemName: string;
  category: string;
  stockQty: number;
  unitPrice: number;
  uom: string;
  currency: string;
  imageUrl?: string;
}

export interface ErpDocumentItem {
  itemCode: string;
  itemName: string;
  qty: number;
  rate: number;
  amount: number;
}

export type ErpDocStatus = 'Draft' | 'Submitted' | 'Paid' | 'Invoiced' | 'Cancelled' | 'Overdue';

export interface ErpSalesOrder {
  id: string; // e.g. SAL-ORD-2026-0012
  customerName: string;
  customerPhone: string;
  postingDate: string;
  deliveryDate: string;
  grandTotal: number;
  status: ErpDocStatus;
  items: ErpDocumentItem[];
  currency: string;
  paymentUrl?: string;
}

export interface ErpInvoice {
  id: string; // e.g. ACC-SINV-2026-0089
  customerName: string;
  postingDate: string;
  dueDate: string;
  amount: number;
  outstandingAmount: number;
  status: 'Paid' | 'Unpaid' | 'Overdue';
  itemsCount: number;
}

export type TableStatus = 'Available' | 'Occupied' | 'Reserved' | 'Bill Requested';

export interface RestaurantTable {
  id: string;
  tableNumber: string;
  capacity: number;
  zone: 'Comedor Principal' | 'Terraza' | 'Bar & VIP' | 'Privado';
  status: TableStatus;
  currentOrderId?: string;
  assignedWaiter?: string;
}

export interface MenuItem {
  id: string;
  name: string;
  category: 'Platos Principales' | 'Bebidas & Cócteles' | 'Entradas' | 'Postres' | 'Menú Ejecutivo';
  price: number;
  description: string;
  isAvailable: boolean;
  preparationTimeMinutes: number;
  imageUrl?: string;
}

export type RestaurantOrderStatus = 'Pending' | 'Kitchen Preparing' | 'Ready to Serve' | 'Completed' | 'Cancelled';

export interface RestaurantOrder {
  id: string;
  orderType: 'Dine-in' | 'Takeaway' | 'Delivery' | 'WhatsApp QR';
  tableNumber?: string;
  customerName: string;
  customerPhone: string;
  items: { menuItemName: string; qty: number; price: number; notes?: string }[];
  status: RestaurantOrderStatus;
  totalAmount: number;
  timestamp: string;
  notes?: string;
}

export interface EcommerceProduct {
  id: string;
  title: string;
  slug: string;
  category: string;
  price: number;
  compareAtPrice?: number;
  stock: number;
  rating: number;
  imageUrl: string;
  badge?: string;
  description: string;
}

export interface StoreCartItem {
  product: EcommerceProduct;
  quantity: number;
}

export type StoreOrderStatus = 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Awaiting Payment';

export interface StoreOrder {
  id: string;
  customerName: string;
  customerPhone: string;
  shippingAddress: string;
  items: { productTitle: string; quantity: number; unitPrice: number }[];
  totalAmount: number;
  status: StoreOrderStatus;
  createdAt: string;
  paymentMethod: 'WhatsApp Direct' | 'Mercado Pago' | 'Credit Card' | 'Clientum Pay';
  frappeSalesOrderRef?: string;
}

export type ClusterSiteStatus = 'Active' | 'Provisioning' | 'Suspended' | 'Backup in Progress' | 'Maintenance';

export interface SaaSClusterSite {
  id: string;
  siteName: string;
  subdomain: string;
  databaseName: string;
  plan: 'Growth' | 'Professional' | 'Enterprise';
  status: ClusterSiteStatus;
  region: 'us-east1 (N. Virginia)' | 'sa-east1 (São Paulo)' | 'eu-west1 (Frankfurt)';
  storageUsedMb: number;
  storageMaxMb: number;
  usersUsed: number;
  usersMax: number;
  wabaMessagesUsed: number;
  wabaMessagesMax: number;
  createdAt: string;
}

export interface GeoStateCity {
  country: string;
  countryCode: string;
  stateName: string;
  cities: string[];
  fiscalTaxRate: number;
}

export interface SaaSUserSession {
  id: string;
  fullName: string;
  email: string;
  role: 'admin' | 'manager' | 'agent';
  companyName: string;
  subdomain: string;
  plan: 'Growth' | 'Professional' | 'Enterprise';
  avatarUrl: string;
  isTwoFactorEnabled: boolean;
  lastLoginAt: string;
}

export interface SaaSThemeConfig {
  presetName: string;
  primaryColor: string;
  accentColor: string;
  sidebarStyle: 'Dark Glass' | 'Minimal Light' | 'Compact Icons';
  fontFamily: 'Plus Jakarta Sans' | 'Inter' | 'Geist' | 'Outfit';
  brandLogoUrl: string;
  customCss: string;
  enableCustomNavbar: boolean;
  customFooterText: string;
  loginTheme: 'Centered Card' | 'Split Modern' | 'Minimal Slate';
  activeThemeId: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  userEmail: string;
  userName: string;
  action: string;
  category: 'AUTH' | 'CRM' | 'WHATSAPP' | 'ERP' | 'AGENT' | 'SYSTEM' | 'SECURITY';
  resource: string;
  ipAddress: string;
  status: 'Success' | 'Warning' | 'Failed';
  details: string;
}

export interface KnowledgeDocument {
  id: string;
  title: string;
  category: 'Politicas' | 'Precios y Planes' | 'Soporte Técnico' | 'FAQS' | 'Procedimientos ERP';
  content: string;
  fileType?: string;
  tags: string[];
  embeddingVectorCount?: number;
  updatedAt: string;
  author: string;
  status: 'Indexed' | 'Processing' | 'Draft';
}

export interface ActivityStreamItem {
  id: string;
  timestamp: string;
  agentName: string;
  agentAvatar?: string;
  actionType: 'ERP_INVOICE' | 'ERP_SALES_ORDER' | 'LEAD_STAGE' | 'WHATSAPP_BROADCAST' | 'DELEGATION' | 'STORE_ORDER' | 'KNOWLEDGE_INDEX';
  description: string;
  resourceId?: string;
  status: 'Completed' | 'In Progress' | 'Alert' | 'Pending';
  timeAgo: string;
}

export interface AIAgent {
  id: string;
  name: string;
  role: string;
  status: string;
  avatar: string;
  description?: string;
  skills?: string[];
  goals?: any[];
  systemPrompt?: string;
  memorySizeKB?: number;
  assignedSubdomain?: string;
  mcpToolsConnected?: string[];
  currentTask?: string;
  activeReasoningChain?: string | string[];
  tasksCompleted?: number;
  accuracyPct?: number;
  lastActionAt?: string;
}

export interface MCPTool {
  id: string;
  name: string;
  description: string;
  status?: string;
  server?: string;
  parameters?: any;
  permissionsRequired?: string[];
  category?: string;
  isAvailable?: boolean;
}

export interface RAGDocument {
  id: string;
  title: string;
  category?: string;
  content?: string;
  updatedAt?: string;
  sourceType?: string;
  subdomain?: string;
  fileSizeMB?: number;
  status?: string;
  totalEmbeddings?: number;
  chunkCount?: number;
  lastIndexedAt?: string;
}

export interface N8nWorkflow {
  id: string;
  name: string;
  active?: boolean;
  nodesCount?: number;
  triggerType?: string;
  trigger?: string;
  status?: string;
  executionCount?: number;
  lastRunAt?: string;
  targetApp?: string;
}

export interface ArchitecturePhase {
  id?: string;
  title: string;
  description?: string;
  status: string | number;
  phase?: string | number;
  subtitle?: string;
  summary?: string;
  diagramMermaid?: string;
  directoryTree?: any;
  keyTechnicalDecisions?: string[];
  advantages?: string[];
  risksAndMitigations?: any[];
}

export interface SiteBackup {
  id: string;
  siteId: string;
  siteName: string;
  createdAt: string;
  sizeMB: number;
  type: string;
  status: string;
  downloadUrl?: string;
  fileName?: string;
  expiresAt?: string;
}

export type SiteStatus = 'active' | 'provisioning' | 'maintenance' | 'suspended';

export interface Site {
  id: string;
  name: string;
  subdomain: string;
  benchName: string;
  frappeVersion: string;
  plan: string;
  status: SiteStatus;
  ssoToken?: string;
  ownerEmail?: string;
  companyName?: string;
  customDomain?: string;
  sslStatus?: string;
  benchId?: string;
  erpnextVersion?: string;
  installedApps?: string[];
  dbName?: string;
  dbUser?: string;
  dbPassword?: string;
  diskUsageMB?: number;
  diskQuotaMB?: number;
  usersCount?: number;
  maxUsers?: number;
  createdAt?: string;
  lastBackupAt?: string;
  country?: string;
}

export interface BenchNode {
  id: string;
  name: string;
  hostname: string;
  ipAddress: string;
  region: string;
  provider: string;
  frappeBranch: string;
  sitesCount: number;
  maxSites: number;
  cpuUsagePct: number;
  memoryUsageGB: number;
  memoryTotalGB: number;
  diskUsageGB: number;
  diskTotalGB: number;
  status: string;
  installedApps: string[];
  redisStatus: string;
  workerStatus: string;
  lastHealthCheck: string;
}

export type PlanTier = 'starter' | 'professional' | 'enterprise';

export interface SubscriptionPlan {
  id: string;
  name: string;
  priceMonthly: number;
  priceYearly: number;
  maxUsers: number;
  maxDiskMB: number;
  includedApps: string[];
  backgroundWorkers: number;
  customDomainAllowed: boolean;
  backupFrequency: string;
  supportLevel: string;
}

export interface SubscriptionRecord {
  id: string;
  siteId: string;
  siteName: string;
  customerEmail: string;
  companyName: string;
  planId: string;
  billingInterval: string;
  status: string;
  amount: number;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  nextInvoiceAt: string;
  paymentMethod: string;
}

export interface EmailNotification {
  id: string;
  subject: string;
  recipient: string;
  sentAt: string;
  status: string;
  eventType?: string;
}

export interface ControlPlaneMetrics {
  totalSites: number;
  activeSites: number;
  provisioningSites: number;
  maintenanceSites: number;
  totalBenches: number;
  onlineBenches: number;
  mrrAmount: number;
  activeSubscriptions: number;
  totalDiskUsedGB: number;
  totalDiskCapacityGB: number;
  averageCpuUsagePct: number;
  backupsCountToday: number;
  backupSuccessRatePct: number;
}

export interface SystemLog {
  id: string;
  timestamp: string;
  level: string;
  siteId?: string;
  siteName?: string;
  source: string;
  message: string;
  details?: string;
  benchId?: string;
}

export interface FrappeApp {
  id: string;
  name: string;
  title: string;
  version: string;
  category: string;
  description: string;
  isRequired?: boolean;
  repoUrl?: string;
}

export interface Invoice {
  id: string;
  subscriptionId: string;
  customerName: string;
  companyName: string;
  amount: number;
  status: string;
  dueDate: string;
  createdAt: string;
  itemsDescription: string;
  pdfUrl?: string;
}



